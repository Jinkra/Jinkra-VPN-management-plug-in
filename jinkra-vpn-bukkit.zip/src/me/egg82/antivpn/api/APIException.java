/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.api;

public class APIException
extends RuntimeException {
    private final boolean hard;

    public APIException(boolean hard, String message) {
        super(message);
        this.hard = hard;
    }

    public APIException(boolean hard, Throwable cause) {
        super(cause);
        this.hard = hard;
    }

    public APIException(boolean hard, String message, Throwable cause) {
        super(message, cause);
        this.hard = hard;
    }

    public boolean isHard() {
        return this.hard;
    }
}

/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.api;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import me.egg82.antivpn.api.VPNAPI;
import me.egg82.antivpn.api.VPNAPIProvider;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class APIRegistrationUtil {
    private static final Logger logger = LoggerFactory.getLogger(APIRegistrationUtil.class);
    private static final Method REGISTER;
    private static final Method DEREGISTER;

    private APIRegistrationUtil() {
    }

    public static void register(@NonNull VPNAPI api) {
        try {
            REGISTER.invoke(null, api);
        }
        catch (IllegalAccessException | InvocationTargetException ex) {
            logger.error(ex.getMessage(), ex);
        }
    }

    public static void deregister() {
        try {
            DEREGISTER.invoke(null, new Object[0]);
        }
        catch (IllegalAccessException | InvocationTargetException ex) {
            logger.error(ex.getMessage(), ex);
        }
    }

    static {
        try {
            REGISTER = VPNAPIProvider.class.getDeclaredMethod("register", VPNAPI.class);
            REGISTER.setAccessible(true);
            DEREGISTER = VPNAPIProvider.class.getDeclaredMethod("deregister", new Class[0]);
            DEREGISTER.setAccessible(true);
        }
        catch (NoSuchMethodException ex) {
            throw new ExceptionInInitializerError(ex);
        }
    }
}

/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.api.platform;

import org.checkerframework.checker.nullness.qual.NonNull;

public static enum Platform.Type {
    BUKKIT("Bukkit"),
    BUNGEECORD("BungeeCord"),
    VELOCITY("Velocity");

    private final String friendlyName;

    private Platform.Type(String friendlyName) {
        this.friendlyName = friendlyName;
    }

    public @NonNull String getFriendlyName() {
        return this.friendlyName;
    }
}

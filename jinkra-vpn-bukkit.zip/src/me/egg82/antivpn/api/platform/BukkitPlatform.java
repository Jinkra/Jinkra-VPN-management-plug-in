/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableSet
 */
package me.egg82.antivpn.api.platform;

import com.google.common.collect.ImmutableSet;
import java.net.InetAddress;
import java.time.Instant;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import me.egg82.antivpn.api.platform.Platform;
import org.checkerframework.checker.nullness.qual.NonNull;

public class BukkitPlatform
implements Platform {
    private static final Set<UUID> uniquePlayers = new HashSet<UUID>();
    private static final Set<InetAddress> uniqueIps = new HashSet<InetAddress>();
    private final Instant startTime;

    public static void addUniquePlayer(@NonNull UUID uuid) {
        uniquePlayers.add(uuid);
    }

    public static void addUniqueIp(@NonNull InetAddress ip) {
        uniqueIps.add(ip);
    }

    public BukkitPlatform(long startTime) {
        this.startTime = Instant.ofEpochMilli(startTime);
    }

    @Override
    public @NonNull Platform.Type getType() {
        return Platform.Type.BUKKIT;
    }

    @Override
    public @NonNull Set<UUID> getUniquePlayers() {
        return ImmutableSet.copyOf(uniquePlayers);
    }

    @Override
    public @NonNull Set<InetAddress> getUniqueIPs() {
        return ImmutableSet.copyOf(uniqueIps);
    }

    @Override
    public @NonNull Instant getStartTime() {
        return this.startTime;
    }
}

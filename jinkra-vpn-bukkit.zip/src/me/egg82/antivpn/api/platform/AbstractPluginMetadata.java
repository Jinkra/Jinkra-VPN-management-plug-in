/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.api.platform;

import me.egg82.antivpn.api.platform.PluginMetadata;
import org.checkerframework.checker.nullness.qual.NonNull;

public abstract class AbstractPluginMetadata
implements PluginMetadata {
    private static final String API_VERSION = "2.0.0";

    @Override
    public @NonNull String getApiVersion() {
        return API_VERSION;
    }
}

/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.api.platform;

import org.checkerframework.checker.nullness.qual.NonNull;

public interface PluginMetadata {
    public @NonNull String getVersion();

    public @NonNull String getApiVersion();
}

/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.api.platform;

import me.egg82.antivpn.api.platform.AbstractPluginMetadata;
import org.checkerframework.checker.nullness.qual.NonNull;

public class BukkitPluginMetadata
extends AbstractPluginMetadata {
    private final String pluginVersion;

    public BukkitPluginMetadata(String pluginVersion) {
        this.pluginVersion = pluginVersion;
    }

    @Override
    public @NonNull String getVersion() {
        return this.pluginVersion;
    }
}

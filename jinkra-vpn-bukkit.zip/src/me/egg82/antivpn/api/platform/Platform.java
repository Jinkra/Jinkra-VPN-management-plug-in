/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.api.platform;

import java.net.InetAddress;
import java.time.Instant;
import java.util.Set;
import java.util.UUID;
import org.checkerframework.checker.nullness.qual.NonNull;

public interface Platform {
    public @NonNull Type getType();

    public @NonNull Set<UUID> getUniquePlayers();

    public @NonNull Set<InetAddress> getUniqueIPs();

    public @NonNull Instant getStartTime();

    public static enum Type {
        BUKKIT("Bukkit"),
        BUNGEECORD("BungeeCord"),
        VELOCITY("Velocity");

        private final String friendlyName;

        private Type(String friendlyName) {
            this.friendlyName = friendlyName;
        }

        public @NonNull String getFriendlyName() {
            return this.friendlyName;
        }
    }
}

/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.api;

import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import me.egg82.antivpn.api.event.VPNEvent;
import me.egg82.antivpn.api.model.ip.IPManager;
import me.egg82.antivpn.api.model.player.PlayerManager;
import me.egg82.antivpn.api.model.source.SourceManager;
import me.egg82.antivpn.api.platform.Platform;
import me.egg82.antivpn.api.platform.PluginMetadata;
import net.engio.mbassy.bus.MBassador;
import org.checkerframework.checker.nullness.qual.NonNull;

public interface VPNAPI {
    public @NonNull UUID getServerId();

    public @NonNull IPManager getIPManager();

    public @NonNull PlayerManager getPlayerManager();

    public @NonNull SourceManager getSourceManager();

    public @NonNull Platform getPlatform();

    public @NonNull PluginMetadata getPluginMetadata();

    public @NonNull CompletableFuture<Void> runUpdateTask();

    public @NonNull MBassador<VPNEvent> getEventBus();
}

/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.api.model.ip;

import java.net.InetAddress;
import java.util.Objects;
import me.egg82.antivpn.api.model.ip.AlgorithmMethod;
import me.egg82.antivpn.api.model.ip.IP;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.checkerframework.checker.nullness.qual.Nullable;

public class GenericIP
implements IP {
    private final InetAddress ip;
    private AlgorithmMethod type;
    private Boolean cascade;
    private Double consensus;
    private final int hc;

    public GenericIP(@NonNull InetAddress ip, @NonNull AlgorithmMethod type, @Nullable Boolean cascade, @Nullable Double consensus) {
        this.ip = ip;
        this.type = type;
        this.cascade = cascade;
        this.consensus = consensus;
        this.hc = Objects.hash(ip);
    }

    @Override
    public @NonNull InetAddress getIP() {
        return this.ip;
    }

    @Override
    public @Nullable Boolean getCascade() {
        return this.cascade;
    }

    @Override
    public void setCascade(@Nullable Boolean status) {
        this.cascade = status;
    }

    @Override
    public @Nullable Double getConsensus() {
        return this.consensus;
    }

    @Override
    public void setConsensus(@Nullable Double status) {
        this.consensus = status;
    }

    @Override
    public @NonNull AlgorithmMethod getType() {
        return this.type;
    }

    @Override
    public void setType(@NonNull AlgorithmMethod type) {
        this.type = type;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof GenericIP)) {
            return false;
        }
        GenericIP genericIP = (GenericIP)o;
        return this.ip.equals(genericIP.ip);
    }

    @Override
    public int hashCode() {
        return this.hc;
    }

    @Override
    public String toString() {
        return "GenericIP{ip='" + this.ip + '\'' + ", type=" + (Object)((Object)this.type) + ", cascade=" + this.cascade + ", consensus=" + this.consensus + '}';
    }
}

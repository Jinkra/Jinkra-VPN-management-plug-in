/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.api.model.ip;

import org.checkerframework.checker.nullness.qual.NonNull;

public enum AlgorithmMethod {
    CASCADE("cascade"),
    CONSESNSUS("consensus");

    private final String name;

    private AlgorithmMethod(String name) {
        this.name = name.toLowerCase();
    }

    public String getName() {
        return this.name;
    }

    public static AlgorithmMethod getByName(@NonNull String name) {
        for (AlgorithmMethod value : AlgorithmMethod.values()) {
            if (!value.name.equalsIgnoreCase(name)) continue;
            return value;
        }
        return null;
    }
}

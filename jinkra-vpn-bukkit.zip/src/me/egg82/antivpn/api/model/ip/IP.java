/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.api.model.ip;

import java.io.Serializable;
import java.net.InetAddress;
import me.egg82.antivpn.api.model.ip.AlgorithmMethod;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.checkerframework.checker.nullness.qual.Nullable;

public interface IP
extends Serializable {
    public @NonNull InetAddress getIP();

    public @NonNull AlgorithmMethod getType();

    public void setType(@NonNull AlgorithmMethod var1);

    public @Nullable Boolean getCascade();

    public void setCascade(@Nullable Boolean var1);

    public @Nullable Double getConsensus();

    public void setConsensus(@Nullable Double var1);

    public boolean equals(Object var1);

    public int hashCode();

    public String toString();
}

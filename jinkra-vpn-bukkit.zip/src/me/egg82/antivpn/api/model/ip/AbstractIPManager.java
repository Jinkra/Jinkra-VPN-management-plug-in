/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  me.egg82.antivpn.external.com.github.benmanes.caffeine.cache.Caffeine
 *  me.egg82.antivpn.external.com.github.benmanes.caffeine.cache.LoadingCache
 */
package me.egg82.antivpn.api.model.ip;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CancellationException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import me.egg82.antivpn.api.APIException;
import me.egg82.antivpn.api.model.ip.AlgorithmMethod;
import me.egg82.antivpn.api.model.ip.GenericIP;
import me.egg82.antivpn.api.model.ip.IP;
import me.egg82.antivpn.api.model.ip.IPManager;
import me.egg82.antivpn.api.model.source.Source;
import me.egg82.antivpn.api.model.source.SourceManager;
import me.egg82.antivpn.api.model.source.models.SourceModel;
import me.egg82.antivpn.config.CachedConfig;
import me.egg82.antivpn.config.ConfigUtil;
import me.egg82.antivpn.core.Pair;
import me.egg82.antivpn.external.com.github.benmanes.caffeine.cache.Caffeine;
import me.egg82.antivpn.external.com.github.benmanes.caffeine.cache.LoadingCache;
import me.egg82.antivpn.messaging.packets.DeleteIPPacket;
import me.egg82.antivpn.messaging.packets.IPPacket;
import me.egg82.antivpn.storage.StorageService;
import me.egg82.antivpn.storage.models.IPModel;
import me.egg82.antivpn.utils.ExceptionUtil;
import me.egg82.antivpn.utils.PacketUtil;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class AbstractIPManager
implements IPManager {
    protected final Logger logger = LoggerFactory.getLogger(this.getClass());
    private final LoadingCache<Pair<String, AlgorithmMethod>, IPModel> ipCache;
    private final LoadingCache<String, Boolean> sourceInvalidationCache;
    private final SourceManager sourceManager;

    protected AbstractIPManager(@NonNull SourceManager sourceManager, long cacheTime, TimeUnit cacheTimeUnit) {
        this.sourceManager = sourceManager;
        this.ipCache = Caffeine.newBuilder().expireAfterAccess(cacheTime, cacheTimeUnit).expireAfterWrite(cacheTime, cacheTimeUnit).build(k -> this.calculateIpResult((String)k.getT1(), (AlgorithmMethod)((Object)((Object)k.getT2())), true));
        this.sourceInvalidationCache = Caffeine.newBuilder().expireAfterWrite(1L, TimeUnit.MINUTES).build(k -> Boolean.FALSE);
    }

    public LoadingCache<Pair<String, AlgorithmMethod>, IPModel> getIpCache() {
        return this.ipCache;
    }

    @Override
    public @NonNull CompletableFuture<IP> getIP(@NonNull String ip) {
        return CompletableFuture.supplyAsync(() -> {
            CachedConfig cachedConfig = ConfigUtil.getCachedConfig();
            if (cachedConfig == null) {
                throw new APIException(false, "Cached config could not be fetched.");
            }
            for (StorageService service : cachedConfig.getStorage()) {
                IPModel model = service.getIpModel(ip, cachedConfig.getSourceCacheTime());
                if (model == null) continue;
                try {
                    return new GenericIP(InetAddress.getByName(ip), AlgorithmMethod.values()[model.getType()], model.getCascade(), model.getConsensus());
                }
                catch (UnknownHostException ex) {
                    throw new IllegalArgumentException("Could not create InetAddress for " + model.getIp());
                }
            }
            return null;
        });
    }

    @Override
    public @NonNull CompletableFuture<Void> saveIP(@NonNull IP ip) {
        return CompletableFuture.runAsync(() -> {
            CachedConfig cachedConfig = ConfigUtil.getCachedConfig();
            if (cachedConfig == null) {
                throw new APIException(false, "Cached config could not be fetched.");
            }
            for (StorageService service : cachedConfig.getStorage()) {
                IPModel model = service.getOrCreateIpModel(ip.getIP().getHostAddress(), ip.getType().ordinal());
                model.setCascade(ip.getCascade());
                model.setConsensus(ip.getConsensus());
                service.storeModel(model);
            }
            IPPacket packet = new IPPacket();
            packet.setIp(ip.getIP().getHostAddress());
            packet.setType(ip.getType().ordinal());
            packet.setCascade(ip.getCascade());
            packet.setConsensus(ip.getConsensus());
            PacketUtil.queuePacket(packet);
        });
    }

    @Override
    public @NonNull CompletableFuture<Void> deleteIP(@NonNull String ip) {
        return CompletableFuture.runAsync(() -> {
            CachedConfig cachedConfig = ConfigUtil.getCachedConfig();
            if (cachedConfig == null) {
                throw new APIException(false, "Cached config could not be fetched.");
            }
            for (StorageService service : cachedConfig.getStorage()) {
                IPModel model = new IPModel();
                model.setIp(ip);
                service.deleteModel(model);
            }
            DeleteIPPacket packet = new DeleteIPPacket();
            packet.setIp(ip);
            PacketUtil.queuePacket(packet);
        });
    }

    @Override
    public @NonNull CompletableFuture<Set<InetAddress>> getIPs() {
        return CompletableFuture.supplyAsync(() -> {
            CachedConfig cachedConfig = ConfigUtil.getCachedConfig();
            if (cachedConfig == null) {
                throw new APIException(false, "Cached config could not be fetched.");
            }
            HashSet<InetAddress> retVal = new HashSet<InetAddress>();
            for (StorageService service : cachedConfig.getStorage()) {
                Set<IPModel> models = service.getAllIps(cachedConfig.getSourceCacheTime());
                if (models.isEmpty()) continue;
                for (IPModel model : models) {
                    try {
                        retVal.add(InetAddress.getByName(model.getIp()));
                    }
                    catch (UnknownHostException ex) {
                        this.logger.warn("Could not create InetAddress for " + model.getIp());
                    }
                }
            }
            return retVal;
        });
    }

    @Override
    public @NonNull AlgorithmMethod getCurrentAlgorithmMethod() throws APIException {
        CachedConfig cachedConfig = ConfigUtil.getCachedConfig();
        if (cachedConfig == null) {
            throw new APIException(false, "Cached config could not be fetched.");
        }
        return cachedConfig.getVPNAlgorithmMethod();
    }

    @Override
    public @NonNull CompletableFuture<Boolean> cascade(@NonNull String ip, boolean useCache) {
        return CompletableFuture.supplyAsync(() -> {
            IPModel model;
            if (useCache) {
                try {
                    model = (IPModel)this.ipCache.get(new Pair<String, AlgorithmMethod>(ip, AlgorithmMethod.CASCADE));
                }
                catch (CompletionException ex) {
                    if (ex.getCause() instanceof APIException) {
                        throw (APIException)ex.getCause();
                    }
                    throw new APIException(false, "Could not get data for IP " + ip, ex);
                }
                catch (Error | RuntimeException ex) {
                    throw new APIException(false, "Could not get data for IP " + ip, ex);
                }
            } else {
                model = this.calculateIpResult(ip, AlgorithmMethod.CASCADE, false);
            }
            if (model == null) {
                throw new APIException(false, "Could not get data for IP " + ip);
            }
            return model.getCascade();
        });
    }

    @Override
    public @NonNull CompletableFuture<Double> consensus(@NonNull String ip, boolean useCache) {
        return CompletableFuture.supplyAsync(() -> {
            IPModel model;
            if (useCache) {
                try {
                    model = (IPModel)this.ipCache.get(new Pair<String, AlgorithmMethod>(ip, AlgorithmMethod.CONSESNSUS));
                }
                catch (CompletionException ex) {
                    if (ex.getCause() instanceof APIException) {
                        throw (APIException)ex.getCause();
                    }
                    throw new APIException(false, "Could not get data for IP " + ip, ex);
                }
                catch (Error | RuntimeException ex) {
                    throw new APIException(false, "Could not get data for IP " + ip, ex);
                }
            } else {
                model = this.calculateIpResult(ip, AlgorithmMethod.CONSESNSUS, false);
            }
            if (model == null) {
                throw new APIException(false, "Could not get data for IP " + ip);
            }
            return model.getConsensus();
        });
    }

    @Override
    public double getMinConsensusValue() throws APIException {
        CachedConfig cachedConfig = ConfigUtil.getCachedConfig();
        if (cachedConfig == null) {
            throw new APIException(false, "Cached config could not be fetched.");
        }
        return cachedConfig.getVPNAlgorithmConsensus();
    }

    private @NonNull IPModel calculateIpResult(@NonNull String ip, @NonNull AlgorithmMethod method, boolean useCache) throws APIException {
        CachedConfig cachedConfig = ConfigUtil.getCachedConfig();
        if (cachedConfig == null) {
            throw new APIException(false, "Cached config could not be fetched.");
        }
        if (useCache) {
            for (StorageService service : cachedConfig.getStorage()) {
                IPModel model = service.getIpModel(ip, cachedConfig.getSourceCacheTime());
                if (model == null || model.getType() != method.ordinal()) continue;
                if (cachedConfig.getDebug()) {
                    this.logger.info("Found database value for IP " + ip + ".");
                }
                return model;
            }
        }
        if (cachedConfig.getDebug()) {
            this.logger.info("Getting web result for IP " + ip + ".");
        }
        IPModel retVal = new IPModel();
        retVal.setIp(ip);
        retVal.setType(cachedConfig.getVPNAlgorithmMethod().ordinal());
        if (method == AlgorithmMethod.CONSESNSUS) {
            ExecutorService pool = Executors.newWorkStealingPool(cachedConfig.getThreads());
            List<Source<? extends SourceModel>> sources = this.sourceManager.getSources();
            CountDownLatch latch = new CountDownLatch(sources.size());
            AtomicLong results = new AtomicLong(0L);
            AtomicLong totalSources = new AtomicLong(0L);
            for (Source<? extends SourceModel> source : sources) {
                pool.submit(() -> {
                    if (Boolean.TRUE.equals(this.sourceInvalidationCache.get((Object)source.getName()))) {
                        if (cachedConfig.getDebug()) {
                            this.logger.info("Skipping source " + source.getName() + " due to recent failure.");
                        }
                        latch.countDown();
                        return;
                    }
                    if (cachedConfig.getDebug()) {
                        this.logger.info("Getting result from source " + source.getName() + ".");
                    }
                    try {
                        Boolean result = source.getResult(ip).get();
                        if (result != null) {
                            if (Boolean.TRUE.equals(result)) {
                                results.addAndGet(1L);
                            }
                            totalSources.addAndGet(1L);
                        } else {
                            this.logger.error("Source " + source.getName() + " returned an error. Skipping.");
                            this.sourceInvalidationCache.put((Object)source.getName(), (Object)Boolean.TRUE);
                        }
                    }
                    catch (InterruptedException ignored) {
                        this.logger.error("Source " + source.getName() + " returned an error. Skipping.");
                        this.sourceInvalidationCache.put((Object)source.getName(), (Object)Boolean.TRUE);
                        Thread.currentThread().interrupt();
                    }
                    catch (CancellationException | ExecutionException ex) {
                        this.logger.error("Source " + source.getName() + " returned an error. Skipping.");
                        this.sourceInvalidationCache.put((Object)source.getName(), (Object)Boolean.TRUE);
                        ExceptionUtil.handleException(ex, this.logger);
                    }
                    latch.countDown();
                });
            }
            try {
                if (!latch.await(20L, TimeUnit.SECONDS)) {
                    this.logger.warn("Consensus timed out before all sources could be queried.");
                }
            }
            catch (InterruptedException ex) {
                if (cachedConfig.getDebug()) {
                    this.logger.error(ex.getMessage(), ex);
                } else {
                    this.logger.error(ex.getMessage());
                }
                Thread.currentThread().interrupt();
            }
            pool.shutdownNow();
            if (totalSources.get() > 0L) {
                retVal.setConsensus((double)results.get() / (double)totalSources.get());
                if (useCache) {
                    this.storeResult(retVal, cachedConfig);
                    this.sendResult(retVal, cachedConfig);
                }
                return retVal;
            }
        } else {
            for (Source<? extends SourceModel> source : this.sourceManager.getSources()) {
                if (Boolean.TRUE.equals(this.sourceInvalidationCache.get((Object)source.getName()))) {
                    if (!cachedConfig.getDebug()) continue;
                    this.logger.info("Skipping source " + source.getName() + " due to recent failure.");
                    continue;
                }
                if (cachedConfig.getDebug()) {
                    this.logger.info("Getting result from source " + source.getName() + ".");
                }
                try {
                    retVal.setCascade(source.getResult(ip).get());
                    if (retVal.getCascade() != null) break;
                    this.logger.error("Source " + source.getName() + " returned an error. Skipping.");
                    this.sourceInvalidationCache.put((Object)source.getName(), (Object)Boolean.TRUE);
                }
                catch (InterruptedException ignored) {
                    this.logger.error("Source " + source.getName() + " returned an error. Skipping.");
                    this.sourceInvalidationCache.put((Object)source.getName(), (Object)Boolean.TRUE);
                    Thread.currentThread().interrupt();
                }
                catch (CancellationException | ExecutionException ex) {
                    this.logger.error("Source " + source.getName() + " returned an error. Skipping.");
                    this.sourceInvalidationCache.put((Object)source.getName(), (Object)Boolean.TRUE);
                    ExceptionUtil.handleException(ex, this.logger);
                }
            }
            if (useCache && retVal.getCascade() != null) {
                this.storeResult(retVal, cachedConfig);
                this.sendResult(retVal, cachedConfig);
            }
            return retVal;
        }
        throw new APIException(false, "No sources were available to query. See https://github.com/egg82/AntiVPN/wiki/FAQ#Errors");
    }

    private void storeResult(@NonNull IPModel model, @NonNull CachedConfig cachedConfig) {
        for (StorageService service : cachedConfig.getStorage()) {
            IPModel m = service.getOrCreateIpModel(model.getIp(), model.getType());
            m.setCascade(model.getCascade());
            m.setConsensus(model.getConsensus());
            service.storeModel(m);
        }
        if (cachedConfig.getDebug()) {
            this.logger.info("Stored data for " + model.getIp() + " in storage.");
        }
    }

    private void sendResult(@NonNull IPModel model, @NonNull CachedConfig cachedConfig) {
        IPPacket packet = new IPPacket();
        packet.setIp(model.getIp());
        packet.setType(model.getType());
        packet.setCascade(model.getCascade());
        packet.setConsensus(model.getConsensus());
        PacketUtil.queuePacket(packet);
        if (cachedConfig.getDebug()) {
            this.logger.info("Queued packet for " + model.getIp() + " in messaging.");
        }
    }
}

/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.api.model.ip;

import java.net.InetAddress;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import me.egg82.antivpn.api.APIException;
import me.egg82.antivpn.api.model.ip.AlgorithmMethod;
import me.egg82.antivpn.api.model.ip.IP;
import me.egg82.antivpn.api.model.player.Player;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.checkerframework.checker.nullness.qual.Nullable;

public interface IPManager {
    default public @NonNull CompletableFuture<IP> getIP(@NonNull InetAddress ip) {
        return this.getIP(ip.getHostAddress());
    }

    public @NonNull CompletableFuture<IP> getIP(@NonNull String var1);

    public @NonNull CompletableFuture<Void> saveIP(@NonNull IP var1);

    default public @NonNull CompletableFuture<Void> deleteIP(@NonNull IP ip) {
        return this.deleteIP(ip.getIP().getHostAddress());
    }

    default public @NonNull CompletableFuture<Void> deleteIP(@NonNull InetAddress ip) {
        return this.deleteIP(ip.getHostAddress());
    }

    public @NonNull CompletableFuture<Void> deleteIP(@NonNull String var1);

    public @NonNull CompletableFuture<Set<InetAddress>> getIPs();

    public @NonNull AlgorithmMethod getCurrentAlgorithmMethod() throws APIException;

    default public @NonNull CompletableFuture<Boolean> cascade(@NonNull IP ip, boolean useCache) {
        return this.cascade(ip.getIP().getHostAddress(), useCache);
    }

    default public @NonNull CompletableFuture<Boolean> cascade(@NonNull InetAddress ip, boolean useCache) {
        return this.cascade(ip.getHostAddress(), useCache);
    }

    public @NonNull CompletableFuture<Boolean> cascade(@NonNull String var1, boolean var2);

    default public @NonNull CompletableFuture<Double> consensus(@NonNull IP ip, boolean useCache) {
        return this.consensus(ip.getIP().getHostAddress(), useCache);
    }

    default public @NonNull CompletableFuture<Double> consensus(@NonNull InetAddress ip, boolean useCache) {
        return this.consensus(ip.getHostAddress(), useCache);
    }

    public @NonNull CompletableFuture<Double> consensus(@NonNull String var1, boolean var2);

    public double getMinConsensusValue() throws APIException;

    default public boolean kickForVpn(@NonNull Player player, @NonNull IP ip) {
        return this.kickForVpn(Objects.requireNonNull(player.getName()), player.getUuid(), ip.getIP().getHostAddress());
    }

    default public boolean kickForVpn(@NonNull String playerName, @NonNull UUID playerUuid, @NonNull IP ip) {
        return this.kickForVpn(playerName, playerUuid, ip.getIP().getHostAddress());
    }

    default public boolean kickForVpn(@NonNull Player player, @NonNull InetAddress ip) {
        return this.kickForVpn(Objects.requireNonNull(player.getName()), player.getUuid(), ip.getHostAddress());
    }

    default public boolean kickForVpn(@NonNull Player player, @NonNull String ip) {
        return this.kickForVpn(Objects.requireNonNull(player.getName()), player.getUuid(), ip);
    }

    default public boolean kickForVpn(@NonNull String playerName, @NonNull UUID playerUuid, @NonNull InetAddress ip) {
        return this.kickForVpn(playerName, playerUuid, ip.getHostAddress());
    }

    public boolean kickForVpn(@NonNull String var1, @NonNull UUID var2, @NonNull String var3);

    default public @Nullable String getVpnKickMessage(@NonNull Player player, @NonNull IP ip) {
        return this.getVpnKickMessage(Objects.requireNonNull(player.getName()), player.getUuid(), ip.getIP().getHostAddress());
    }

    default public @Nullable String getVpnKickMessage(@NonNull String playerName, @NonNull UUID playerUuid, @NonNull IP ip) {
        return this.getVpnKickMessage(playerName, playerUuid, ip.getIP().getHostAddress());
    }

    default public @Nullable String getVpnKickMessage(@NonNull Player player, @NonNull InetAddress ip) {
        return this.getVpnKickMessage(Objects.requireNonNull(player.getName()), player.getUuid(), ip.getHostAddress());
    }

    default public @Nullable String getVpnKickMessage(@NonNull Player player, @NonNull String ip) {
        return this.getVpnKickMessage(Objects.requireNonNull(player.getName()), player.getUuid(), ip);
    }

    default public @Nullable String getVpnKickMessage(@NonNull String playerName, @NonNull UUID playerUuid, @NonNull InetAddress ip) {
        return this.getVpnKickMessage(playerName, playerUuid, ip.getHostAddress());
    }

    public @Nullable String getVpnKickMessage(@NonNull String var1, @NonNull UUID var2, @NonNull String var3);

    default public @NonNull List<String> getVpnCommands(@NonNull Player player, @NonNull IP ip) {
        return this.getVpnCommands(Objects.requireNonNull(player.getName()), player.getUuid(), ip.getIP().getHostAddress());
    }

    default public @NonNull List<String> getVpnCommands(@NonNull String playerName, @NonNull UUID playerUuid, @NonNull IP ip) {
        return this.getVpnCommands(playerName, playerUuid, ip.getIP().getHostAddress());
    }

    default public @NonNull List<String> getVpnCommands(@NonNull Player player, @NonNull InetAddress ip) {
        return this.getVpnCommands(Objects.requireNonNull(player.getName()), player.getUuid(), ip.getHostAddress());
    }

    default public @NonNull List<String> getVpnCommands(@NonNull Player player, @NonNull String ip) {
        return this.getVpnCommands(Objects.requireNonNull(player.getName()), player.getUuid(), ip);
    }

    default public @NonNull List<String> getVpnCommands(@NonNull String playerName, @NonNull UUID playerUuid, @NonNull InetAddress ip) {
        return this.getVpnCommands(playerName, playerUuid, ip.getHostAddress());
    }

    public @NonNull List<String> getVpnCommands(@NonNull String var1, @NonNull UUID var2, @NonNull String var3);
}

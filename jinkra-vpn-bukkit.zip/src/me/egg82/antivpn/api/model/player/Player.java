/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.api.model.player;

import java.io.Serializable;
import java.util.UUID;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.checkerframework.checker.nullness.qual.Nullable;

public interface Player
extends Serializable {
    public @NonNull UUID getUuid();

    public @Nullable String getName();

    public boolean isMcLeaks();

    public void setMcLeaks(boolean var1);

    public boolean equals(Object var1);

    public int hashCode();

    public String toString();
}

/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.api.model.player;

import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.CancellationException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import me.egg82.antivpn.api.model.player.Player;
import me.egg82.antivpn.utils.ExceptionUtil;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.checkerframework.checker.nullness.qual.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class AbstractPlayer
implements Player {
    protected final transient Logger logger = LoggerFactory.getLogger(this.getClass());
    private final UUID uuid;
    private final String name;
    private boolean mcleaks;
    private final int hc;

    protected AbstractPlayer(@NonNull UUID uuid, String name, boolean mcleaks) {
        this.uuid = uuid;
        if (name == null) {
            try {
                name = this.fetchName(uuid).get();
            }
            catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
            }
            catch (CancellationException | ExecutionException ex) {
                ExceptionUtil.handleException(ex, this.logger);
            }
        }
        this.name = name;
        this.mcleaks = mcleaks;
        this.hc = Objects.hash(uuid);
    }

    @Override
    public @NonNull UUID getUuid() {
        return this.uuid;
    }

    @Override
    public @Nullable String getName() {
        return this.name;
    }

    @Override
    public boolean isMcLeaks() {
        return this.mcleaks;
    }

    @Override
    public void setMcLeaks(boolean status) {
        this.mcleaks = status;
    }

    protected abstract @NonNull CompletableFuture<String> fetchName(@NonNull UUID var1);

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof AbstractPlayer)) {
            return false;
        }
        AbstractPlayer that = (AbstractPlayer)o;
        return this.uuid.equals(that.uuid);
    }

    @Override
    public int hashCode() {
        return this.hc;
    }

    @Override
    public String toString() {
        return "AbstractPlayer{uuid=" + this.uuid + ", name='" + this.name + '\'' + ", mcleaks=" + this.mcleaks + '}';
    }
}

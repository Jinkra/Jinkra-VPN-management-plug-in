/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.api.model.player;

import java.net.InetAddress;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import me.egg82.antivpn.api.model.ip.IP;
import me.egg82.antivpn.api.model.player.Player;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.checkerframework.checker.nullness.qual.Nullable;

public interface PlayerManager {
    public @NonNull CompletableFuture<Player> getPlayer(@NonNull UUID var1);

    public @NonNull CompletableFuture<Player> getPlayer(@NonNull String var1);

    public @NonNull CompletableFuture<Void> savePlayer(@NonNull Player var1);

    default public @NonNull CompletableFuture<Void> deletePlayer(@NonNull Player player) {
        return this.deletePlayer(player.getUuid());
    }

    public @NonNull CompletableFuture<Void> deletePlayer(@NonNull UUID var1);

    public @NonNull CompletableFuture<Set<UUID>> getPlayers();

    default public @NonNull CompletableFuture<Boolean> checkMcLeaks(@NonNull Player player, boolean useCache) {
        return this.checkMcLeaks(player.getUuid(), useCache);
    }

    public @NonNull CompletableFuture<Boolean> checkMcLeaks(@NonNull UUID var1, boolean var2);

    default public boolean kickForMcLeaks(@NonNull Player player, @NonNull IP ip) {
        return this.kickForMcLeaks(Objects.requireNonNull(player.getName()), player.getUuid(), ip.getIP().getHostAddress());
    }

    default public boolean kickForMcLeaks(@NonNull String playerName, @NonNull UUID playerUuid, @NonNull IP ip) {
        return this.kickForMcLeaks(playerName, playerUuid, ip.getIP().getHostAddress());
    }

    default public boolean kickForMcLeaks(@NonNull Player player, @NonNull InetAddress ip) {
        return this.kickForMcLeaks(Objects.requireNonNull(player.getName()), player.getUuid(), ip.getHostAddress());
    }

    default public boolean kickForMcLeaks(@NonNull Player player, @NonNull String ip) {
        return this.kickForMcLeaks(Objects.requireNonNull(player.getName()), player.getUuid(), ip);
    }

    default public boolean kickForMcLeaks(@NonNull String playerName, @NonNull UUID playerUuid, @NonNull InetAddress ip) {
        return this.kickForMcLeaks(playerName, playerUuid, ip.getHostAddress());
    }

    public boolean kickForMcLeaks(@NonNull String var1, @NonNull UUID var2, @NonNull String var3);

    default public @Nullable String getMcLeaksKickMessage(@NonNull Player player, @NonNull IP ip) {
        return this.getMcLeaksKickMessage(Objects.requireNonNull(player.getName()), player.getUuid(), ip.getIP().getHostAddress());
    }

    default public @Nullable String getMcLeaksKickMessage(@NonNull String playerName, @NonNull UUID playerUuid, @NonNull IP ip) {
        return this.getMcLeaksKickMessage(playerName, playerUuid, ip.getIP().getHostAddress());
    }

    default public @Nullable String getMcLeaksKickMessage(@NonNull Player player, @NonNull InetAddress ip) {
        return this.getMcLeaksKickMessage(Objects.requireNonNull(player.getName()), player.getUuid(), ip.getHostAddress());
    }

    default public @Nullable String getMcLeaksKickMessage(@NonNull Player player, @NonNull String ip) {
        return this.getMcLeaksKickMessage(Objects.requireNonNull(player.getName()), player.getUuid(), ip);
    }

    default public @Nullable String getMcLeaksKickMessage(@NonNull String playerName, @NonNull UUID playerUuid, @NonNull InetAddress ip) {
        return this.getMcLeaksKickMessage(playerName, playerUuid, ip.getHostAddress());
    }

    public @Nullable String getMcLeaksKickMessage(@NonNull String var1, @NonNull UUID var2, @NonNull String var3);

    default public @NonNull List<String> getMcLeaksCommands(@NonNull Player player, @NonNull IP ip) {
        return this.getMcLeaksCommands(Objects.requireNonNull(player.getName()), player.getUuid(), ip.getIP().getHostAddress());
    }

    default public @NonNull List<String> getMcLeaksCommands(@NonNull String playerName, @NonNull UUID playerUuid, @NonNull IP ip) {
        return this.getMcLeaksCommands(playerName, playerUuid, ip.getIP().getHostAddress());
    }

    default public @NonNull List<String> getMcLeaksCommands(@NonNull Player player, @NonNull InetAddress ip) {
        return this.getMcLeaksCommands(Objects.requireNonNull(player.getName()), player.getUuid(), ip.getHostAddress());
    }

    default public @NonNull List<String> getMcLeaksCommands(@NonNull Player player, @NonNull String ip) {
        return this.getMcLeaksCommands(Objects.requireNonNull(player.getName()), player.getUuid(), ip);
    }

    default public @NonNull List<String> getMcLeaksCommands(@NonNull String playerName, @NonNull UUID playerUuid, @NonNull InetAddress ip) {
        return this.getMcLeaksCommands(playerName, playerUuid, ip.getHostAddress());
    }

    public @NonNull List<String> getMcLeaksCommands(@NonNull String var1, @NonNull UUID var2, @NonNull String var3);
}

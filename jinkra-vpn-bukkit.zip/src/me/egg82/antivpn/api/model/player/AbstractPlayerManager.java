/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  me.egg82.antivpn.external.com.github.benmanes.caffeine.cache.Caffeine
 *  me.egg82.antivpn.external.com.github.benmanes.caffeine.cache.LoadingCache
 */
package me.egg82.antivpn.api.model.player;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.TimeUnit;
import me.egg82.antivpn.api.APIException;
import me.egg82.antivpn.api.model.player.Player;
import me.egg82.antivpn.api.model.player.PlayerManager;
import me.egg82.antivpn.config.CachedConfig;
import me.egg82.antivpn.config.ConfigUtil;
import me.egg82.antivpn.external.com.github.benmanes.caffeine.cache.Caffeine;
import me.egg82.antivpn.external.com.github.benmanes.caffeine.cache.LoadingCache;
import me.egg82.antivpn.messaging.packets.DeletePlayerPacket;
import me.egg82.antivpn.messaging.packets.PlayerPacket;
import me.egg82.antivpn.storage.StorageService;
import me.egg82.antivpn.storage.models.PlayerModel;
import me.egg82.antivpn.utils.PacketUtil;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class AbstractPlayerManager
implements PlayerManager {
    protected final Logger logger = LoggerFactory.getLogger(this.getClass());
    protected final LoadingCache<UUID, PlayerModel> playerCache;

    protected AbstractPlayerManager(long cacheTime, TimeUnit cacheTimeUnit) {
        this.playerCache = Caffeine.newBuilder().expireAfterAccess(cacheTime, cacheTimeUnit).expireAfterWrite(cacheTime, cacheTimeUnit).build(k -> this.calculatePlayerResult((UUID)k, true));
    }

    public LoadingCache<UUID, PlayerModel> getPlayerCache() {
        return this.playerCache;
    }

    @Override
    public @NonNull CompletableFuture<Void> savePlayer(@NonNull Player player) {
        return CompletableFuture.runAsync(() -> {
            CachedConfig cachedConfig = ConfigUtil.getCachedConfig();
            if (cachedConfig == null) {
                throw new APIException(false, "Cached config could not be fetched.");
            }
            for (StorageService service : cachedConfig.getStorage()) {
                PlayerModel model = service.getOrCreatePlayerModel(player.getUuid(), player.isMcLeaks());
                service.storeModel(model);
            }
            PlayerPacket packet = new PlayerPacket();
            packet.setUuid(player.getUuid());
            packet.setValue(player.isMcLeaks());
            PacketUtil.queuePacket(packet);
        });
    }

    @Override
    public @NonNull CompletableFuture<Void> deletePlayer(@NonNull UUID uniqueId) {
        return CompletableFuture.runAsync(() -> {
            CachedConfig cachedConfig = ConfigUtil.getCachedConfig();
            if (cachedConfig == null) {
                throw new APIException(false, "Cached config could not be fetched.");
            }
            for (StorageService service : cachedConfig.getStorage()) {
                PlayerModel model = new PlayerModel();
                model.setUuid(uniqueId);
                service.deleteModel(model);
            }
            DeletePlayerPacket packet = new DeletePlayerPacket();
            packet.setUuid(uniqueId);
            PacketUtil.queuePacket(packet);
        });
    }

    @Override
    public @NonNull CompletableFuture<Set<UUID>> getPlayers() {
        return CompletableFuture.supplyAsync(() -> {
            CachedConfig cachedConfig = ConfigUtil.getCachedConfig();
            if (cachedConfig == null) {
                throw new APIException(false, "Cached config could not be fetched.");
            }
            HashSet<UUID> retVal = new HashSet<UUID>();
            for (StorageService service : cachedConfig.getStorage()) {
                Set<PlayerModel> models = service.getAllPlayers(cachedConfig.getSourceCacheTime());
                if (models == null || models.isEmpty()) continue;
                for (PlayerModel model : models) {
                    retVal.add(model.getUuid());
                }
            }
            return retVal;
        });
    }

    @Override
    public @NonNull CompletableFuture<Boolean> checkMcLeaks(@NonNull UUID uniqueId, boolean useCache) throws APIException {
        return CompletableFuture.supplyAsync(() -> {
            PlayerModel model;
            if (useCache) {
                try {
                    model = (PlayerModel)this.playerCache.get((Object)uniqueId);
                }
                catch (CompletionException ex) {
                    if (ex.getCause() instanceof APIException) {
                        throw (APIException)ex.getCause();
                    }
                    throw new APIException(false, "Could not get data for player " + uniqueId, ex);
                }
                catch (Error | RuntimeException ex) {
                    throw new APIException(false, "Could not get data for player " + uniqueId, ex);
                }
            } else {
                model = this.calculatePlayerResult(uniqueId, false);
            }
            if (model == null) {
                throw new APIException(false, "Could not get data for player " + uniqueId);
            }
            return model.isMcleaks();
        });
    }

    protected abstract @NonNull PlayerModel calculatePlayerResult(@NonNull UUID var1, boolean var2) throws APIException;
}

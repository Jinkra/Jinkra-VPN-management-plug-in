/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.api.model.source;

import flexjson.JSONDeserializer;
import java.net.HttpURLConnection;
import java.util.concurrent.CompletableFuture;
import me.egg82.antivpn.api.APIException;
import me.egg82.antivpn.api.model.source.AbstractSource;
import me.egg82.antivpn.api.model.source.models.VPNBlockerModel;
import me.egg82.antivpn.external.org.spongepowered.configurate.ConfigurationNode;
import me.egg82.antivpn.utils.ValidationUtil;
import org.checkerframework.checker.nullness.qual.NonNull;

public class VPNBlocker
extends AbstractSource<VPNBlockerModel> {
    @Override
    public @NonNull String getName() {
        return "vpnblocker";
    }

    @Override
    public boolean isKeyRequired() {
        return false;
    }

    public VPNBlocker() {
        super(VPNBlockerModel.class);
    }

    @Override
    public @NonNull CompletableFuture<Boolean> getResult(@NonNull String ip) {
        return this.getRawResponse(ip).thenApply(model -> {
            if (!"success".equalsIgnoreCase(model.getStatus())) {
                throw new APIException(model.getMsg().contains("key"), "Could not get result from " + this.getName() + " (" + model.getMsg() + ")");
            }
            return model.isHost();
        });
    }

    @Override
    public @NonNull CompletableFuture<VPNBlockerModel> getRawResponse(@NonNull String ip) {
        return CompletableFuture.supplyAsync(() -> {
            if (!ValidationUtil.isValidIp(ip)) {
                throw new IllegalArgumentException("ip is invalid.");
            }
            ConfigurationNode sourceConfigNode = this.getSourceConfigNode();
            String key = sourceConfigNode.node("key").getString();
            HttpURLConnection conn = this.getConnection("http" + (key != null && !key.isEmpty() ? "s" : "") + "://api.vpnblocker.net/v2/json/" + ip + (key != null && !key.isEmpty() ? "/" + key : ""), "GET", (int)this.getCachedConfig().getTimeout(), "egg82/AntiVPN", headers);
            JSONDeserializer modelDeserializer = new JSONDeserializer();
            return (VPNBlockerModel)modelDeserializer.deserialize(this.getString(conn), VPNBlockerModel.class);
        });
    }
}

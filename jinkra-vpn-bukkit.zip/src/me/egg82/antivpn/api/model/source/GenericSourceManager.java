/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 */
package me.egg82.antivpn.api.model.source;

import com.google.common.collect.ImmutableList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import me.egg82.antivpn.api.VPNAPI;
import me.egg82.antivpn.api.VPNAPIProvider;
import me.egg82.antivpn.api.event.source.GenericSourceDeregisterEvent;
import me.egg82.antivpn.api.event.source.GenericSourceRegisterEvent;
import me.egg82.antivpn.api.event.type.Cancellable;
import me.egg82.antivpn.api.model.source.Source;
import me.egg82.antivpn.api.model.source.SourceManager;
import me.egg82.antivpn.api.model.source.models.SourceModel;
import net.engio.mbassy.bus.IMessagePublication;
import net.engio.mbassy.bus.publication.SyncAsyncPostCommand;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.checkerframework.checker.nullness.qual.Nullable;

public class GenericSourceManager
implements SourceManager {
    private final List<Source<? extends SourceModel>> sources = new CopyOnWriteArrayList<Source<? extends SourceModel>>();
    private final Object sourceLock = new Object();

    @Override
    public @Nullable Source<? extends SourceModel> getSource(@NonNull String name) {
        for (Source<? extends SourceModel> source : this.sources) {
            if (!source.getName().equals(name)) continue;
            return source;
        }
        return null;
    }

    @Override
    public <T extends SourceModel> @Nullable Source<T> getSource(@NonNull String name, @NonNull Class<T> modelClass) {
        for (Source<? extends SourceModel> source : this.sources) {
            if (!source.getName().equals(name) || !source.getModelClass().isAssignableFrom(modelClass)) continue;
            return source;
        }
        return null;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public boolean registerSource(@NonNull Source<? extends SourceModel> source, int index) {
        Object object = this.sourceLock;
        synchronized (object) {
            for (Source<? extends SourceModel> s : this.sources) {
                if (!s.getName().equals(source.getName())) continue;
                return false;
            }
            try {
                VPNAPI api = VPNAPIProvider.getInstance();
                IMessagePublication publication = ((SyncAsyncPostCommand)api.getEventBus().post((Object)new GenericSourceRegisterEvent(api, source))).now();
                if (!publication.isDeadMessage() && ((Cancellable)publication.getMessage()).isCancelled()) {
                    return false;
                }
            }
            catch (IllegalStateException illegalStateException) {
                // empty catch block
            }
            this.sources.add(index, source);
            return true;
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public boolean deregisterSource(@NonNull Source<? extends SourceModel> source) {
        Object object = this.sourceLock;
        synchronized (object) {
            Iterator<Source<? extends SourceModel>> i = this.sources.iterator();
            while (i.hasNext()) {
                Source<? extends SourceModel> s = i.next();
                if (!s.getName().equals(source.getName())) continue;
                try {
                    VPNAPI api = VPNAPIProvider.getInstance();
                    IMessagePublication publication = ((SyncAsyncPostCommand)api.getEventBus().post((Object)new GenericSourceDeregisterEvent(api, source))).now();
                    if (!publication.isDeadMessage() && ((Cancellable)publication.getMessage()).isCancelled()) {
                        return false;
                    }
                }
                catch (IllegalStateException illegalStateException) {
                    // empty catch block
                }
                i.remove();
                return true;
            }
            return false;
        }
    }

    @Override
    public @NonNull List<Source<? extends SourceModel>> getSources() {
        return ImmutableList.copyOf(this.sources);
    }
}

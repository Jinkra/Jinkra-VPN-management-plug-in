/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.api.model.source;

import flexjson.JSONDeserializer;
import java.net.HttpURLConnection;
import java.util.concurrent.CompletableFuture;
import me.egg82.antivpn.api.APIException;
import me.egg82.antivpn.api.model.source.AbstractSource;
import me.egg82.antivpn.api.model.source.models.ShodanModel;
import me.egg82.antivpn.external.org.spongepowered.configurate.ConfigurationNode;
import me.egg82.antivpn.utils.ValidationUtil;
import org.checkerframework.checker.nullness.qual.NonNull;

public class Shodan
extends AbstractSource<ShodanModel> {
    @Override
    public @NonNull String getName() {
        return "shodan";
    }

    @Override
    public boolean isKeyRequired() {
        return true;
    }

    public Shodan() {
        super(ShodanModel.class);
    }

    @Override
    public @NonNull CompletableFuture<Boolean> getResult(@NonNull String ip) {
        return this.getRawResponse(ip).thenApply(model -> {
            if (model.getError() != null) {
                throw new APIException(model.getError().contains("key"), "Could not get result from " + this.getName() + " (" + model.getError() + ")");
            }
            if (model.getTags() == null || model.getTags().isEmpty()) {
                return false;
            }
            for (String tag : model.getTags()) {
                if (!"proxy".equalsIgnoreCase(tag) && !"vpn".equalsIgnoreCase(tag)) continue;
                return true;
            }
            return false;
        });
    }

    @Override
    public @NonNull CompletableFuture<ShodanModel> getRawResponse(@NonNull String ip) {
        return CompletableFuture.supplyAsync(() -> {
            if (!ValidationUtil.isValidIp(ip)) {
                throw new IllegalArgumentException("ip is invalid.");
            }
            ConfigurationNode sourceConfigNode = this.getSourceConfigNode();
            String key = sourceConfigNode.node("key").getString();
            if (key == null || key.isEmpty()) {
                throw new APIException(true, "Key is not defined for " + this.getName());
            }
            HttpURLConnection conn = this.getConnection("https://api.shodan.io/shodan/host/" + ip + "?minify=true&key=" + key, "GET", (int)this.getCachedConfig().getTimeout(), "egg82/AntiVPN", headers);
            JSONDeserializer modelDeserializer = new JSONDeserializer();
            return (ShodanModel)modelDeserializer.deserialize(this.getString(conn), ShodanModel.class);
        });
    }
}

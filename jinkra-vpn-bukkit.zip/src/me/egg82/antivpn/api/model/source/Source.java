/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.api.model.source;

import java.net.InetAddress;
import java.util.concurrent.CompletableFuture;
import me.egg82.antivpn.api.model.ip.IP;
import me.egg82.antivpn.api.model.source.models.SourceModel;
import org.checkerframework.checker.nullness.qual.NonNull;

public interface Source<T extends SourceModel> {
    public @NonNull String getName();

    public boolean isKeyRequired();

    default public @NonNull CompletableFuture<Boolean> getResult(@NonNull IP ip) {
        return this.getResult(ip.getIP().getHostAddress());
    }

    default public @NonNull CompletableFuture<Boolean> getResult(@NonNull InetAddress ip) {
        return this.getResult(ip.getHostAddress());
    }

    public @NonNull CompletableFuture<Boolean> getResult(@NonNull String var1);

    default public @NonNull CompletableFuture<T> getRawResponse(@NonNull IP ip) {
        return this.getRawResponse(ip.getIP().getHostAddress());
    }

    default public @NonNull CompletableFuture<T> getRawResponse(@NonNull InetAddress ip) {
        return this.getRawResponse(ip.getHostAddress());
    }

    public @NonNull CompletableFuture<T> getRawResponse(@NonNull String var1);

    public @NonNull Class<T> getModelClass();
}

/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.api.model.source;

import flexjson.JSONDeserializer;
import java.net.HttpURLConnection;
import java.util.concurrent.CompletableFuture;
import me.egg82.antivpn.api.APIException;
import me.egg82.antivpn.api.model.source.AbstractSource;
import me.egg82.antivpn.api.model.source.models.IP2ProxyModel;
import me.egg82.antivpn.external.org.spongepowered.configurate.ConfigurationNode;
import me.egg82.antivpn.utils.ValidationUtil;
import org.checkerframework.checker.nullness.qual.NonNull;

public class IP2Proxy
extends AbstractSource<IP2ProxyModel> {
    @Override
    public @NonNull String getName() {
        return "ip2proxy";
    }

    @Override
    public boolean isKeyRequired() {
        return true;
    }

    public IP2Proxy() {
        super(IP2ProxyModel.class);
    }

    @Override
    public @NonNull CompletableFuture<Boolean> getResult(@NonNull String ip) {
        return this.getRawResponse(ip).thenApply(model -> {
            if (!"OK".equalsIgnoreCase(model.getResponse())) {
                throw new APIException(false, "Could not get result from " + this.getName() + " (" + model.getResponse() + ")");
            }
            return "YES".equalsIgnoreCase(model.getProxy());
        });
    }

    @Override
    public @NonNull CompletableFuture<IP2ProxyModel> getRawResponse(@NonNull String ip) {
        return CompletableFuture.supplyAsync(() -> {
            if (!ValidationUtil.isValidIp(ip)) {
                throw new IllegalArgumentException("ip is invalid.");
            }
            ConfigurationNode sourceConfigNode = this.getSourceConfigNode();
            String key = sourceConfigNode.node("key").getString();
            if (key == null || key.isEmpty()) {
                throw new APIException(true, "Key is not defined for " + this.getName());
            }
            HttpURLConnection conn = this.getConnection("https://api.ip2proxy.com/?ip=" + ip + "&key=" + key + "&package=PX1&format=json", "GET", (int)this.getCachedConfig().getTimeout(), "egg82/AntiVPN", headers);
            JSONDeserializer modelDeserializer = new JSONDeserializer();
            return (IP2ProxyModel)modelDeserializer.deserialize(this.getString(conn), IP2ProxyModel.class);
        });
    }
}

/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.api.model.source;

import flexjson.JSONDeserializer;
import java.net.HttpURLConnection;
import java.util.concurrent.CompletableFuture;
import me.egg82.antivpn.api.APIException;
import me.egg82.antivpn.api.model.source.AbstractSource;
import me.egg82.antivpn.api.model.source.models.IPInfoModel;
import me.egg82.antivpn.external.org.spongepowered.configurate.ConfigurationNode;
import me.egg82.antivpn.utils.ValidationUtil;
import org.checkerframework.checker.nullness.qual.NonNull;

public class IPInfo
extends AbstractSource<IPInfoModel> {
    @Override
    public @NonNull String getName() {
        return "ipinfo";
    }

    @Override
    public boolean isKeyRequired() {
        return true;
    }

    public IPInfo() {
        super(IPInfoModel.class);
    }

    @Override
    public @NonNull CompletableFuture<Boolean> getResult(@NonNull String ip) {
        return this.getRawResponse(ip).thenApply(model -> {
            if (model.getError() != null) {
                throw new APIException(model.getError().getMessage().contains("token"), "Could not get result from " + this.getName() + " (" + model.getError().getMessage() + ")");
            }
            ConfigurationNode sourceConfigNode = this.getSourceConfigNode();
            if (sourceConfigNode.node("proxy").getBoolean(true) && model.isProxy()) {
                return true;
            }
            return model.isTor() || model.isVpn();
        });
    }

    @Override
    public @NonNull CompletableFuture<IPInfoModel> getRawResponse(@NonNull String ip) {
        return CompletableFuture.supplyAsync(() -> {
            if (!ValidationUtil.isValidIp(ip)) {
                throw new IllegalArgumentException("ip is invalid.");
            }
            ConfigurationNode sourceConfigNode = this.getSourceConfigNode();
            String key = sourceConfigNode.node("key").getString();
            if (key == null || key.isEmpty()) {
                throw new APIException(true, "Key is not defined for " + this.getName());
            }
            HttpURLConnection conn = this.getConnection("https://ipinfo.io/" + ip + "/privacy?token=" + key, "GET", (int)this.getCachedConfig().getTimeout(), "egg82/AntiVPN", headers);
            JSONDeserializer modelDeserializer = new JSONDeserializer();
            return (IPInfoModel)modelDeserializer.deserialize(this.getString(conn), IPInfoModel.class);
        });
    }
}

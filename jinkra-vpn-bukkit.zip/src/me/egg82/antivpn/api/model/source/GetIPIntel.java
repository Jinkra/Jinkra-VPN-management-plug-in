/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.google.common.util.concurrent.ThreadFactoryBuilder
 */
package me.egg82.antivpn.api.model.source;

import com.google.common.util.concurrent.ThreadFactoryBuilder;
import flexjson.JSONDeserializer;
import java.net.HttpURLConnection;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import me.egg82.antivpn.api.APIException;
import me.egg82.antivpn.api.model.source.AbstractSource;
import me.egg82.antivpn.api.model.source.models.GetIPIntelModel;
import me.egg82.antivpn.external.org.spongepowered.configurate.ConfigurationNode;
import me.egg82.antivpn.utils.ValidationUtil;
import org.checkerframework.checker.nullness.qual.NonNull;

public class GetIPIntel
extends AbstractSource<GetIPIntelModel> {
    private static final AtomicInteger hourlyRequests = new AtomicInteger(0);
    private static final AtomicInteger minuteRequests = new AtomicInteger(0);
    private static final ScheduledExecutorService threadPool = Executors.newSingleThreadScheduledExecutor(new ThreadFactoryBuilder().setNameFormat("AntiVPN-GetIPIntel-%d").build());

    public GetIPIntel() {
        super(GetIPIntelModel.class);
    }

    @Override
    public @NonNull String getName() {
        return "getipintel";
    }

    @Override
    public boolean isKeyRequired() {
        return false;
    }

    @Override
    public @NonNull CompletableFuture<Boolean> getResult(@NonNull String ip) {
        return this.getRawResponse(ip).thenApply(model -> {
            if (!"success".equalsIgnoreCase(model.getStatus())) {
                boolean isHard = "-5".equals(model.getResult()) || "-6".equals(model.getResult());
                throw new APIException(isHard, "Could not get result from " + this.getName() + " (" + model.getResult() + ": " + model.getMessage() + ")" + (isHard ? " (Is your server's IP banned due to an improper contact e-mail in the config? Send an e-mail to contact@getipintel.net for an unban)" : ""));
            }
            ConfigurationNode sourceConfigNode = this.getSourceConfigNode();
            double retVal = Double.parseDouble(model.getResult());
            return retVal >= sourceConfigNode.node("threshold").getDouble(0.98);
        });
    }

    @Override
    public @NonNull CompletableFuture<GetIPIntelModel> getRawResponse(@NonNull String ip) {
        return CompletableFuture.supplyAsync(() -> {
            if (!ValidationUtil.isValidIp(ip)) {
                throw new IllegalArgumentException("ip is invalid.");
            }
            ConfigurationNode sourceConfigNode = this.getSourceConfigNode();
            if ("admin@yoursite.com".equalsIgnoreCase(sourceConfigNode.node("contact").getString("admin@yoursite.com"))) {
                throw new APIException(true, "Contact is not defined for " + this.getName() + " (WARNING: USING AN INVALID E-MAIL FOR THE CONTACT WILL GET YOUR IP BANNED FROM THE SERVICE)");
            }
            if (hourlyRequests.getAndIncrement() >= 500) {
                throw new APIException(false, "API calls to this source have been limited to 500/day as per request.");
            }
            if (minuteRequests.getAndIncrement() >= 15) {
                throw new APIException(false, "API calls to this source have been limited to 15/minute as per request.");
            }
            HttpURLConnection conn = this.getConnection("https://" + sourceConfigNode.node("subdomain").getString("check") + ".getipintel.net/check.php?ip=" + ip + "&contact=" + sourceConfigNode.node("contact").getString("admin@yoursite.com") + "&format=json&flags=b", "GET", (int)this.getCachedConfig().getTimeout(), "egg82/AntiVPN", headers);
            JSONDeserializer modelDeserializer = new JSONDeserializer();
            return (GetIPIntelModel)modelDeserializer.deserialize(this.getString(conn), GetIPIntelModel.class);
        });
    }

    static {
        threadPool.scheduleAtFixedRate(() -> hourlyRequests.set(0), 0L, 24L, TimeUnit.HOURS);
        threadPool.scheduleAtFixedRate(() -> minuteRequests.set(0), 0L, 1L, TimeUnit.MINUTES);
    }
}

/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.api.model.source;

import flexjson.JSONDeserializer;
import flexjson.JSONSerializer;
import java.net.HttpURLConnection;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import me.egg82.antivpn.api.APIException;
import me.egg82.antivpn.api.model.source.AbstractSource;
import me.egg82.antivpn.api.model.source.models.ProxyCheckModel;
import me.egg82.antivpn.external.org.spongepowered.configurate.ConfigurationNode;
import me.egg82.antivpn.utils.ValidationUtil;
import org.checkerframework.checker.nullness.qual.NonNull;

public class ProxyCheck
extends AbstractSource<ProxyCheckModel> {
    @Override
    public @NonNull String getName() {
        return "proxycheck";
    }

    @Override
    public boolean isKeyRequired() {
        return false;
    }

    public ProxyCheck() {
        super(ProxyCheckModel.class);
    }

    @Override
    public @NonNull CompletableFuture<Boolean> getResult(@NonNull String ip) {
        return this.getRawResponse(ip).thenApply(model -> {
            if (!"ok".equalsIgnoreCase(model.getStatus())) {
                throw new APIException(model.getMessage().contains("Key"), "Could not get result from " + this.getName() + " (" + model.getMessage() + ")");
            }
            return "yes".equalsIgnoreCase(model.getIp().getProxy());
        });
    }

    @Override
    public @NonNull CompletableFuture<ProxyCheckModel> getRawResponse(@NonNull String ip) {
        return CompletableFuture.supplyAsync(() -> {
            if (!ValidationUtil.isValidIp(ip)) {
                throw new IllegalArgumentException("ip is invalid.");
            }
            ConfigurationNode sourceConfigNode = this.getSourceConfigNode();
            String key = sourceConfigNode.node("key").getString();
            HttpURLConnection conn = this.getConnection("https://proxycheck.io/v2/" + ip + "?vpn=1" + (key != null && !key.isEmpty() ? "&key=" + key : ""), "GET", (int)this.getCachedConfig().getTimeout(), "egg82/AntiVPN", headers);
            String str = this.getString(conn);
            JSONDeserializer mapDeserializer = new JSONDeserializer();
            Map map = (Map)mapDeserializer.deserialize(str);
            ProxyCheckModel.IP ipModel = null;
            if (map.containsKey(ip)) {
                JSONDeserializer ipModelDeserializer = new JSONDeserializer();
                ipModel = (ProxyCheckModel.IP)ipModelDeserializer.deserialize(new JSONSerializer().exclude("*.class").deepSerialize(map.get(ip)), ProxyCheckModel.IP.class);
            }
            JSONDeserializer modelDeserializer = new JSONDeserializer();
            ProxyCheckModel model = (ProxyCheckModel)modelDeserializer.deserialize(str, ProxyCheckModel.class);
            model.setIp(ipModel);
            return model;
        });
    }
}

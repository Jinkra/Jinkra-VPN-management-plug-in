/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.api.model.source;

import flexjson.JSONDeserializer;
import java.net.HttpURLConnection;
import java.util.HashMap;
import java.util.concurrent.CompletableFuture;
import me.egg82.antivpn.api.APIException;
import me.egg82.antivpn.api.model.source.AbstractSource;
import me.egg82.antivpn.api.model.source.models.IPHubModel;
import me.egg82.antivpn.external.org.spongepowered.configurate.ConfigurationNode;
import me.egg82.antivpn.utils.ValidationUtil;
import org.checkerframework.checker.nullness.qual.NonNull;

public class IPHub
extends AbstractSource<IPHubModel> {
    @Override
    public @NonNull String getName() {
        return "iphub";
    }

    @Override
    public boolean isKeyRequired() {
        return true;
    }

    public IPHub() {
        super(IPHubModel.class);
    }

    @Override
    public @NonNull CompletableFuture<Boolean> getResult(@NonNull String ip) {
        return this.getRawResponse(ip).thenApply(model -> {
            if (model.getError() != null) {
                throw new APIException(model.getError().contains("key"), "Could not get result from " + this.getName() + " (" + model.getError() + ")");
            }
            return model.getBlock() == this.getSourceConfigNode().node("block").getInt(1);
        });
    }

    @Override
    public @NonNull CompletableFuture<IPHubModel> getRawResponse(@NonNull String ip) {
        return CompletableFuture.supplyAsync(() -> {
            if (!ValidationUtil.isValidIp(ip)) {
                throw new IllegalArgumentException("ip is invalid.");
            }
            ConfigurationNode sourceConfigNode = this.getSourceConfigNode();
            String key = sourceConfigNode.node("key").getString();
            if (key == null || key.isEmpty()) {
                throw new APIException(true, "Key is not defined for " + this.getName());
            }
            HashMap<String, String> newHeaders = new HashMap<String, String>(headers);
            newHeaders.put("X-Key", key);
            HttpURLConnection conn = this.getConnection("https://v2.api.iphub.info/ip/" + ip, "GET", (int)this.getCachedConfig().getTimeout(), "egg82/AntiVPN", newHeaders);
            JSONDeserializer modelDeserializer = new JSONDeserializer();
            return (IPHubModel)modelDeserializer.deserialize(this.getString(conn), IPHubModel.class);
        });
    }
}

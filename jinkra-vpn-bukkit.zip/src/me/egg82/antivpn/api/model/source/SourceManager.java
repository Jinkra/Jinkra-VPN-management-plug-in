/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.api.model.source;

import java.util.List;
import me.egg82.antivpn.api.model.source.Source;
import me.egg82.antivpn.api.model.source.models.SourceModel;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.checkerframework.checker.nullness.qual.Nullable;

public interface SourceManager {
    public @Nullable Source<? extends SourceModel> getSource(@NonNull String var1);

    public <T extends SourceModel> @Nullable Source<T> getSource(@NonNull String var1, @NonNull Class<T> var2);

    default public boolean replaceSource(@NonNull Source<? extends SourceModel> newSource) {
        List<Source<? extends SourceModel>> sources = this.getSources();
        int index = -1;
        Source<? extends SourceModel> removedSource = null;
        for (int i = 0; i < sources.size(); ++i) {
            if (!sources.get(i).getName().equals(newSource.getName())) continue;
            index = i;
            removedSource = sources.get(i);
            break;
        }
        if (index == -1 || removedSource == null || !this.deregisterSource(removedSource)) {
            return false;
        }
        return this.registerSource(newSource, index);
    }

    default public boolean registerSource(@NonNull Source<? extends SourceModel> source) {
        return this.registerSource(source, this.getSources().size());
    }

    public boolean registerSource(@NonNull Source<? extends SourceModel> var1, int var2);

    public boolean deregisterSource(@NonNull Source<? extends SourceModel> var1);

    default public boolean deregisterSource(@NonNull String sourceName) {
        List<Source<? extends SourceModel>> sources = this.getSources();
        Source<? extends SourceModel> removedSource = null;
        for (Source<? extends SourceModel> source : sources) {
            if (!source.getName().equals(sourceName)) continue;
            removedSource = source;
            break;
        }
        if (removedSource != null) {
            return this.deregisterSource(removedSource);
        }
        return false;
    }

    public @NonNull List<Source<? extends SourceModel>> getSources();
}

/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.api.model.source;

import flexjson.JSONDeserializer;
import java.net.HttpURLConnection;
import java.util.concurrent.CompletableFuture;
import me.egg82.antivpn.api.APIException;
import me.egg82.antivpn.api.model.source.AbstractSource;
import me.egg82.antivpn.api.model.source.models.IPTrooperModel;
import me.egg82.antivpn.utils.ValidationUtil;
import org.checkerframework.checker.nullness.qual.NonNull;

public class IPTrooper
extends AbstractSource<IPTrooperModel> {
    @Override
    public @NonNull String getName() {
        return "iptrooper";
    }

    @Override
    public boolean isKeyRequired() {
        return false;
    }

    public IPTrooper() {
        super(IPTrooperModel.class);
    }

    @Override
    public @NonNull CompletableFuture<Boolean> getResult(@NonNull String ip) {
        return this.getRawResponse(ip).thenApply(model -> {
            if (model.getCode() == 3) {
                throw new APIException(false, "Could not get result from " + this.getName() + " (Request limit reached)");
            }
            return model.isBad();
        });
    }

    @Override
    public @NonNull CompletableFuture<IPTrooperModel> getRawResponse(@NonNull String ip) {
        return CompletableFuture.supplyAsync(() -> {
            if (!ValidationUtil.isValidIp(ip)) {
                throw new IllegalArgumentException("ip is invalid.");
            }
            HttpURLConnection conn = this.getConnection("https://api.iptrooper.net/check/" + ip + "?full=1", "GET", (int)this.getCachedConfig().getTimeout(), "egg82/AntiVPN", headers);
            JSONDeserializer modelDeserializer = new JSONDeserializer();
            return (IPTrooperModel)modelDeserializer.deserialize(this.getString(conn), IPTrooperModel.class);
        });
    }
}

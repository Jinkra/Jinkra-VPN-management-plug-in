/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.api.event;

import me.egg82.antivpn.api.VPNAPI;
import org.checkerframework.checker.nullness.qual.NonNull;

public interface VPNEvent {
    public @NonNull VPNAPI getApi();

    public @NonNull Class<? extends VPNEvent> getEventType();
}

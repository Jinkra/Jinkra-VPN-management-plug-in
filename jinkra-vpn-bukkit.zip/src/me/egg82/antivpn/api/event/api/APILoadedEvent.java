/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.api.event.api;

public interface APILoadedEvent {
}

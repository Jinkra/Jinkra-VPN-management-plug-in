/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.api.event.api;

import me.egg82.antivpn.api.event.VPNEvent;

public interface APIDisableEvent
extends VPNEvent {
}

/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.api.event.api;

import me.egg82.antivpn.api.model.ip.IPManager;
import me.egg82.antivpn.api.model.player.PlayerManager;
import me.egg82.antivpn.api.model.source.SourceManager;
import org.checkerframework.checker.nullness.qual.NonNull;

public interface APIReloadEvent {
    public @NonNull IPManager getNewIPManager();

    public @NonNull PlayerManager getNewPlayerManager();

    public @NonNull SourceManager getNewSourceManager();
}

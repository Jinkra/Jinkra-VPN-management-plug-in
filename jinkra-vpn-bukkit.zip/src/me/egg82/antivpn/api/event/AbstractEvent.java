/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.api.event;

import me.egg82.antivpn.api.VPNAPI;
import me.egg82.antivpn.api.event.VPNEvent;
import org.checkerframework.checker.nullness.qual.NonNull;

public abstract class AbstractEvent
implements VPNEvent {
    protected final VPNAPI api;
    private final Class<? extends VPNEvent> clazz;

    protected AbstractEvent(@NonNull VPNAPI api) {
        this.api = api;
        this.clazz = this.getClass();
    }

    @Override
    public @NonNull VPNAPI getApi() {
        return this.api;
    }

    @Override
    public @NonNull Class<? extends VPNEvent> getEventType() {
        return this.clazz;
    }
}

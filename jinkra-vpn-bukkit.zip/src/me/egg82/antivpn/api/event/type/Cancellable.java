/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.api.event.type;

import java.util.concurrent.atomic.AtomicBoolean;
import org.checkerframework.checker.nullness.qual.NonNull;

public interface Cancellable {
    public @NonNull AtomicBoolean cancellationState();

    default public boolean isCancelled() {
        return this.cancellationState().get();
    }

    default public boolean isNotCancelled() {
        return !this.cancellationState().get();
    }

    default public boolean setCancelled(boolean cancelled) {
        return this.cancellationState().getAndSet(cancelled);
    }
}

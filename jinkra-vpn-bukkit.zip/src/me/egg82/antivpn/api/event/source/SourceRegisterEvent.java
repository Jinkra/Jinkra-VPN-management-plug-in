/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.api.event.source;

import me.egg82.antivpn.api.event.VPNEvent;
import me.egg82.antivpn.api.event.type.Cancellable;
import me.egg82.antivpn.api.model.source.Source;
import me.egg82.antivpn.api.model.source.models.SourceModel;
import org.checkerframework.checker.nullness.qual.NonNull;

public interface SourceRegisterEvent
extends VPNEvent,
Cancellable {
    public @NonNull Source<? extends SourceModel> getSource();
}

/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.api;

import me.egg82.antivpn.api.VPNAPI;
import org.checkerframework.checker.nullness.qual.NonNull;

public final class VPNAPIProvider {
    private static VPNAPI instance = null;

    private VPNAPIProvider() {
    }

    public static @NonNull VPNAPI getInstance() {
        VPNAPI i = instance;
        if (i == null) {
            throw new IllegalStateException("VPNAPI is not loaded.");
        }
        return i;
    }

    private static void register(@NonNull VPNAPI instance) {
        VPNAPIProvider.instance = instance;
    }

    private static void deregister() {
        instance = null;
    }
}

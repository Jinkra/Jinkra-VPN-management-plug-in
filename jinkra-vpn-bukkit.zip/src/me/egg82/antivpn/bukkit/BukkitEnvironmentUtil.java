/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.bukkit;

import org.checkerframework.checker.nullness.qual.NonNull;

public class BukkitEnvironmentUtil {
    private static Environment environment;

    private BukkitEnvironmentUtil() {
    }

    public static @NonNull Environment getEnvironment() {
        return environment;
    }

    static {
        try {
            Class.forName("com.destroystokyo.paper.PaperConfig");
            environment = Environment.PAPER;
        }
        catch (ClassNotFoundException e) {
            try {
                Class.forName("org.spigotmc.SpigotConfig");
                environment = Environment.SPIGOT;
            }
            catch (ClassNotFoundException e1) {
                environment = Environment.BUKKIT;
            }
        }
    }

    public static enum Environment {
        PAPER,
        SPIGOT,
        BUKKIT;

    }
}

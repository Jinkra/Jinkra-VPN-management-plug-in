/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.bukkit;

public static enum BukkitEnvironmentUtil.Environment {
    PAPER,
    SPIGOT,
    BUKKIT;

}

/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 */
package me.egg82.antivpn.bukkit;

import me.egg82.antivpn.utils.VersionUtil;
import org.bukkit.Bukkit;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.checkerframework.checker.nullness.qual.Nullable;

public class BukkitVersionUtil {
    private static final Object versionLock = new Object();
    private static String gameVersion = null;

    private BukkitVersionUtil() {
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static @NonNull String getGameVersion() {
        String localVersion = gameVersion;
        if (localVersion == null) {
            Object object = versionLock;
            synchronized (object) {
                localVersion = gameVersion;
                if (localVersion == null) {
                    localVersion = BukkitVersionUtil.getVersionFromVersionString(Bukkit.getVersion());
                    if (!(localVersion != null && BukkitVersionUtil.isVersion(localVersion) || (localVersion = BukkitVersionUtil.getVersionFromBukkitString(Bukkit.getBukkitVersion())) != null && BukkitVersionUtil.isVersion(localVersion) || BukkitVersionUtil.isVersion(localVersion = BukkitVersionUtil.getVersionFromServerPackageString(Bukkit.getServer().getClass().getPackage().getName())))) {
                        if (localVersion.equalsIgnoreCase("mockbukkit")) {
                            return "1.8";
                        }
                        throw new RuntimeException("Could not get version from Bukkit! (Is the server or another plugin changing it?)");
                    }
                    gameVersion = localVersion;
                }
            }
        }
        return localVersion;
    }

    private static boolean isVersion(@NonNull String versionString) {
        String[] numbers = versionString.split("\\.");
        int[] version = VersionUtil.parseVersion(versionString, '.');
        if (version.length != numbers.length) {
            return false;
        }
        for (int i = 0; i < numbers.length; ++i) {
            if (VersionUtil.tryParseInt(numbers[i]) == version[i]) continue;
            return false;
        }
        return true;
    }

    private static @Nullable String getVersionFromVersionString(@NonNull String versionString) {
        int versionIndex = versionString.indexOf("(MC: ");
        if (versionIndex == -1) {
            return null;
        }
        int endIndex = versionString.indexOf(41, versionIndex);
        if (endIndex == -1) {
            return null;
        }
        return versionString.substring(versionIndex + 5, endIndex).trim().replace('_', '.');
    }

    private static @Nullable String getVersionFromBukkitString(@NonNull String versionString) {
        int endIndex = versionString.indexOf("-R");
        if (endIndex == -1) {
            return null;
        }
        return versionString.substring(0, endIndex).trim().replace('_', '.');
    }

    private static @NonNull String getVersionFromServerPackageString(@NonNull String versionString) {
        return versionString.substring(versionString.lastIndexOf(46) + 1).trim().replace('_', '.');
    }
}

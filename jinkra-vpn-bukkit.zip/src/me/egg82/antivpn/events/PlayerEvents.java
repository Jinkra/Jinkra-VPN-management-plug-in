/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  me.egg82.antivpn.external.inet.ipaddr.IPAddressString
 *  org.bukkit.Bukkit
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.command.CommandSender
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.player.AsyncPlayerPreLoginEvent
 *  org.bukkit.event.player.AsyncPlayerPreLoginEvent$Result
 *  org.bukkit.event.player.PlayerLoginEvent
 *  org.bukkit.event.player.PlayerLoginEvent$Result
 *  org.bukkit.plugin.Plugin
 */
package me.egg82.antivpn.events;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import me.egg82.antivpn.AntiVPN;
import me.egg82.antivpn.api.VPNAPIProvider;
import me.egg82.antivpn.api.model.ip.AlgorithmMethod;
import me.egg82.antivpn.api.model.ip.IPManager;
import me.egg82.antivpn.api.model.player.PlayerManager;
import me.egg82.antivpn.api.platform.BukkitPlatform;
import me.egg82.antivpn.config.CachedConfig;
import me.egg82.antivpn.config.ConfigUtil;
import me.egg82.antivpn.events.EventHolder;
import me.egg82.antivpn.external.co.aikar.commands.CommandIssuer;
import me.egg82.antivpn.external.inet.ipaddr.IPAddressString;
import me.egg82.antivpn.external.ninja.egg82.events.BukkitEventSubscriber;
import me.egg82.antivpn.external.ninja.egg82.events.BukkitEvents;
import me.egg82.antivpn.external.ninja.egg82.service.ServiceLocator;
import me.egg82.antivpn.hooks.LuckPermsHook;
import me.egg82.antivpn.hooks.VaultHook;
import me.egg82.antivpn.utils.BukkitCommandUtil;
import me.egg82.antivpn.utils.ExceptionUtil;
import me.egg82.antivpn.utils.ValidationUtil;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.CommandSender;
import org.bukkit.event.EventPriority;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.plugin.Plugin;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.checkerframework.checker.nullness.qual.Nullable;

public class PlayerEvents
extends EventHolder {
    private final Plugin plugin;
    private final CommandIssuer console;

    public PlayerEvents(@NonNull Plugin plugin, @NonNull CommandIssuer console) {
        this.plugin = plugin;
        this.console = console;
        this.events.add(BukkitEvents.subscribe(plugin, AsyncPlayerPreLoginEvent.class, EventPriority.HIGH).handler(this::checkPerms));
        this.events.add(((BukkitEventSubscriber)BukkitEvents.subscribe(plugin, PlayerLoginEvent.class, EventPriority.LOWEST).filter(e -> !Bukkit.hasWhitelist() || e.getPlayer().isWhitelisted())).handler(this::checkPlayer));
        this.events.add(((BukkitEventSubscriber)((BukkitEventSubscriber)BukkitEvents.subscribe(plugin, PlayerLoginEvent.class, EventPriority.MONITOR).filter(e -> e.getResult() == PlayerLoginEvent.Result.ALLOWED)).filter(e -> !Bukkit.hasWhitelist() || e.getPlayer().isWhitelisted())).handler(e -> {
            BukkitPlatform.addUniquePlayer(e.getPlayer().getUniqueId());
            String ip = this.getIp(e.getAddress());
            if (ip != null) {
                try {
                    BukkitPlatform.addUniqueIp(InetAddress.getByName(ip));
                }
                catch (UnknownHostException ex) {
                    this.logger.warn("Could not create InetAddress for " + ip);
                }
            }
        }));
    }

    private void checkPerms(@NonNull AsyncPlayerPreLoginEvent event) {
        Optional<LuckPermsHook> luckPermsHook;
        if (Bukkit.hasWhitelist() && !this.isWhitelisted(event.getUniqueId())) {
            if (ConfigUtil.getDebugOrFalse()) {
                this.console.sendMessage("<c1>" + event.getName() + " (" + event.getUniqueId() + ")</c1><c2> is not whitelisted while the server is in whitelist mode. Ignoring.</c2>");
            }
            return;
        }
        try {
            luckPermsHook = ServiceLocator.getOptional(LuckPermsHook.class);
        }
        catch (IllegalAccessException | InstantiationException ex) {
            this.logger.error(ex.getMessage(), ex);
            luckPermsHook = Optional.empty();
        }
        if (luckPermsHook.isPresent()) {
            Boolean val;
            try {
                val = luckPermsHook.get().hasPermission(event.getUniqueId(), "avpn.bypass").get();
            }
            catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
                val = null;
            }
            catch (CancellationException | ExecutionException ex) {
                ExceptionUtil.handleException(ex, this.logger);
                val = null;
            }
            this.checkPermsPlayer(event, Boolean.TRUE.equals(val));
        } else {
            Optional<VaultHook> vaultHook;
            try {
                vaultHook = ServiceLocator.getOptional(VaultHook.class);
            }
            catch (IllegalAccessException | InstantiationException ex) {
                this.logger.error(ex.getMessage(), ex);
                vaultHook = Optional.empty();
            }
            if (vaultHook.isPresent() && vaultHook.get().getPermission() != null) {
                this.checkPermsPlayer(event, vaultHook.get().getPermission().playerHas(null, Bukkit.getOfflinePlayer((UUID)event.getUniqueId()), "avpn.bypass"));
            } else {
                this.cachePlayer(event);
            }
        }
    }

    private void checkPermsPlayer(@NonNull AsyncPlayerPreLoginEvent event, boolean hasBypass) {
        String kickMessage;
        if (hasBypass) {
            if (ConfigUtil.getDebugOrFalse()) {
                this.console.sendMessage("<c1>" + event.getName() + "</c1> <c2>bypasses pre-check. Ignoring.</c2>");
            }
            return;
        }
        String ip = this.getIp(event.getAddress());
        if (ip == null || ip.isEmpty()) {
            return;
        }
        CachedConfig cachedConfig = ConfigUtil.getCachedConfig();
        if (cachedConfig == null) {
            this.logger.error("Cached config could not be fetched.");
            return;
        }
        for (String testAddress : cachedConfig.getIgnoredIps()) {
            if (ValidationUtil.isValidIp(testAddress) && ip.equalsIgnoreCase(testAddress)) {
                if (ConfigUtil.getDebugOrFalse()) {
                    this.console.sendMessage("<c1>" + event.getName() + "</c1> <c2>is using an ignored IP</c2> <c1>" + ip + "</c1><c2>. Ignoring.</c2>");
                }
                return;
            }
            if (!ValidationUtil.isValidIpRange(testAddress) || !this.rangeContains(testAddress, ip)) continue;
            if (ConfigUtil.getDebugOrFalse()) {
                this.console.sendMessage("<c1>" + event.getName() + "</c1> <c2>is under an ignored range</c2> <c1>" + testAddress + " (" + ip + ")</c1><c2>. Ignoring.</c2>");
            }
            return;
        }
        this.cacheData(ip, event.getUniqueId(), cachedConfig);
        if (this.isVpn(ip, event.getName(), cachedConfig)) {
            AntiVPN.incrementBlockedVPNs();
            IPManager ipManager = VPNAPIProvider.getInstance().getIPManager();
            BukkitCommandUtil.dispatchCommands(ipManager.getVpnCommands(event.getName(), event.getUniqueId(), ip), (CommandSender)Bukkit.getConsoleSender(), this.plugin, true);
            kickMessage = ipManager.getVpnKickMessage(event.getName(), event.getUniqueId(), ip);
            if (kickMessage != null) {
                event.setLoginResult(AsyncPlayerPreLoginEvent.Result.KICK_OTHER);
                event.setKickMessage(kickMessage);
            }
        }
        if (this.isMcLeaks(event.getName(), event.getUniqueId(), cachedConfig)) {
            AntiVPN.incrementBlockedMCLeaks();
            PlayerManager playerManager = VPNAPIProvider.getInstance().getPlayerManager();
            BukkitCommandUtil.dispatchCommands(playerManager.getMcLeaksCommands(event.getName(), event.getUniqueId(), ip), (CommandSender)Bukkit.getConsoleSender(), this.plugin, true);
            kickMessage = playerManager.getMcLeaksKickMessage(event.getName(), event.getUniqueId(), ip);
            if (kickMessage != null) {
                event.setLoginResult(AsyncPlayerPreLoginEvent.Result.KICK_OTHER);
                event.setKickMessage(kickMessage);
            }
        }
    }

    private void cachePlayer(@NonNull AsyncPlayerPreLoginEvent event) {
        String ip = this.getIp(event.getAddress());
        if (ip == null || ip.isEmpty()) {
            return;
        }
        CachedConfig cachedConfig = ConfigUtil.getCachedConfig();
        if (cachedConfig == null) {
            this.logger.error("Cached config could not be fetched.");
            return;
        }
        for (String testAddress : cachedConfig.getIgnoredIps()) {
            if ((!ValidationUtil.isValidIp(testAddress) || !ip.equalsIgnoreCase(testAddress)) && (!ValidationUtil.isValidIpRange(testAddress) || !this.rangeContains(testAddress, ip))) continue;
            return;
        }
        this.cacheData(ip, event.getUniqueId(), cachedConfig);
    }

    private void cacheData(@NonNull String ip, @NonNull UUID uuid, @NonNull CachedConfig cachedConfig) {
        if (!cachedConfig.getVPNKickMessage().isEmpty() || !cachedConfig.getVPNActionCommands().isEmpty()) {
            IPManager ipManager = VPNAPIProvider.getInstance().getIPManager();
            if (cachedConfig.getVPNAlgorithmMethod() == AlgorithmMethod.CONSESNSUS) {
                try {
                    ipManager.consensus(ip, true).get();
                }
                catch (InterruptedException ignored) {
                    Thread.currentThread().interrupt();
                }
                catch (CancellationException | ExecutionException ex) {
                    ExceptionUtil.handleException(ex, this.logger);
                }
            } else {
                try {
                    ipManager.cascade(ip, true).get();
                }
                catch (InterruptedException ignored) {
                    Thread.currentThread().interrupt();
                }
                catch (CancellationException | ExecutionException ex) {
                    ExceptionUtil.handleException(ex, this.logger);
                }
            }
        }
        if (!cachedConfig.getMCLeaksKickMessage().isEmpty() || !cachedConfig.getMCLeaksActionCommands().isEmpty()) {
            PlayerManager playerManager = VPNAPIProvider.getInstance().getPlayerManager();
            try {
                playerManager.checkMcLeaks(uuid, true).get();
            }
            catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
            }
            catch (CancellationException | ExecutionException ex) {
                ExceptionUtil.handleException(ex, this.logger);
            }
        }
    }

    private void checkPlayer(@NonNull PlayerLoginEvent event) {
        String kickMessage;
        Optional<VaultHook> vaultHook;
        Optional<LuckPermsHook> luckPermsHook;
        try {
            luckPermsHook = ServiceLocator.getOptional(LuckPermsHook.class);
        }
        catch (IllegalAccessException | InstantiationException ex) {
            this.logger.error(ex.getMessage(), ex);
            luckPermsHook = Optional.empty();
        }
        if (luckPermsHook.isPresent()) {
            return;
        }
        try {
            vaultHook = ServiceLocator.getOptional(VaultHook.class);
        }
        catch (IllegalAccessException | InstantiationException ex) {
            this.logger.error(ex.getMessage(), ex);
            vaultHook = Optional.empty();
        }
        if (vaultHook.isPresent() && vaultHook.get().getPermission() != null) {
            return;
        }
        String ip = this.getIp(event.getAddress());
        if (ip == null || ip.isEmpty()) {
            return;
        }
        CachedConfig cachedConfig = ConfigUtil.getCachedConfig();
        if (cachedConfig == null) {
            this.logger.error("Cached config could not be fetched.");
            return;
        }
        if (event.getPlayer().hasPermission("avpn.bypass")) {
            if (ConfigUtil.getDebugOrFalse()) {
                this.console.sendMessage("<c1>" + event.getPlayer().getName() + "</c1> <c2>bypasses actions. Ignoring.</c2>");
            }
            return;
        }
        for (String testAddress : cachedConfig.getIgnoredIps()) {
            if (ValidationUtil.isValidIp(testAddress) && ip.equalsIgnoreCase(testAddress)) {
                if (ConfigUtil.getDebugOrFalse()) {
                    this.console.sendMessage("<c1>" + event.getPlayer().getName() + "</c1> <c2>is using an ignored IP</c2> <c1>" + ip + "</c1><c2>. Ignoring.</c2>");
                }
                return;
            }
            if (!ValidationUtil.isValidIpRange(testAddress) || !this.rangeContains(testAddress, ip)) continue;
            if (ConfigUtil.getDebugOrFalse()) {
                this.console.sendMessage("<c1>" + event.getPlayer().getName() + "</c1> <c2>is under an ignored range</c2> <c1>" + testAddress + " (" + ip + ")</c1><c2>. Ignoring.</c2>");
            }
            return;
        }
        if (this.isVpn(ip, event.getPlayer().getName(), cachedConfig)) {
            AntiVPN.incrementBlockedVPNs();
            IPManager ipManager = VPNAPIProvider.getInstance().getIPManager();
            BukkitCommandUtil.dispatchCommands(ipManager.getVpnCommands(event.getPlayer().getName(), event.getPlayer().getUniqueId(), ip), (CommandSender)Bukkit.getConsoleSender(), this.plugin, false);
            kickMessage = ipManager.getVpnKickMessage(event.getPlayer().getName(), event.getPlayer().getUniqueId(), ip);
            if (kickMessage != null) {
                event.setResult(PlayerLoginEvent.Result.KICK_OTHER);
                event.setKickMessage(kickMessage);
            }
        }
        if (this.isMcLeaks(event.getPlayer().getName(), event.getPlayer().getUniqueId(), cachedConfig)) {
            AntiVPN.incrementBlockedMCLeaks();
            PlayerManager playerManager = VPNAPIProvider.getInstance().getPlayerManager();
            BukkitCommandUtil.dispatchCommands(playerManager.getMcLeaksCommands(event.getPlayer().getName(), event.getPlayer().getUniqueId(), ip), (CommandSender)Bukkit.getConsoleSender(), this.plugin, false);
            kickMessage = playerManager.getMcLeaksKickMessage(event.getPlayer().getName(), event.getPlayer().getUniqueId(), ip);
            if (kickMessage != null) {
                event.setResult(PlayerLoginEvent.Result.KICK_OTHER);
                event.setKickMessage(kickMessage);
            }
        }
    }

    private boolean isVpn(@NonNull String ip, @NonNull String name, @NonNull CachedConfig cachedConfig) {
        if (!cachedConfig.getVPNKickMessage().isEmpty() || !cachedConfig.getVPNActionCommands().isEmpty()) {
            boolean isVPN;
            IPManager ipManager = VPNAPIProvider.getInstance().getIPManager();
            if (cachedConfig.getVPNAlgorithmMethod() == AlgorithmMethod.CONSESNSUS) {
                try {
                    Double val = ipManager.consensus(ip, true).get();
                    isVPN = val != null && val >= cachedConfig.getVPNAlgorithmConsensus();
                }
                catch (InterruptedException ignored) {
                    Thread.currentThread().interrupt();
                    isVPN = false;
                }
                catch (CancellationException | ExecutionException ex) {
                    ExceptionUtil.handleException(ex, this.logger);
                    isVPN = false;
                }
            } else {
                try {
                    isVPN = Boolean.TRUE.equals(ipManager.cascade(ip, true).get());
                }
                catch (InterruptedException ignored) {
                    Thread.currentThread().interrupt();
                    isVPN = false;
                }
                catch (CancellationException | ExecutionException ex) {
                    ExceptionUtil.handleException(ex, this.logger);
                    isVPN = false;
                }
            }
            if (isVPN) {
                if (cachedConfig.getDebug()) {
                    this.console.sendMessage("<c1>" + name + "</c1> <c9>found using a VPN. Running required actions.</c9>");
                }
            } else if (cachedConfig.getDebug()) {
                this.console.sendMessage("<c1>" + name + "</c1> <c4>passed VPN check.</c4>");
            }
            return isVPN;
        }
        if (cachedConfig.getDebug()) {
            this.console.sendMessage("<c2>Plugin set to API-only. Ignoring VPN check for</c2> <c1>" + name + "</c1>");
        }
        return false;
    }

    private boolean isMcLeaks(@NonNull String name, @NonNull UUID uuid, @NonNull CachedConfig cachedConfig) {
        if (!cachedConfig.getMCLeaksKickMessage().isEmpty() || !cachedConfig.getMCLeaksActionCommands().isEmpty()) {
            boolean isMCLeaks;
            PlayerManager playerManager = VPNAPIProvider.getInstance().getPlayerManager();
            try {
                isMCLeaks = Boolean.TRUE.equals(playerManager.checkMcLeaks(uuid, true).get());
            }
            catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
                isMCLeaks = false;
            }
            catch (CancellationException | ExecutionException ex) {
                ExceptionUtil.handleException(ex, this.logger);
                isMCLeaks = false;
            }
            if (isMCLeaks) {
                if (cachedConfig.getDebug()) {
                    this.console.sendMessage("<c1>" + name + "</c1> <c9>found using an MCLeaks account. Running required actions.</c9>");
                }
            } else if (cachedConfig.getDebug()) {
                this.console.sendMessage("<c1>" + name + "</c1> <c4>passed MCLeaks check.</c4>");
            }
            return isMCLeaks;
        }
        if (cachedConfig.getDebug()) {
            this.console.sendMessage("<c2>Plugin set to API-only. Ignoring MCLeaks check for</c2> <c1>" + name + "</c1>");
        }
        return false;
    }

    private @Nullable String getIp(InetAddress address) {
        if (address == null) {
            return null;
        }
        return address.getHostAddress();
    }

    private boolean isWhitelisted(UUID playerID) {
        for (OfflinePlayer p : Bukkit.getWhitelistedPlayers()) {
            if (!playerID.equals(p.getUniqueId())) continue;
            return true;
        }
        return false;
    }

    private boolean rangeContains(@NonNull String range, @NonNull String ip) {
        return new IPAddressString(range).contains(new IPAddressString(ip));
    }
}

/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.event.player.PlayerLoginEvent
 *  org.bukkit.plugin.Plugin
 */
package me.egg82.antivpn.events;

import java.util.concurrent.ExecutionException;
import java.util.function.Consumer;
import me.egg82.antivpn.config.ConfigUtil;
import me.egg82.antivpn.external.co.aikar.commands.CommandManager;
import me.egg82.antivpn.external.ninja.egg82.service.ServiceLocator;
import me.egg82.antivpn.external.ninja.egg82.service.ServiceNotFoundException;
import me.egg82.antivpn.external.ninja.egg82.updater.SpigotUpdater;
import me.egg82.antivpn.external.org.spongepowered.configurate.ConfigurationNode;
import me.egg82.antivpn.lang.Message;
import org.bukkit.Bukkit;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.plugin.Plugin;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PlayerLoginUpdateNotifyHandler
implements Consumer<PlayerLoginEvent> {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());
    private final Plugin plugin;
    private final CommandManager commandManager;

    public PlayerLoginUpdateNotifyHandler(@NonNull Plugin plugin, @NonNull CommandManager commandManager) {
        this.plugin = plugin;
        this.commandManager = commandManager;
    }

    @Override
    public void accept(@NonNull PlayerLoginEvent event) {
        SpigotUpdater updater;
        if (!event.getPlayer().hasPermission("avpn.admin")) {
            return;
        }
        ConfigurationNode config = ConfigUtil.getConfig();
        if (config == null) {
            return;
        }
        try {
            updater = ServiceLocator.get(SpigotUpdater.class);
        }
        catch (IllegalAccessException | InstantiationException | ServiceNotFoundException ex) {
            this.logger.error(ex.getMessage(), ex);
            return;
        }
        if (!config.node("update", "check").getBoolean(true)) {
            return;
        }
        updater.isUpdateAvailable().thenAccept(v -> {
            if (!v.booleanValue()) {
                return;
            }
            if (config.node("update", "notify").getBoolean(true)) {
                try {
                    String version = updater.getLatestVersion().get();
                    Bukkit.getScheduler().runTask(this.plugin, () -> this.commandManager.getCommandIssuer(event.getPlayer()).sendInfo(Message.GENERAL__UPDATE, "{version}", version));
                }
                catch (ExecutionException ex) {
                    this.logger.error(ex.getMessage(), ex);
                }
                catch (InterruptedException ex) {
                    this.logger.error(ex.getMessage(), ex);
                    Thread.currentThread().interrupt();
                }
            }
        });
    }
}

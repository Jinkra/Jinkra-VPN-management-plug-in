/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.events;

import java.util.ArrayList;
import java.util.List;
import me.egg82.antivpn.external.ninja.egg82.events.BukkitEventSubscriber;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class EventHolder {
    protected final Logger logger = LoggerFactory.getLogger(this.getClass());
    protected final List<BukkitEventSubscriber<?>> events = new ArrayList();

    public final int numEvents() {
        return this.events.size();
    }

    public final void cancel() {
        for (BukkitEventSubscriber<?> event : this.events) {
            event.cancel();
        }
    }
}

/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.hooks;

public interface PluginHook {
    public void cancel();
}

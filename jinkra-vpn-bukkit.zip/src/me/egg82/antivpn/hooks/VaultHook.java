/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  net.milkbowl.vault.permission.Permission
 *  org.bukkit.Bukkit
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.server.PluginEnableEvent
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.RegisteredServiceProvider
 */
package me.egg82.antivpn.hooks;

import me.egg82.antivpn.config.ConfigUtil;
import me.egg82.antivpn.external.co.aikar.commands.CommandIssuer;
import me.egg82.antivpn.external.ninja.egg82.events.BukkitEventSubscriber;
import me.egg82.antivpn.external.ninja.egg82.events.BukkitEvents;
import me.egg82.antivpn.external.ninja.egg82.service.ServiceLocator;
import me.egg82.antivpn.hooks.PluginHook;
import net.milkbowl.vault.permission.Permission;
import org.bukkit.Bukkit;
import org.bukkit.event.EventPriority;
import org.bukkit.event.server.PluginEnableEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.checkerframework.checker.nullness.qual.Nullable;

public class VaultHook
implements PluginHook {
    private final Permission permission;
    private final CommandIssuer console;

    public static void create(@NonNull Plugin plugin, @NonNull Plugin vault, @NonNull CommandIssuer console) {
        if (!vault.isEnabled()) {
            ((BukkitEventSubscriber)((BukkitEventSubscriber)BukkitEvents.subscribe(plugin, PluginEnableEvent.class, EventPriority.MONITOR).expireIf(e -> e.getPlugin().getName().equals("Vault"))).filter(e -> e.getPlugin().getName().equals("Vault"))).handler(e -> ServiceLocator.register(new VaultHook(console)));
            return;
        }
        ServiceLocator.register(new VaultHook(console));
    }

    private VaultHook(@NonNull CommandIssuer console) {
        this.console = console;
        RegisteredServiceProvider permissionProvider = Bukkit.getServicesManager().getRegistration(Permission.class);
        if (permissionProvider != null) {
            if (ConfigUtil.getDebugOrFalse()) {
                console.sendMessage("<c2>Found Vault permissions provider.</c2>");
            }
            this.permission = (Permission)permissionProvider.getProvider();
        } else {
            if (ConfigUtil.getDebugOrFalse()) {
                console.sendMessage("<c9>Could not find Vault permissions provider.</c9>");
            }
            this.permission = null;
        }
    }

    @Override
    public void cancel() {
    }

    public @Nullable Permission getPermission() {
        if (this.permission == null && ConfigUtil.getDebugOrFalse()) {
            this.console.sendMessage("<c2>Returning null Vault permissions provider.</c2>");
        }
        return this.permission;
    }
}

/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.djrapitops.plan.extension.CallEvents
 *  com.djrapitops.plan.extension.DataExtension
 *  com.djrapitops.plan.extension.FormatType
 *  com.djrapitops.plan.extension.annotation.BooleanProvider
 *  com.djrapitops.plan.extension.annotation.NumberProvider
 *  com.djrapitops.plan.extension.annotation.PluginInfo
 *  com.djrapitops.plan.extension.icon.Color
 *  com.djrapitops.plan.extension.icon.Family
 *  org.bukkit.Bukkit
 *  org.bukkit.entity.Player
 */
package me.egg82.antivpn.hooks;

import com.djrapitops.plan.extension.CallEvents;
import com.djrapitops.plan.extension.DataExtension;
import com.djrapitops.plan.extension.FormatType;
import com.djrapitops.plan.extension.annotation.BooleanProvider;
import com.djrapitops.plan.extension.annotation.NumberProvider;
import com.djrapitops.plan.extension.annotation.PluginInfo;
import com.djrapitops.plan.extension.icon.Color;
import com.djrapitops.plan.extension.icon.Family;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.util.Collection;
import java.util.UUID;
import java.util.concurrent.CancellationException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import me.egg82.antivpn.api.VPNAPIProvider;
import me.egg82.antivpn.api.model.ip.AlgorithmMethod;
import me.egg82.antivpn.api.model.ip.IPManager;
import me.egg82.antivpn.api.model.player.PlayerManager;
import me.egg82.antivpn.config.ConfigUtil;
import me.egg82.antivpn.utils.ExceptionUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.checkerframework.checker.nullness.qual.Nullable;

@PluginInfo(name="AntiVPN", iconName="shield-alt", iconFamily=Family.SOLID, color=Color.BLUE)
class PlayerAnalyticsHook.Data
implements DataExtension {
    private final CallEvents[] events = new CallEvents[]{CallEvents.SERVER_PERIODICAL, CallEvents.SERVER_EXTENSION_REGISTER, CallEvents.PLAYER_JOIN};

    private PlayerAnalyticsHook.Data() {
    }

    @NumberProvider(text="VPN Users", description="Number of online VPN users.", priority=2, iconName="user-shield", iconFamily=Family.SOLID, iconColor=Color.NONE, format=FormatType.NONE)
    public long getVpns() {
        IPManager ipManager = VPNAPIProvider.getInstance().getIPManager();
        Collection players = Bukkit.getOnlinePlayers();
        ExecutorService pool = Executors.newWorkStealingPool(Math.max(players.size() / 2, Runtime.getRuntime().availableProcessors() / 2));
        CountDownLatch latch = new CountDownLatch(players.size());
        AtomicLong results = new AtomicLong(0L);
        for (Player p : players) {
            pool.submit(() -> {
                String ip = this.getIp(p);
                if (ip == null || ip.isEmpty()) {
                    latch.countDown();
                    return;
                }
                if (ipManager.getCurrentAlgorithmMethod() == AlgorithmMethod.CONSESNSUS) {
                    try {
                        Double val = ipManager.consensus(ip, true).get();
                        if (val != null && val >= ipManager.getMinConsensusValue()) {
                            results.addAndGet(1L);
                        }
                    }
                    catch (InterruptedException ignored) {
                        Thread.currentThread().interrupt();
                    }
                    catch (CancellationException | ExecutionException ex) {
                        ExceptionUtil.handleException(ex, PlayerAnalyticsHook.this.logger);
                    }
                } else {
                    try {
                        if (Boolean.TRUE.equals(ipManager.cascade(ip, true).get())) {
                            results.addAndGet(1L);
                        }
                    }
                    catch (InterruptedException ignored) {
                        Thread.currentThread().interrupt();
                    }
                    catch (CancellationException | ExecutionException ex) {
                        ExceptionUtil.handleException(ex, PlayerAnalyticsHook.this.logger);
                    }
                }
                latch.countDown();
            });
        }
        try {
            if (!latch.await(40L, TimeUnit.SECONDS)) {
                PlayerAnalyticsHook.this.logger.warn("Plan hook timed out before all results could be obtained.");
            }
        }
        catch (InterruptedException ex) {
            if (ConfigUtil.getDebugOrFalse()) {
                PlayerAnalyticsHook.this.logger.error(ex.getMessage(), ex);
            } else {
                PlayerAnalyticsHook.this.logger.error(ex.getMessage());
            }
            Thread.currentThread().interrupt();
        }
        pool.shutdownNow();
        return results.get();
    }

    @NumberProvider(text="MCLeaks Users", description="Number of online MCLeaks users.", priority=1, iconName="users", iconFamily=Family.SOLID, iconColor=Color.NONE, format=FormatType.NONE)
    public long getMcLeaks() {
        PlayerManager playerManager = VPNAPIProvider.getInstance().getPlayerManager();
        Collection players = Bukkit.getOnlinePlayers();
        ExecutorService pool = Executors.newWorkStealingPool(Math.max(players.size() / 2, Runtime.getRuntime().availableProcessors() / 2));
        CountDownLatch latch = new CountDownLatch(players.size());
        AtomicLong results = new AtomicLong(0L);
        for (Player p : players) {
            pool.submit(() -> {
                try {
                    if (Boolean.TRUE.equals(playerManager.checkMcLeaks(p.getUniqueId(), true).get())) {
                        results.addAndGet(1L);
                    }
                }
                catch (InterruptedException ignored) {
                    Thread.currentThread().interrupt();
                }
                catch (CancellationException | ExecutionException ex) {
                    ExceptionUtil.handleException(ex, PlayerAnalyticsHook.this.logger);
                }
                latch.countDown();
            });
        }
        try {
            if (!latch.await(40L, TimeUnit.SECONDS)) {
                PlayerAnalyticsHook.this.logger.warn("Plan hook timed out before all results could be obtained.");
            }
        }
        catch (InterruptedException ex) {
            if (ConfigUtil.getDebugOrFalse()) {
                PlayerAnalyticsHook.this.logger.error(ex.getMessage(), ex);
            } else {
                PlayerAnalyticsHook.this.logger.error(ex.getMessage());
            }
            Thread.currentThread().interrupt();
        }
        pool.shutdownNow();
        return results.get();
    }

    @BooleanProvider(text="VPN", description="Using a VPN or proxy.", iconName="user-shield", iconFamily=Family.SOLID, iconColor=Color.NONE)
    public boolean getUsingVpn(@NonNull UUID playerID) {
        Player player = Bukkit.getPlayer((UUID)playerID);
        if (player == null) {
            return false;
        }
        String ip = this.getIp(player);
        if (ip == null || ip.isEmpty()) {
            return false;
        }
        IPManager ipManager = VPNAPIProvider.getInstance().getIPManager();
        if (ipManager.getCurrentAlgorithmMethod() == AlgorithmMethod.CONSESNSUS) {
            try {
                Double val = ipManager.consensus(ip, true).get();
                return val != null && val >= ipManager.getMinConsensusValue();
            }
            catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
            }
            catch (CancellationException | ExecutionException ex) {
                ExceptionUtil.handleException(ex, PlayerAnalyticsHook.this.logger);
            }
        } else {
            try {
                return Boolean.TRUE.equals(ipManager.cascade(ip, true).get());
            }
            catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
            }
            catch (CancellationException | ExecutionException ex) {
                ExceptionUtil.handleException(ex, PlayerAnalyticsHook.this.logger);
            }
        }
        return false;
    }

    @BooleanProvider(text="MCLeaks", description="Using an MCLeaks account.", iconName="users", iconFamily=Family.SOLID, iconColor=Color.NONE)
    public boolean getMcLeaks(@NonNull UUID playerId) {
        PlayerManager playerManager = VPNAPIProvider.getInstance().getPlayerManager();
        try {
            return Boolean.TRUE.equals(playerManager.checkMcLeaks(playerId, true).get());
        }
        catch (InterruptedException ignored) {
            Thread.currentThread().interrupt();
        }
        catch (CancellationException | ExecutionException ex) {
            ExceptionUtil.handleException(ex, PlayerAnalyticsHook.this.logger);
        }
        return false;
    }

    private @Nullable String getIp(@NonNull Player player) {
        InetSocketAddress address = player.getAddress();
        if (address == null) {
            return null;
        }
        InetAddress host = address.getAddress();
        if (host == null) {
            return null;
        }
        return host.getHostAddress();
    }

    public @NonNull CallEvents[] callExtensionMethodsOn() {
        return this.events;
    }
}

/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.hooks;

static class PlayerAnalyticsHook.1 {
}

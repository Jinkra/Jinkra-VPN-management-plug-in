/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  me.clip.placeholderapi.PlaceholderAPI
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.entity.Player
 */
package me.egg82.antivpn.hooks;

import me.clip.placeholderapi.PlaceholderAPI;
import me.egg82.antivpn.hooks.PluginHook;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.checkerframework.checker.nullness.qual.NonNull;

public class PlaceholderAPIHook
implements PluginHook {
    @Override
    public void cancel() {
    }

    public @NonNull String withPlaceholders(Player player, @NonNull String input) {
        return PlaceholderAPI.setPlaceholders((Player)player, (String)input);
    }

    public @NonNull String withPlaceholders(OfflinePlayer player, @NonNull String input) {
        return PlaceholderAPI.setPlaceholders((OfflinePlayer)player, (String)input);
    }
}

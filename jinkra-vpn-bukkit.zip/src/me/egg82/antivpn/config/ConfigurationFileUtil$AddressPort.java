/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.config;

import org.checkerframework.checker.nullness.qual.NonNull;

private static class ConfigurationFileUtil.AddressPort {
    private final String address;
    private final int port;

    public ConfigurationFileUtil.AddressPort(@NonNull String node, @NonNull String raw, int defaultPort) {
        int p;
        String a = raw;
        int portIndex = a.indexOf(58);
        if (portIndex > -1) {
            p = Integer.parseInt(a.substring(portIndex + 1));
            a = a.substring(0, portIndex);
        } else {
            logger.warn(node + " port is an unknown value. Using default value.");
            p = defaultPort;
        }
        this.address = a;
        this.port = p;
    }

    public @NonNull String getAddress() {
        return this.address;
    }

    public int getPort() {
        return this.port;
    }

    static /* synthetic */ String access$400(ConfigurationFileUtil.AddressPort x0) {
        return x0.address;
    }

    static /* synthetic */ int access$500(ConfigurationFileUtil.AddressPort x0) {
        return x0.port;
    }
}

/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.config;

import me.egg82.antivpn.config.CachedConfig;
import me.egg82.antivpn.external.org.spongepowered.configurate.ConfigurationNode;
import org.checkerframework.checker.nullness.qual.Nullable;

public class ConfigUtil {
    private static ConfigurationNode config = null;
    private static CachedConfig cachedConfig = null;

    private ConfigUtil() {
    }

    public static void setConfiguration(ConfigurationNode config, CachedConfig cachedConfig) {
        ConfigUtil.config = config;
        ConfigUtil.cachedConfig = cachedConfig;
    }

    public static @Nullable ConfigurationNode getConfig() {
        return config;
    }

    public static @Nullable CachedConfig getCachedConfig() {
        return cachedConfig;
    }

    public static boolean getDebugOrFalse() {
        CachedConfig c = cachedConfig;
        return c != null && c.getDebug();
    }
}

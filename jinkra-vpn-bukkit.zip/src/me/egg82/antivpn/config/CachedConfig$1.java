/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.config;

static class CachedConfig.1 {
}

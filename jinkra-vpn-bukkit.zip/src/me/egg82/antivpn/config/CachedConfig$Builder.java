/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 *  com.google.common.collect.ImmutableSet
 */
package me.egg82.antivpn.config;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import me.egg82.antivpn.api.model.ip.AlgorithmMethod;
import me.egg82.antivpn.config.CachedConfig;
import me.egg82.antivpn.messaging.MessagingService;
import me.egg82.antivpn.storage.StorageService;
import me.egg82.antivpn.utils.TimeUtil;
import org.checkerframework.checker.nullness.qual.NonNull;

public static class CachedConfig.Builder {
    private final CachedConfig values = new CachedConfig(null);

    private CachedConfig.Builder() {
    }

    public CachedConfig.Builder debug(boolean value) {
        this.values.debug = value;
        return this;
    }

    public CachedConfig.Builder language(@NonNull Locale value) {
        this.values.language = value;
        return this;
    }

    public CachedConfig.Builder storage(@NonNull List<StorageService> value) {
        this.values.storage = ImmutableList.copyOf(value);
        return this;
    }

    public CachedConfig.Builder messaging(@NonNull List<MessagingService> value) {
        this.values.messaging = ImmutableList.copyOf(value);
        return this;
    }

    public CachedConfig.Builder sourceCacheTime( @NonNull TimeUtil.Time value) {
        if (value.getMillis() <= 0L) {
            throw new IllegalArgumentException("value cannot be <= 0.");
        }
        this.values.sourceCacheTime = value.getMillis();
        return this;
    }

    public CachedConfig.Builder mcleaksCacheTime(TimeUtil.Time value) {
        if (value == null) {
            throw new IllegalArgumentException("value cannot be null.");
        }
        if (value.getMillis() <= 0L) {
            throw new IllegalArgumentException("value cannot be <= 0.");
        }
        this.values.mcleaksCacheTime = value.getMillis();
        return this;
    }

    public CachedConfig.Builder ignoredIps(@NonNull Collection<String> value) {
        this.values.ignoredIps = ImmutableSet.copyOf(value);
        return this;
    }

    public CachedConfig.Builder cacheTime(TimeUtil.Time value) {
        if (value == null) {
            throw new IllegalArgumentException("value cannot be null.");
        }
        if (value.getMillis() <= 0L) {
            throw new IllegalArgumentException("value cannot be <= 0.");
        }
        this.values.cacheTime = value;
        return this;
    }

    public CachedConfig.Builder threads(int value) {
        if (value <= 1) {
            throw new IllegalArgumentException("value cannot be <= 1.");
        }
        this.values.threads = value;
        return this;
    }

    public CachedConfig.Builder timeout(long value) {
        if (value <= 0L) {
            throw new IllegalArgumentException("value cannot be <= 0.");
        }
        this.values.timeout = value;
        return this;
    }

    public CachedConfig.Builder vpnKickMessage(@NonNull String value) {
        this.values.vpnKickMessage = value;
        return this;
    }

    public CachedConfig.Builder vpnActionCommands(@NonNull Collection<String> value) {
        this.values.vpnActionCommands = ImmutableList.copyOf(value);
        return this;
    }

    public CachedConfig.Builder mcleaksKickMessage(@NonNull String value) {
        this.values.mcleaksKickMessage = value;
        return this;
    }

    public CachedConfig.Builder mcleaksActionCommands(@NonNull Collection<String> value) {
        this.values.mcleaksActionCommands = ImmutableList.copyOf(value);
        return this;
    }

    public CachedConfig.Builder vpnAlgorithmMethod(@NonNull AlgorithmMethod value) {
        this.values.algorithmMethod = value;
        return this;
    }

    public CachedConfig.Builder vpnAlgorithmConsensus(double value) {
        if (value < 0.0) {
            throw new IllegalArgumentException("value cannot be < 0.");
        }
        if (value > 1.0) {
            throw new IllegalArgumentException("value cannot be > 1.");
        }
        this.values.vpnAlgorithmConsensus = value;
        return this;
    }

    public CachedConfig.Builder mcleaksKey(@NonNull String value) {
        this.values.mcleaksKey = value;
        return this;
    }

    public CachedConfig.Builder serverId(@NonNull UUID value) {
        this.values.serverId = value;
        this.values.serverIdString = value.toString();
        return this;
    }

    public CachedConfig build() {
        return this.values;
    }
}

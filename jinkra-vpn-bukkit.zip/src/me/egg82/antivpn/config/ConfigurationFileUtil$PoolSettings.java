/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.config;

import me.egg82.antivpn.external.org.spongepowered.configurate.ConfigurationNode;

private static class ConfigurationFileUtil.PoolSettings {
    private final int minPoolSize;
    private final int maxPoolSize;
    private final long maxLifetime;
    private final long timeout;

    public ConfigurationFileUtil.PoolSettings(ConfigurationNode settingsNode) {
        this.minPoolSize = settingsNode.node("min-idle").getInt();
        this.maxPoolSize = settingsNode.node("max-pool-size").getInt();
        this.maxLifetime = settingsNode.node("max-lifetime").getLong();
        this.timeout = settingsNode.node("timeout").getLong();
    }

    public int getMinPoolSize() {
        return this.minPoolSize;
    }

    public int getMaxPoolSize() {
        return this.maxPoolSize;
    }

    public long getMaxLifetime() {
        return this.maxLifetime;
    }

    public long getTimeout() {
        return this.timeout;
    }

    static /* synthetic */ long access$000(ConfigurationFileUtil.PoolSettings x0) {
        return x0.maxLifetime;
    }

    static /* synthetic */ long access$100(ConfigurationFileUtil.PoolSettings x0) {
        return x0.timeout;
    }

    static /* synthetic */ int access$200(ConfigurationFileUtil.PoolSettings x0) {
        return x0.minPoolSize;
    }

    static /* synthetic */ int access$300(ConfigurationFileUtil.PoolSettings x0) {
        return x0.maxPoolSize;
    }
}

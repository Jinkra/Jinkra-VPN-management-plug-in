/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 *  com.google.common.collect.ImmutableSet
 */
package me.egg82.antivpn.config;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import me.egg82.antivpn.api.model.ip.AlgorithmMethod;
import me.egg82.antivpn.messaging.MessagingService;
import me.egg82.antivpn.storage.StorageService;
import me.egg82.antivpn.utils.TimeUtil;
import org.checkerframework.checker.nullness.qual.NonNull;

public class CachedConfig {
    private ImmutableList<StorageService> storage = ImmutableList.of();
    private ImmutableList<MessagingService> messaging = ImmutableList.of();
    private long sourceCacheTime = new TimeUtil.Time(6L, TimeUnit.HOURS).getMillis();
    private long mcleaksCacheTime = new TimeUtil.Time(1L, TimeUnit.DAYS).getMillis();
    private ImmutableSet<String> ignoredIps = ImmutableSet.of();
    private TimeUtil.Time cacheTime = new TimeUtil.Time(1L, TimeUnit.MINUTES);
    private boolean debug = false;
    private Locale language = Locale.ENGLISH;
    private int threads = 4;
    private long timeout = 5000L;
    private String vpnKickMessage = "&cPlease disconnect from your proxy or VPN before re-joining!";
    private ImmutableList<String> vpnActionCommands = ImmutableList.of();
    private String mcleaksKickMessage = "&cPlease discontinue your use of an MCLeaks account!";
    private ImmutableList<String> mcleaksActionCommands = ImmutableList.of();
    private AlgorithmMethod algorithmMethod = AlgorithmMethod.CASCADE;
    private double vpnAlgorithmConsensus = 0.6;
    private String mcleaksKey = "";
    private UUID serverId = UUID.randomUUID();
    private String serverIdString = this.serverId.toString();

    private CachedConfig() {
    }

    public @NonNull ImmutableList<StorageService> getStorage() {
        return this.storage;
    }

    public @NonNull ImmutableList<MessagingService> getMessaging() {
        return this.messaging;
    }

    public long getSourceCacheTime() {
        return this.sourceCacheTime;
    }

    public long getMCLeaksCacheTime() {
        return this.mcleaksCacheTime;
    }

    public @NonNull ImmutableSet<String> getIgnoredIps() {
        return this.ignoredIps;
    }

    public TimeUtil.Time getCacheTime() {
        return this.cacheTime;
    }

    public boolean getDebug() {
        return this.debug;
    }

    public @NonNull Locale getLanguage() {
        return this.language;
    }

    public int getThreads() {
        return this.threads;
    }

    public long getTimeout() {
        return this.timeout;
    }

    public @NonNull String getVPNKickMessage() {
        return this.vpnKickMessage;
    }

    public @NonNull ImmutableList<String> getVPNActionCommands() {
        return this.vpnActionCommands;
    }

    public @NonNull String getMCLeaksKickMessage() {
        return this.mcleaksKickMessage;
    }

    public @NonNull ImmutableList<String> getMCLeaksActionCommands() {
        return this.mcleaksActionCommands;
    }

    public @NonNull AlgorithmMethod getVPNAlgorithmMethod() {
        return this.algorithmMethod;
    }

    public double getVPNAlgorithmConsensus() {
        return this.vpnAlgorithmConsensus;
    }

    public @NonNull String getMcLeaksKey() {
        return this.mcleaksKey;
    }

    public @NonNull UUID getServerId() {
        return this.serverId;
    }

    public @NonNull String getServerIdString() {
        return this.serverIdString;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private final CachedConfig values = new CachedConfig();

        private Builder() {
        }

        public Builder debug(boolean value) {
            this.values.debug = value;
            return this;
        }

        public Builder language(@NonNull Locale value) {
            this.values.language = value;
            return this;
        }

        public Builder storage(@NonNull List<StorageService> value) {
            this.values.storage = ImmutableList.copyOf(value);
            return this;
        }

        public Builder messaging(@NonNull List<MessagingService> value) {
            this.values.messaging = ImmutableList.copyOf(value);
            return this;
        }

        public Builder sourceCacheTime( @NonNull TimeUtil.Time value) {
            if (value.getMillis() <= 0L) {
                throw new IllegalArgumentException("value cannot be <= 0.");
            }
            this.values.sourceCacheTime = value.getMillis();
            return this;
        }

        public Builder mcleaksCacheTime(TimeUtil.Time value) {
            if (value == null) {
                throw new IllegalArgumentException("value cannot be null.");
            }
            if (value.getMillis() <= 0L) {
                throw new IllegalArgumentException("value cannot be <= 0.");
            }
            this.values.mcleaksCacheTime = value.getMillis();
            return this;
        }

        public Builder ignoredIps(@NonNull Collection<String> value) {
            this.values.ignoredIps = ImmutableSet.copyOf(value);
            return this;
        }

        public Builder cacheTime(TimeUtil.Time value) {
            if (value == null) {
                throw new IllegalArgumentException("value cannot be null.");
            }
            if (value.getMillis() <= 0L) {
                throw new IllegalArgumentException("value cannot be <= 0.");
            }
            this.values.cacheTime = value;
            return this;
        }

        public Builder threads(int value) {
            if (value <= 1) {
                throw new IllegalArgumentException("value cannot be <= 1.");
            }
            this.values.threads = value;
            return this;
        }

        public Builder timeout(long value) {
            if (value <= 0L) {
                throw new IllegalArgumentException("value cannot be <= 0.");
            }
            this.values.timeout = value;
            return this;
        }

        public Builder vpnKickMessage(@NonNull String value) {
            this.values.vpnKickMessage = value;
            return this;
        }

        public Builder vpnActionCommands(@NonNull Collection<String> value) {
            this.values.vpnActionCommands = ImmutableList.copyOf(value);
            return this;
        }

        public Builder mcleaksKickMessage(@NonNull String value) {
            this.values.mcleaksKickMessage = value;
            return this;
        }

        public Builder mcleaksActionCommands(@NonNull Collection<String> value) {
            this.values.mcleaksActionCommands = ImmutableList.copyOf(value);
            return this;
        }

        public Builder vpnAlgorithmMethod(@NonNull AlgorithmMethod value) {
            this.values.algorithmMethod = value;
            return this;
        }

        public Builder vpnAlgorithmConsensus(double value) {
            if (value < 0.0) {
                throw new IllegalArgumentException("value cannot be < 0.");
            }
            if (value > 1.0) {
                throw new IllegalArgumentException("value cannot be > 1.");
            }
            this.values.vpnAlgorithmConsensus = value;
            return this;
        }

        public Builder mcleaksKey(@NonNull String value) {
            this.values.mcleaksKey = value;
            return this;
        }

        public Builder serverId(@NonNull UUID value) {
            this.values.serverId = value;
            this.values.serverIdString = value.toString();
            return this;
        }

        public CachedConfig build() {
            return this.values;
        }
    }
}

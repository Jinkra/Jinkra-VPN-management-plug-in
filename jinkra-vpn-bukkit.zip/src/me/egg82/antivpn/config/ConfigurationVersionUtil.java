/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.google.common.io.Files
 */
package me.egg82.antivpn.config;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;
import me.egg82.antivpn.external.org.spongepowered.configurate.CommentedConfigurationNode;
import me.egg82.antivpn.external.org.spongepowered.configurate.loader.ConfigurationLoader;
import me.egg82.antivpn.external.org.spongepowered.configurate.serialize.SerializationException;
import me.egg82.antivpn.utils.TimeUtil;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ConfigurationVersionUtil {
    private static final Logger logger = LoggerFactory.getLogger(ConfigurationVersionUtil.class);

    private ConfigurationVersionUtil() {
    }

    public static void conformVersion(@NonNull ConfigurationLoader<CommentedConfigurationNode> loader, @NonNull CommentedConfigurationNode config, @NonNull File fileOnDisk) throws IOException {
        double oldVersion = ((CommentedConfigurationNode)config.node(new Object[]{"version"})).getDouble(1.0);
        if (((CommentedConfigurationNode)config.node(new Object[]{"version"})).getDouble(1.0) == 1.0) {
            ConfigurationVersionUtil.to20(config);
        }
        if (((CommentedConfigurationNode)config.node(new Object[]{"version"})).getDouble() == 2.0) {
            ConfigurationVersionUtil.to21(config);
        }
        if (((CommentedConfigurationNode)config.node(new Object[]{"version"})).getDouble() == 2.1) {
            ConfigurationVersionUtil.to22(config);
        }
        if (((CommentedConfigurationNode)config.node(new Object[]{"version"})).getDouble() == 2.2) {
            ConfigurationVersionUtil.to23(config);
        }
        if (((CommentedConfigurationNode)config.node(new Object[]{"version"})).getDouble() == 2.3) {
            ConfigurationVersionUtil.to33(config);
        }
        if (((CommentedConfigurationNode)config.node(new Object[]{"version"})).getDouble() == 3.3) {
            ConfigurationVersionUtil.to34(config);
        }
        if (((CommentedConfigurationNode)config.node(new Object[]{"version"})).getDouble() == 3.4) {
            ConfigurationVersionUtil.to35(config);
        }
        if (((CommentedConfigurationNode)config.node(new Object[]{"version"})).getDouble() == 3.5) {
            ConfigurationVersionUtil.to36(config);
        }
        if (((CommentedConfigurationNode)config.node(new Object[]{"version"})).getDouble() == 3.6) {
            ConfigurationVersionUtil.to37(config);
        }
        if (((CommentedConfigurationNode)config.node(new Object[]{"version"})).getDouble() == 3.7) {
            ConfigurationVersionUtil.to38(config);
        }
        if (((CommentedConfigurationNode)config.node(new Object[]{"version"})).getDouble() == 3.8) {
            ConfigurationVersionUtil.to39(config);
        }
        if (((CommentedConfigurationNode)config.node(new Object[]{"version"})).getDouble() == 3.9) {
            ConfigurationVersionUtil.to49(config);
        }
        if (((CommentedConfigurationNode)config.node(new Object[]{"version"})).getDouble() == 4.9) {
            ConfigurationVersionUtil.to411(config);
        }
        if (((CommentedConfigurationNode)config.node(new Object[]{"version"})).getDouble() == 4.11) {
            ConfigurationVersionUtil.to412(config);
        }
        if (((CommentedConfigurationNode)config.node(new Object[]{"version"})).getDouble() == 4.12) {
            ConfigurationVersionUtil.to413(config);
        }
        if (((CommentedConfigurationNode)config.node(new Object[]{"version"})).getDouble() == 4.13) {
            ConfigurationVersionUtil.to50(config);
        }
        if (((CommentedConfigurationNode)config.node(new Object[]{"version"})).getDouble() == 5.0) {
            ConfigurationVersionUtil.to51(config);
        }
        if (((CommentedConfigurationNode)config.node(new Object[]{"version"})).getDouble() != oldVersion) {
            File backupFile = new File(fileOnDisk.getParent(), fileOnDisk.getName() + ".bak");
            if (backupFile.exists()) {
                Files.delete(backupFile.toPath());
            }
            com.google.common.io.Files.copy((File)fileOnDisk, (File)backupFile);
            loader.save(config);
        }
    }

    private static void to20(@NonNull CommentedConfigurationNode config) throws SerializationException {
        boolean rabbitEnabled = ((CommentedConfigurationNode)config.node(new Object[]{"rabbit", "enabled"})).getBoolean();
        String rabbitAddress = ((CommentedConfigurationNode)config.node(new Object[]{"rabbit", "address"})).getString("");
        int rabbitPort = ((CommentedConfigurationNode)config.node(new Object[]{"rabbit", "port"})).getInt(5672);
        String rabbitUser = ((CommentedConfigurationNode)config.node(new Object[]{"rabbit", "user"})).getString("guest");
        String rabbitPass = ((CommentedConfigurationNode)config.node(new Object[]{"rabbit", "pass"})).getString("guest");
        config.removeChild("rabbit");
        ((CommentedConfigurationNode)config.node(new Object[]{"messaging", "type"})).set(rabbitEnabled ? "rabbit" : "bungee");
        ((CommentedConfigurationNode)config.node(new Object[]{"messaging", "rabbit", "address"})).set(rabbitAddress);
        ((CommentedConfigurationNode)config.node(new Object[]{"messaging", "rabbit", "port"})).set(rabbitPort);
        ((CommentedConfigurationNode)config.node(new Object[]{"messaging", "rabbit", "user"})).set(rabbitUser);
        ((CommentedConfigurationNode)config.node(new Object[]{"messaging", "rabbit", "pass"})).set(rabbitPass);
        String[] order = ((CommentedConfigurationNode)config.node(new Object[]{"sources", "order"})).getString("").split(",\\s?");
        ((CommentedConfigurationNode)config.node(new Object[]{"sources", "order"})).setList(String.class, (List)Arrays.asList(order));
        ((CommentedConfigurationNode)config.node(new Object[]{"ignore"})).setList(String.class, (List)Arrays.asList("127.0.0.1", "localhost", "::1"));
        config.removeChild("async");
        ((CommentedConfigurationNode)config.node(new Object[]{"version"})).set(2.0);
    }

    private static void to21(@NonNull CommentedConfigurationNode config) throws SerializationException {
        ((CommentedConfigurationNode)config.node(new Object[]{"consensus"})).set(-1.0);
        ((CommentedConfigurationNode)config.node(new Object[]{"version"})).set(2.1);
    }

    private static void to22(@NonNull CommentedConfigurationNode config) throws SerializationException {
        ((CommentedConfigurationNode)config.node(new Object[]{"stats", "usage"})).set(Boolean.TRUE);
        ((CommentedConfigurationNode)config.node(new Object[]{"stats", "errors"})).set(Boolean.TRUE);
        ((CommentedConfigurationNode)config.node(new Object[]{"update", "check"})).set(Boolean.TRUE);
        ((CommentedConfigurationNode)config.node(new Object[]{"update", "notify"})).set(Boolean.TRUE);
        ((CommentedConfigurationNode)config.node(new Object[]{"version"})).set(2.2);
    }

    private static void to23(@NonNull CommentedConfigurationNode config) throws SerializationException {
        ArrayList<String> sources;
        ((CommentedConfigurationNode)config.node(new Object[]{"sources", "voxprox", "enabled"})).set(Boolean.FALSE);
        ((CommentedConfigurationNode)config.node(new Object[]{"sources", "voxprox", "key"})).set("");
        try {
            sources = !((CommentedConfigurationNode)config.node(new Object[]{"sources", "order"})).empty() ? new ArrayList<String>(((CommentedConfigurationNode)config.node(new Object[]{"sources", "order"})).getList(String.class)) : new ArrayList();
        }
        catch (SerializationException ex) {
            sources = new ArrayList<String>();
        }
        if (!sources.contains("voxprox")) {
            sources.add("voxprox");
        }
        ((CommentedConfigurationNode)config.node(new Object[]{"sources", "order"})).setList(String.class, (List)sources);
        ((CommentedConfigurationNode)config.node(new Object[]{"version"})).set(2.3);
    }

    private static void to33(@NonNull CommentedConfigurationNode config) throws SerializationException {
        ArrayList ignore;
        String sqlDatabase;
        String sqlType = ((CommentedConfigurationNode)config.node(new Object[]{"sql", "type"})).getString("sqlite");
        int sqlThreads = ((CommentedConfigurationNode)config.node(new Object[]{"sql", "threads"})).getInt(2);
        if (sqlType.equalsIgnoreCase("sqlite")) {
            sqlDatabase = ((CommentedConfigurationNode)config.node(new Object[]{"sql", "sqlite", "file"})).getString("avpn");
            int dotIndex = sqlDatabase.indexOf(46);
            if (dotIndex > 0) {
                sqlDatabase = sqlDatabase.substring(0, dotIndex);
            }
        } else {
            sqlDatabase = ((CommentedConfigurationNode)config.node(new Object[]{"sql", "mysql", "database"})).getString("avpn");
        }
        String mysqlAddress = ((CommentedConfigurationNode)config.node(new Object[]{"sql", "mysql", "address"})).getString("127.0.0.1");
        int mysqlPort = ((CommentedConfigurationNode)config.node(new Object[]{"sql", "mysql", "port"})).getInt(3306);
        String mysqlUser = ((CommentedConfigurationNode)config.node(new Object[]{"sql", "mysql", "user"})).getString("");
        String mysqlPass = ((CommentedConfigurationNode)config.node(new Object[]{"sql", "mysql", "pass"})).getString("");
        config.removeChild("sql");
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "method"})).set(sqlType);
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "data", "address"})).set(mysqlAddress + ":" + mysqlPort);
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "data", "database"})).set(sqlDatabase);
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "data", "prefix"})).set("antivpn_");
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "data", "username"})).set(mysqlUser);
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "data", "password"})).set(mysqlPass);
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "data", "mongodb", "collection-prefix"})).set("");
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "data", "mongodb", "connection-uri"})).set("");
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "settings", "max-pool-size"})).set(sqlThreads);
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "settings", "min-idle"})).set(sqlThreads);
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "settings", "max-lifetime"})).set(1800000L);
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "settings", "timeout"})).set(5000L);
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "settings", "properties", "unicode"})).set(Boolean.TRUE);
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "settings", "properties", "encoding"})).set("utf8");
        String redisAddress = ((CommentedConfigurationNode)config.node(new Object[]{"redis", "address"})).getString("");
        if (redisAddress.isEmpty()) {
            redisAddress = "127.0.0.1";
        }
        int redisPort = ((CommentedConfigurationNode)config.node(new Object[]{"redis", "port"})).getInt(6379);
        String redisPass = ((CommentedConfigurationNode)config.node(new Object[]{"redis", "pass"})).getString("");
        ((CommentedConfigurationNode)config.node(new Object[]{"redis"})).removeChild("port");
        ((CommentedConfigurationNode)config.node(new Object[]{"redis"})).removeChild("pass");
        ((CommentedConfigurationNode)config.node(new Object[]{"redis", "address"})).set(redisAddress + ":" + redisPort);
        ((CommentedConfigurationNode)config.node(new Object[]{"redis", "password"})).set(redisPass);
        String messagingType = ((CommentedConfigurationNode)config.node(new Object[]{"messaging", "type"})).getString("");
        String rabbitAddress = ((CommentedConfigurationNode)config.node(new Object[]{"messaging", "rabbit", "address"})).getString("");
        if (rabbitAddress.isEmpty()) {
            rabbitAddress = "127.0.0.1";
        }
        int rabbitPort = ((CommentedConfigurationNode)config.node(new Object[]{"messaging", "rabbit", "port"})).getInt(5672);
        String rabbitUser = ((CommentedConfigurationNode)config.node(new Object[]{"messaging", "rabbit", "user"})).getString("guest");
        String rabbitPass = ((CommentedConfigurationNode)config.node(new Object[]{"messaging", "rabbit", "pass"})).getString("guest");
        config.removeChild("messaging");
        ((CommentedConfigurationNode)config.node(new Object[]{"rabbitmq", "enabled"})).set(messagingType.equalsIgnoreCase("rabbit") || messagingType.equalsIgnoreCase("rabbitmq") ? Boolean.TRUE : Boolean.FALSE);
        ((CommentedConfigurationNode)config.node(new Object[]{"rabbitmq", "address"})).set(rabbitAddress + ":" + rabbitPort);
        ((CommentedConfigurationNode)config.node(new Object[]{"rabbitmq", "username"})).set(rabbitUser);
        ((CommentedConfigurationNode)config.node(new Object[]{"rabbitmq", "password"})).set(rabbitPass);
        boolean kick = ((CommentedConfigurationNode)config.node(new Object[]{"kick"})).getBoolean(true);
        config.removeChild("kick");
        ((CommentedConfigurationNode)config.node(new Object[]{"kick", "enabled"})).set(kick);
        try {
            ignore = !((CommentedConfigurationNode)config.node(new Object[]{"ignore"})).empty() ? ((CommentedConfigurationNode)config.node(new Object[]{"ignore"})).getList(String.class) : new ArrayList();
        }
        catch (SerializationException ex) {
            ignore = new ArrayList();
        }
        config.removeChild("ignore");
        ((CommentedConfigurationNode)config.node(new Object[]{"kick", "ignore"})).setList(String.class, (List)ignore);
        String kickMessage = ((CommentedConfigurationNode)config.node(new Object[]{"kickMessage"})).getString("");
        config.removeChild("kickMessage");
        ((CommentedConfigurationNode)config.node(new Object[]{"kick", "message"})).set(kickMessage);
        double consensus = ((CommentedConfigurationNode)config.node(new Object[]{"consensus"})).getDouble();
        ((CommentedConfigurationNode)config.node(new Object[]{"kick", "algorithm", "method"})).set(consensus >= 0.0 ? "consensus" : "cascade");
        ((CommentedConfigurationNode)config.node(new Object[]{"kick", "algorithm", "min-consensus"})).set(consensus >= 0.0 ? consensus : 0.6);
        config.removeChild("consensus");
        ((CommentedConfigurationNode)config.node(new Object[]{"threads"})).set(4);
        ((CommentedConfigurationNode)config.node(new Object[]{"version"})).set(3.3);
    }

    private static void to34(@NonNull CommentedConfigurationNode config) throws SerializationException {
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "data", "ssl"})).set(Boolean.FALSE);
        ((CommentedConfigurationNode)config.node(new Object[]{"version"})).set(3.4);
    }

    private static void to35(@NonNull CommentedConfigurationNode config) throws SerializationException {
        ArrayList<String> order = !((CommentedConfigurationNode)config.node(new Object[]{"sources", "order"})).empty() ? new ArrayList<String>(((CommentedConfigurationNode)config.node(new Object[]{"sources", "order"})).getList(String.class)) : new ArrayList();
        ArrayList<String> removed = new ArrayList<String>();
        for (String source : order) {
            if (!source.equalsIgnoreCase("ipdetector")) continue;
            removed.add(source);
        }
        order.removeAll(removed);
        ((CommentedConfigurationNode)config.node(new Object[]{"sources", "order"})).setList(String.class, (List)order);
        ((CommentedConfigurationNode)config.node(new Object[]{"sources"})).removeChild("ipdetector");
        ((CommentedConfigurationNode)config.node(new Object[]{"version"})).set(3.5);
    }

    private static void to36(@NonNull CommentedConfigurationNode config) throws SerializationException {
        ArrayList<String> sources;
        ((CommentedConfigurationNode)config.node(new Object[]{"sources", "ipwarner", "enabled"})).set(Boolean.FALSE);
        ((CommentedConfigurationNode)config.node(new Object[]{"sources", "ipwarner", "key"})).set("");
        try {
            sources = !((CommentedConfigurationNode)config.node(new Object[]{"sources", "order"})).empty() ? new ArrayList<String>(((CommentedConfigurationNode)config.node(new Object[]{"sources", "order"})).getList(String.class)) : new ArrayList();
        }
        catch (SerializationException ex) {
            sources = new ArrayList<String>();
        }
        if (!sources.contains("ipwarner")) {
            sources.add("ipwarner");
        }
        ((CommentedConfigurationNode)config.node(new Object[]{"sources", "order"})).setList(String.class, (List)sources);
        ((CommentedConfigurationNode)config.node(new Object[]{"version"})).set(3.6);
    }

    private static void to37(@NonNull CommentedConfigurationNode config) throws SerializationException {
        ArrayList<String> ignore;
        boolean kickEnabled = ((CommentedConfigurationNode)config.node(new Object[]{"kick", "enabled"})).getBoolean(true);
        String kickMessage = ((CommentedConfigurationNode)config.node(new Object[]{"kick", "message"})).getString("");
        ((CommentedConfigurationNode)config.node(new Object[]{"action", "kick-message"})).set(kickEnabled ? kickMessage : "");
        String algorithmMethod = ((CommentedConfigurationNode)config.node(new Object[]{"kick", "algorithm", "method"})).getString("");
        double algorithmConsensus = ((CommentedConfigurationNode)config.node(new Object[]{"kick", "algorithm", "min-consensus"})).getDouble(0.6);
        ((CommentedConfigurationNode)config.node(new Object[]{"action", "algorithm", "method"})).set(algorithmMethod);
        ((CommentedConfigurationNode)config.node(new Object[]{"action", "algorithm", "min-consensus"})).set(algorithmConsensus);
        try {
            ignore = !((CommentedConfigurationNode)config.node(new Object[]{"kick", "ignore"})).empty() ? new ArrayList<String>(((CommentedConfigurationNode)config.node(new Object[]{"kick", "ignore"})).getList(String.class)) : new ArrayList();
        }
        catch (SerializationException ex) {
            ignore = new ArrayList<String>();
        }
        ((CommentedConfigurationNode)config.node(new Object[]{"action", "ignore"})).setList(String.class, (List)ignore);
        config.removeChild("kick");
        ((CommentedConfigurationNode)config.node(new Object[]{"action", "command"})).set("");
        ((CommentedConfigurationNode)config.node(new Object[]{"version"})).set(3.7);
    }

    private static void to38(@NonNull CommentedConfigurationNode config) throws SerializationException {
        ArrayList<String> sources;
        ArrayList<String> order = !((CommentedConfigurationNode)config.node(new Object[]{"sources", "order"})).empty() ? new ArrayList<String>(((CommentedConfigurationNode)config.node(new Object[]{"sources", "order"})).getList(String.class)) : new ArrayList();
        ArrayList<String> removed = new ArrayList<String>();
        for (String source : order) {
            if (!source.equalsIgnoreCase("voxprox")) continue;
            removed.add(source);
        }
        order.removeAll(removed);
        ((CommentedConfigurationNode)config.node(new Object[]{"sources", "order"})).setList(String.class, (List)order);
        ((CommentedConfigurationNode)config.node(new Object[]{"sources"})).removeChild("voxprox");
        ((CommentedConfigurationNode)config.node(new Object[]{"sources", "teoh", "enabled"})).set(Boolean.TRUE);
        ((CommentedConfigurationNode)config.node(new Object[]{"sources", "iphunter", "enabled"})).set(Boolean.FALSE);
        ((CommentedConfigurationNode)config.node(new Object[]{"sources", "iphunter", "key"})).set("");
        ((CommentedConfigurationNode)config.node(new Object[]{"sources", "iphunter", "block"})).set(1);
        try {
            sources = !((CommentedConfigurationNode)config.node(new Object[]{"sources", "order"})).empty() ? new ArrayList<String>(((CommentedConfigurationNode)config.node(new Object[]{"sources", "order"})).getList(String.class)) : new ArrayList();
        }
        catch (SerializationException ex) {
            sources = new ArrayList<String>();
        }
        if (!sources.contains("teoh")) {
            sources.add("teoh");
        }
        if (!sources.contains("iphunter")) {
            sources.add("iphunter");
        }
        ((CommentedConfigurationNode)config.node(new Object[]{"sources", "order"})).setList(String.class, (List)sources);
        ((CommentedConfigurationNode)config.node(new Object[]{"version"})).set(3.8);
    }

    private static void to39(@NonNull CommentedConfigurationNode config) throws SerializationException {
        ArrayList<String> sources;
        ((CommentedConfigurationNode)config.node(new Object[]{"sources", "ip2proxy", "enabled"})).set(Boolean.TRUE);
        ((CommentedConfigurationNode)config.node(new Object[]{"sources", "ip2proxy", "key"})).set("demo");
        try {
            sources = !((CommentedConfigurationNode)config.node(new Object[]{"sources", "order"})).empty() ? new ArrayList<String>(((CommentedConfigurationNode)config.node(new Object[]{"sources", "order"})).getList(String.class)) : new ArrayList();
        }
        catch (SerializationException ex) {
            sources = new ArrayList<String>();
        }
        if (!sources.contains("ip2proxy")) {
            sources.add("ip2proxy");
        }
        ((CommentedConfigurationNode)config.node(new Object[]{"sources", "order"})).setList(String.class, (List)sources);
        ((CommentedConfigurationNode)config.node(new Object[]{"version"})).set(3.9);
    }

    private static void to49(@NonNull CommentedConfigurationNode config) throws SerializationException {
        String storageMethod = ((CommentedConfigurationNode)config.node(new Object[]{"storage", "method"})).getString("sqlite");
        String storageAddress = ((CommentedConfigurationNode)config.node(new Object[]{"storage", "data", "address"})).getString("127.0.0.1:3306");
        String storageDatabase = ((CommentedConfigurationNode)config.node(new Object[]{"storage", "data", "database"})).getString("anti_vpn");
        String storagePrefix = ((CommentedConfigurationNode)config.node(new Object[]{"storage", "data", "prefix"})).getString("avpn_");
        String storageUser = ((CommentedConfigurationNode)config.node(new Object[]{"storage", "data", "username"})).getString("");
        String storagePass = ((CommentedConfigurationNode)config.node(new Object[]{"storage", "data", "password"})).getString("");
        boolean storageSSL = ((CommentedConfigurationNode)config.node(new Object[]{"storage", "data", "ssl"})).getBoolean(false);
        int storageMaxPoolSize = ((CommentedConfigurationNode)config.node(new Object[]{"storage", "settings", "max-pool-size"})).getInt(4);
        int storageMinIdle = ((CommentedConfigurationNode)config.node(new Object[]{"storage", "settings", "min-idle"})).getInt(4);
        long storageMaxLifetime = ((CommentedConfigurationNode)config.node(new Object[]{"storage", "settings", "max-lifetime"})).getLong(1800000L);
        long storageTimeout = ((CommentedConfigurationNode)config.node(new Object[]{"storage", "settings", "timeout"})).getLong(5000L);
        boolean storageUnicode = ((CommentedConfigurationNode)config.node(new Object[]{"storage", "settings", "unicode"})).getBoolean(true);
        String storageEncoding = ((CommentedConfigurationNode)config.node(new Object[]{"storage", "settings", "encoding"})).getString("utf8");
        config.removeChild("storage");
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "engines", "mysql", "enabled"})).set(storageMethod.equalsIgnoreCase("mysql"));
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "engines", "mysql", "connection", "address"})).set(storageAddress);
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "engines", "mysql", "connection", "database"})).set(storageDatabase);
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "engines", "mysql", "connection", "prefix"})).set(storagePrefix);
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "engines", "mysql", "connection", "username"})).set(storageUser);
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "engines", "mysql", "connection", "password"})).set(storagePass);
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "engines", "mysql", "connection", "options"})).set("useSSL=" + storageSSL + "&useUnicode=" + storageUnicode + "&characterEncoding=" + storageEncoding);
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "engines", "redis", "enabled"})).set(Boolean.FALSE);
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "engines", "redis", "connection", "address"})).set("127.0.0.1:6379");
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "engines", "redis", "connection", "password"})).set("");
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "engines", "redis", "connection", "prefix"})).set("avpn:");
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "engines", "sqlite", "enabled"})).set(storageMethod.equalsIgnoreCase("sqlite"));
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "engines", "sqlite", "connection", "file"})).set(storageDatabase + ".db");
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "engines", "sqlite", "connection", "prefix"})).set(storagePrefix);
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "engines", "sqlite", "connection", "options"})).set("useUnicode=" + storageUnicode + "&characterEncoding=" + storageEncoding);
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "settings", "max-pool-size"})).set(storageMaxPoolSize);
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "settings", "min-idle"})).set(storageMinIdle);
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "settings", "max-lifetime"})).set(storageMaxLifetime);
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "settings", "timeout"})).set(storageTimeout);
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "order"})).set(Arrays.asList("mysql", "redis", "sqlite"));
        boolean redisEnabled = ((CommentedConfigurationNode)config.node(new Object[]{"redis", "enabled"})).getBoolean(false);
        String redisAddress = ((CommentedConfigurationNode)config.node(new Object[]{"redis", "address"})).getString("127.0.0.1:6379");
        String redisPass = ((CommentedConfigurationNode)config.node(new Object[]{"redis", "password"})).getString("");
        boolean rabbitEnabled = ((CommentedConfigurationNode)config.node(new Object[]{"rabbitmq", "enabled"})).getBoolean(false);
        String rabbitAddress = ((CommentedConfigurationNode)config.node(new Object[]{"rabbitmq", "address"})).getString("127.0.0.1:5672");
        String rabbitUser = ((CommentedConfigurationNode)config.node(new Object[]{"rabbitmq", "username"})).getString("guest");
        String rabbitPass = ((CommentedConfigurationNode)config.node(new Object[]{"rabbitmq", "password"})).getString("guest");
        int messagingMaxPoolSize = ((CommentedConfigurationNode)config.node(new Object[]{"messaging", "settings", "max-pool-size"})).getInt(4);
        int messagingMinIdle = ((CommentedConfigurationNode)config.node(new Object[]{"messaging", "settings", "min-idle"})).getInt(4);
        long messagingMaxLifetime = ((CommentedConfigurationNode)config.node(new Object[]{"messaging", "settings", "max-lifetime"})).getLong(1800000L);
        long messagingTimeout = ((CommentedConfigurationNode)config.node(new Object[]{"messaging", "settings", "timeout"})).getLong(5000L);
        config.removeChild("redis");
        config.removeChild("rabbitmq");
        ((CommentedConfigurationNode)config.node(new Object[]{"messaging", "engines", "redis", "enabled"})).set(redisEnabled);
        ((CommentedConfigurationNode)config.node(new Object[]{"messaging", "engines", "redis", "connection", "address"})).set(redisAddress);
        ((CommentedConfigurationNode)config.node(new Object[]{"messaging", "engines", "redis", "connection", "password"})).set(redisPass);
        ((CommentedConfigurationNode)config.node(new Object[]{"messaging", "engines", "rabbitmq", "enabled"})).set(rabbitEnabled);
        ((CommentedConfigurationNode)config.node(new Object[]{"messaging", "engines", "rabbitmq", "connection", "address"})).set(rabbitAddress);
        ((CommentedConfigurationNode)config.node(new Object[]{"messaging", "engines", "rabbitmq", "connection", "v-host"})).set("/");
        ((CommentedConfigurationNode)config.node(new Object[]{"messaging", "engines", "rabbitmq", "connection", "username"})).set(rabbitUser);
        ((CommentedConfigurationNode)config.node(new Object[]{"messaging", "engines", "rabbitmq", "connection", "password"})).set(rabbitPass);
        ((CommentedConfigurationNode)config.node(new Object[]{"messaging", "settings", "max-pool-size"})).set(messagingMaxPoolSize);
        ((CommentedConfigurationNode)config.node(new Object[]{"messaging", "settings", "min-idle"})).set(messagingMinIdle);
        ((CommentedConfigurationNode)config.node(new Object[]{"messaging", "settings", "max-lifetime"})).set(messagingMaxLifetime);
        ((CommentedConfigurationNode)config.node(new Object[]{"messaging", "settings", "timeout"})).set(messagingTimeout);
        ((CommentedConfigurationNode)config.node(new Object[]{"messaging", "order"})).set(Arrays.asList("rabbitmq", "redis"));
        String kickMessage = ((CommentedConfigurationNode)config.node(new Object[]{"action", "kick-message"})).getString("&cPlease disconnect from your proxy or VPN before re-joining!");
        String algorithmMethod = ((CommentedConfigurationNode)config.node(new Object[]{"action", "algorithm", "method"})).getString("cascade");
        double algorithmMinConsensus = ((CommentedConfigurationNode)config.node(new Object[]{"action", "algorithm", "min-consensus"})).getDouble(0.6);
        String actionCommand = ((CommentedConfigurationNode)config.node(new Object[]{"action", "command"})).getString("");
        ((CommentedConfigurationNode)config.node(new Object[]{"action"})).removeChild("kick-message");
        ((CommentedConfigurationNode)config.node(new Object[]{"action"})).removeChild("command");
        ((CommentedConfigurationNode)config.node(new Object[]{"action"})).removeChild("algorithm");
        ((CommentedConfigurationNode)config.node(new Object[]{"action", "vpn", "kick-message"})).set(kickMessage);
        ((CommentedConfigurationNode)config.node(new Object[]{"action", "vpn", "commands"})).set(Collections.singleton(actionCommand));
        ((CommentedConfigurationNode)config.node(new Object[]{"action", "vpn", "algorithm", "method"})).set(algorithmMethod);
        ((CommentedConfigurationNode)config.node(new Object[]{"action", "vpn", "algorithm", "min-consensus"})).set(algorithmMinConsensus);
        String sourceCacheTime = ((CommentedConfigurationNode)config.node(new Object[]{"sources", "cacheTime"})).getString("6hours");
        ((CommentedConfigurationNode)config.node(new Object[]{"sources"})).removeChild("cacheTime");
        ((CommentedConfigurationNode)config.node(new Object[]{"sources", "cache-time"})).set(sourceCacheTime);
        String cacheTime = ((CommentedConfigurationNode)config.node(new Object[]{"cacheTime"})).getString("1minute");
        int threads = ((CommentedConfigurationNode)config.node(new Object[]{"threads"})).getInt(4);
        config.removeChild("cacheTime");
        config.removeChild("threads");
        ((CommentedConfigurationNode)config.node(new Object[]{"connection", "cache-time"})).set(cacheTime);
        ((CommentedConfigurationNode)config.node(new Object[]{"connection", "threads"})).set(threads);
        ((CommentedConfigurationNode)config.node(new Object[]{"connection", "timeout"})).set(5000L);
        String sourcesCacheTime = ((CommentedConfigurationNode)config.node(new Object[]{"sources", "cacheTime"})).getString("6hours");
        ((CommentedConfigurationNode)config.node(new Object[]{"sources"})).removeChild("cacheTime");
        ((CommentedConfigurationNode)config.node(new Object[]{"sources", "cache-time"})).set(sourcesCacheTime);
        ((CommentedConfigurationNode)config.node(new Object[]{"mcleaks", "cache-time"})).set("1day");
        ((CommentedConfigurationNode)config.node(new Object[]{"mcleaks", "key"})).set("");
        ((CommentedConfigurationNode)config.node(new Object[]{"action", "mcleaks", "kick-message"})).set("&cPlease discontinue your use of an MCLeaks account!");
        ((CommentedConfigurationNode)config.node(new Object[]{"action", "mcleaks", "commands"})).set(Collections.singleton(""));
        ArrayList<String> ignoredIPs = !((CommentedConfigurationNode)config.node(new Object[]{"action", "ignore"})).empty() ? new ArrayList<String>(((CommentedConfigurationNode)config.node(new Object[]{"action", "ignore"})).getList(String.class)) : new ArrayList();
        ArrayList<String> removed = new ArrayList<String>();
        for (String ip : ignoredIPs) {
            if (!ip.equalsIgnoreCase("localhost")) continue;
            removed.add(ip);
        }
        ignoredIPs.removeAll(removed);
        ((CommentedConfigurationNode)config.node(new Object[]{"action", "ignore"})).setList(String.class, (List)ignoredIPs);
        ((CommentedConfigurationNode)config.node(new Object[]{"version"})).set(4.9);
    }

    private static void to411(@NonNull CommentedConfigurationNode config) throws SerializationException {
        ((CommentedConfigurationNode)config.node(new Object[]{"lang"})).set("en");
        ((CommentedConfigurationNode)config.node(new Object[]{"version"})).set(4.11);
    }

    private static void to412(@NonNull CommentedConfigurationNode config) throws SerializationException {
        ((CommentedConfigurationNode)config.node(new Object[]{"sources", "ipqualityscore", "proxy"})).set(Boolean.FALSE);
        ((CommentedConfigurationNode)config.node(new Object[]{"sources", "ipqualityscore", "mobile"})).set(Boolean.TRUE);
        ((CommentedConfigurationNode)config.node(new Object[]{"sources", "ipqualityscore", "strictness"})).set(0);
        ((CommentedConfigurationNode)config.node(new Object[]{"sources", "ipqualityscore", "recent-abuse"})).set(Boolean.TRUE);
        ((CommentedConfigurationNode)config.node(new Object[]{"sources", "ipqualityscore", "threshold"})).set(0.98);
        ((CommentedConfigurationNode)config.node(new Object[]{"version"})).set(4.12);
    }

    private static void to413(@NonNull CommentedConfigurationNode config) throws SerializationException {
        ArrayList<String> ignoredIPs = !((CommentedConfigurationNode)config.node(new Object[]{"action", "ignore"})).empty() ? new ArrayList<String>(((CommentedConfigurationNode)config.node(new Object[]{"action", "ignore"})).getList(String.class)) : new ArrayList();
        ArrayList<String> added = new ArrayList<String>();
        added.add("10.0.0.0/8");
        added.add("172.16.0.0/12");
        added.add("192.168.0.0/16");
        added.add("fd00::/8");
        Iterator i = added.iterator();
        while (i.hasNext()) {
            String ip = (String)i.next();
            for (String ip2 : ignoredIPs) {
                if (!ip.equalsIgnoreCase(ip2)) continue;
                i.remove();
            }
        }
        ignoredIPs.addAll(added);
        ((CommentedConfigurationNode)config.node(new Object[]{"action", "ignore"})).setList(String.class, (List)ignoredIPs);
        ((CommentedConfigurationNode)config.node(new Object[]{"version"})).set(4.13);
    }

    private static void to50(@NonNull CommentedConfigurationNode config) throws SerializationException {
        ArrayList<String> sources;
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "engines", "engine1"})).from(config.node(new Object[]{"storage", "engines", "mysql"}));
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "engines", "engine2"})).from(config.node(new Object[]{"storage", "engines", "sqlite"}));
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "engines", "engine1", "type"})).set("mysql");
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "engines", "engine2", "type"})).set("sqlite");
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "engines"})).removeChild("mysql");
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "engines"})).removeChild("redis");
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "engines"})).removeChild("sqlite");
        ArrayList<String> storageOrder = !((CommentedConfigurationNode)config.node(new Object[]{"storage", "order"})).empty() ? new ArrayList<String>(((CommentedConfigurationNode)config.node(new Object[]{"storage", "order"})).getList(String.class)) : new ArrayList();
        ArrayList<String> newStorageOrder = new ArrayList<String>();
        Iterator iterator = storageOrder.iterator();
        while (iterator.hasNext()) {
            String engine;
            switch (engine = (String)iterator.next()) {
                case "mysql": {
                    newStorageOrder.add("engine1");
                    break;
                }
                case "sqlite": {
                    newStorageOrder.add("engine2");
                    break;
                }
            }
        }
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "order"})).setList(String.class, (List)newStorageOrder);
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "settings", "max-lifetime"})).set(TimeUtil.getTimeString(new TimeUtil.Time(((CommentedConfigurationNode)config.node(new Object[]{"storage", "settings", "max-lifetime"})).getLong(1800000L) / 1000L / 60L, TimeUnit.MINUTES)));
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "settings", "timeout"})).set(TimeUtil.getTimeString(new TimeUtil.Time(((CommentedConfigurationNode)config.node(new Object[]{"storage", "settings", "timeout"})).getLong(5000L) / 1000L, TimeUnit.SECONDS)));
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "engines", "engine1", "connection"})).removeChild("prefix");
        ((CommentedConfigurationNode)config.node(new Object[]{"storage", "engines", "engine2", "connection"})).removeChild("prefix");
        ((CommentedConfigurationNode)config.node(new Object[]{"messaging", "engines", "engine1"})).from(config.node(new Object[]{"messaging", "engines", "rabbitmq"}));
        ((CommentedConfigurationNode)config.node(new Object[]{"messaging", "engines", "engine2"})).from(config.node(new Object[]{"messaging", "engines", "redis"}));
        ((CommentedConfigurationNode)config.node(new Object[]{"messaging", "engines", "engine1", "type"})).set("rabbitmq");
        ((CommentedConfigurationNode)config.node(new Object[]{"messaging", "engines", "engine2", "type"})).set("redis");
        ((CommentedConfigurationNode)config.node(new Object[]{"messaging", "engines"})).removeChild("rabbitmq");
        ((CommentedConfigurationNode)config.node(new Object[]{"messaging", "engines"})).removeChild("redis");
        ((CommentedConfigurationNode)config.node(new Object[]{"messaging"})).removeChild("order");
        ((CommentedConfigurationNode)config.node(new Object[]{"messaging", "settings", "max-lifetime"})).set(TimeUtil.getTimeString(new TimeUtil.Time(((CommentedConfigurationNode)config.node(new Object[]{"messaging", "settings", "max-lifetime"})).getLong(1800000L) / 1000L / 60L, TimeUnit.MINUTES)));
        ((CommentedConfigurationNode)config.node(new Object[]{"messaging", "settings", "timeout"})).set(TimeUtil.getTimeString(new TimeUtil.Time(((CommentedConfigurationNode)config.node(new Object[]{"messaging", "settings", "timeout"})).getLong(5000L) / 1000L, TimeUnit.SECONDS)));
        ((CommentedConfigurationNode)config.node(new Object[]{"connection", "timeout"})).set(TimeUtil.getTimeString(new TimeUtil.Time(((CommentedConfigurationNode)config.node(new Object[]{"connection", "timeout"})).getLong(5000L) / 1000L, TimeUnit.SECONDS)));
        ((CommentedConfigurationNode)config.node(new Object[]{"sources", "ipinfo", "enabled"})).set(Boolean.FALSE);
        ((CommentedConfigurationNode)config.node(new Object[]{"sources", "ipinfo", "key"})).set("");
        ((CommentedConfigurationNode)config.node(new Object[]{"sources", "ipinfo", "proxy"})).set(Boolean.TRUE);
        ArrayList<String> arrayList = sources = !((CommentedConfigurationNode)config.node(new Object[]{"sources", "order"})).empty() ? new ArrayList<String>(((CommentedConfigurationNode)config.node(new Object[]{"sources", "order"})).getList(String.class)) : new ArrayList();
        if (!sources.contains("ipinfo")) {
            sources.add("ipinfo");
        }
        ((CommentedConfigurationNode)config.node(new Object[]{"sources", "order"})).setList(String.class, (List)sources);
        ArrayList<String> order = !((CommentedConfigurationNode)config.node(new Object[]{"sources", "order"})).empty() ? new ArrayList<String>(((CommentedConfigurationNode)config.node(new Object[]{"sources", "order"})).getList(String.class)) : new ArrayList();
        ArrayList<String> removed = new ArrayList<String>();
        for (String source : order) {
            if (!source.equalsIgnoreCase("ipwarner")) continue;
            removed.add(source);
        }
        order.removeAll(removed);
        ((CommentedConfigurationNode)config.node(new Object[]{"sources", "order"})).setList(String.class, (List)order);
        ((CommentedConfigurationNode)config.node(new Object[]{"sources"})).removeChild("ipwarner");
        ((CommentedConfigurationNode)config.node(new Object[]{"sources", "getipintel", "subdomain"})).set("check");
        ((CommentedConfigurationNode)config.node(new Object[]{"version"})).set(5.0);
    }

    private static void to51(@NonNull CommentedConfigurationNode config) throws SerializationException {
        String engine2 = ((CommentedConfigurationNode)config.node(new Object[]{"storage", "engines", "engine2", "type"})).getString();
        if ("sqlite".equalsIgnoreCase(engine2)) {
            ((CommentedConfigurationNode)config.node(new Object[]{"storage", "engines", "engine2", "type"})).set("h2");
            ((CommentedConfigurationNode)config.node(new Object[]{"storage", "engines", "engine2", "connection", "file"})).set("anti_vpn");
        }
        ((CommentedConfigurationNode)config.node(new Object[]{"version"})).set(5.1);
    }
}

/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.core;

import java.util.Objects;
import org.checkerframework.checker.nullness.qual.Nullable;

public class Pair<T1, T2> {
    private final T1 t1;
    private final T2 t2;
    private final int hc;

    public Pair(T1 t1, T2 t2) {
        this.t1 = t1;
        this.t2 = t2;
        this.hc = Objects.hash(t1, t2);
    }

    public @Nullable T1 getT1() {
        return this.t1;
    }

    public @Nullable T2 getT2() {
        return this.t2;
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Pair)) {
            return false;
        }
        Pair pair = (Pair)o;
        return Objects.equals(this.t1, pair.t1) && Objects.equals(this.t2, pair.t2);
    }

    public int hashCode() {
        return this.hc;
    }

    public String toString() {
        return "Pair{t1=" + this.t1 + ", t2=" + this.t2 + '}';
    }
}

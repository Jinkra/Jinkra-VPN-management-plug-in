/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.core;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import org.checkerframework.checker.nullness.qual.NonNull;

public class DoubleBuffer<T> {
    private volatile Queue<T> currentBuffer = new ConcurrentLinkedQueue<T>();
    private volatile Queue<T> backBuffer = new ConcurrentLinkedQueue<T>();
    private final ReadWriteLock lock = new ReentrantReadWriteLock();

    public @NonNull Queue<T> getReadBuffer() {
        this.lock.readLock().lock();
        try {
            Queue<T> queue = this.backBuffer;
            return queue;
        }
        finally {
            this.lock.readLock().unlock();
        }
    }

    public @NonNull Queue<T> getWriteBuffer() {
        this.lock.readLock().lock();
        try {
            Queue<T> queue = this.currentBuffer;
            return queue;
        }
        finally {
            this.lock.readLock().unlock();
        }
    }

    public void swapBuffers() {
        this.lock.writeLock().lock();
        try {
            Queue<T> t = this.currentBuffer;
            this.currentBuffer = this.backBuffer;
            this.backBuffer = t;
        }
        finally {
            this.lock.writeLock().unlock();
        }
    }
}

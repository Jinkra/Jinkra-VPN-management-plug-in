/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.command.CommandSender
 *  org.bukkit.plugin.Plugin
 */
package me.egg82.antivpn.commands;

import me.egg82.antivpn.commands.internal.CheckCommand;
import me.egg82.antivpn.commands.internal.ImportCommand;
import me.egg82.antivpn.commands.internal.KickCommand;
import me.egg82.antivpn.commands.internal.ReloadCommand;
import me.egg82.antivpn.commands.internal.ScoreCommand;
import me.egg82.antivpn.commands.internal.TestCommand;
import me.egg82.antivpn.external.co.aikar.commands.BaseCommand;
import me.egg82.antivpn.external.co.aikar.commands.CommandHelp;
import me.egg82.antivpn.external.co.aikar.commands.CommandIssuer;
import me.egg82.antivpn.external.co.aikar.commands.annotation.CatchUnknown;
import me.egg82.antivpn.external.co.aikar.commands.annotation.CommandAlias;
import me.egg82.antivpn.external.co.aikar.commands.annotation.CommandCompletion;
import me.egg82.antivpn.external.co.aikar.commands.annotation.CommandPermission;
import me.egg82.antivpn.external.co.aikar.commands.annotation.Conditions;
import me.egg82.antivpn.external.co.aikar.commands.annotation.Default;
import me.egg82.antivpn.external.co.aikar.commands.annotation.Description;
import me.egg82.antivpn.external.co.aikar.commands.annotation.HelpCommand;
import me.egg82.antivpn.external.co.aikar.commands.annotation.Subcommand;
import me.egg82.antivpn.external.co.aikar.commands.annotation.Syntax;
import me.egg82.antivpn.external.co.aikar.taskchain.TaskChainFactory;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.Plugin;
import org.checkerframework.checker.nullness.qual.NonNull;

@CommandAlias(value="antivpn|avpn")
public class AntiVPNCommand
extends BaseCommand {
    private final Plugin plugin;
    private final TaskChainFactory taskFactory;
    private final CommandIssuer console;

    public AntiVPNCommand(@NonNull Plugin plugin, @NonNull TaskChainFactory taskFactory, @NonNull CommandIssuer console) {
        this.plugin = plugin;
        this.taskFactory = taskFactory;
        this.console = console;
    }

    @Subcommand(value="reload")
    @CommandPermission(value="avpn.admin")
    @Description(value="{@@description.reload}")
    public void onReload(@NonNull CommandIssuer issuer) {
        new ReloadCommand(issuer, this.taskFactory, this.plugin.getDataFolder(), this.console, this.plugin).run();
    }

    @Subcommand(value="import")
    @CommandPermission(value="avpn.admin")
    @Description(value="{@@description.import}")
    @Syntax(value="<master> <slave> [batchSize]")
    @CommandCompletion(value="@storage @storage @nothing")
    public void onImport(@NonNull CommandIssuer issuer, @Conditions(value="storage") @NonNull String master, @Conditions(value="storage") @NonNull String slave, @Default(value="50") String batchSize) {
        new ImportCommand(issuer, this.taskFactory, master, slave, batchSize).run();
    }

    @Subcommand(value="kick")
    @CommandPermission(value="avpn.admin")
    @Description(value="{@@description.kick}")
    @Syntax(value="<player> [type]")
    @CommandCompletion(value="@player @type")
    public void onKick(@NonNull CommandIssuer issuer, @NonNull String player, @Default(value="vpn") String type) {
        new KickCommand(issuer, this.taskFactory, player, type, this.plugin).run();
    }

    @Subcommand(value="test")
    @CommandPermission(value="avpn.admin")
    @Description(value="{@@description.test}")
    @Syntax(value="<ip>")
    @CommandCompletion(value="@nothing")
    public void onTest(@NonNull CommandIssuer issuer, @Conditions(value="ip") @NonNull String ip) {
        new TestCommand(issuer, this.taskFactory, ip).run();
    }

    @Subcommand(value="score")
    @CommandPermission(value="avpn.admin")
    @Description(value="{@@description.score}")
    @Syntax(value="<source>")
    @CommandCompletion(value="@source @nothing")
    public void onScore(@NonNull CommandIssuer issuer, @Conditions(value="source") @NonNull String source) {
        new ScoreCommand(issuer, this.taskFactory, source).run();
    }

    @Subcommand(value="check")
    @CommandPermission(value="avpn.admin")
    @Description(value="{@@description.check}")
    @Syntax(value="<ip|player>")
    @CommandCompletion(value="@player @nothing")
    public void onCheck(@NonNull CommandIssuer issuer, @NonNull String type) {
        new CheckCommand(issuer, this.taskFactory, type).run();
    }

    @CatchUnknown
    @Default
    @CommandCompletion(value="@subcommand")
    public void onDefault(@NonNull CommandSender sender, String[] args) {
        Bukkit.getServer().dispatchCommand(sender, "antivpn help");
    }

    @HelpCommand
    @Syntax(value="[command]")
    public void onHelp(@NonNull CommandSender sender, @NonNull CommandHelp help) {
        help.showHelp();
    }
}

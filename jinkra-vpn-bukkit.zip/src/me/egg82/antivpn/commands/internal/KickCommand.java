/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 */
package me.egg82.antivpn.commands.internal;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import me.egg82.antivpn.api.VPNAPIProvider;
import me.egg82.antivpn.api.model.ip.IPManager;
import me.egg82.antivpn.api.model.player.PlayerManager;
import me.egg82.antivpn.commands.internal.AbstractCommand;
import me.egg82.antivpn.config.CachedConfig;
import me.egg82.antivpn.config.ConfigUtil;
import me.egg82.antivpn.external.co.aikar.commands.CommandIssuer;
import me.egg82.antivpn.external.co.aikar.taskchain.TaskChainFactory;
import me.egg82.antivpn.lang.Message;
import me.egg82.antivpn.utils.BukkitCommandUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.checkerframework.checker.nullness.qual.Nullable;

public class KickCommand
extends AbstractCommand {
    private final String player;
    private final String type;
    private final Plugin plugin;

    public KickCommand(@NonNull CommandIssuer issuer, @NonNull TaskChainFactory taskFactory, @NonNull String player, @NonNull String type, @NonNull Plugin plugin) {
        super(issuer, taskFactory);
        this.player = player;
        this.type = type;
        this.plugin = plugin;
    }

    @Override
    public void run() {
        CachedConfig cachedConfig = ConfigUtil.getCachedConfig();
        if (cachedConfig == null) {
            this.logger.error("Cached config could not be fetched.");
            this.issuer.sendError(Message.ERROR__INTERNAL, new String[0]);
            return;
        }
        Player p = Bukkit.getPlayerExact((String)this.player);
        if (p == null) {
            this.issuer.sendError(Message.KICK__NO_PLAYER, new String[0]);
            return;
        }
        String ip = this.getIp(p);
        if (ip == null) {
            this.logger.error("Could not get IP for player " + p.getName());
            this.issuer.sendError(Message.ERROR__INTERNAL, new String[0]);
            return;
        }
        if (this.type.equalsIgnoreCase("vpn")) {
            IPManager ipManager = VPNAPIProvider.getInstance().getIPManager();
            if (cachedConfig.getVPNActionCommands().isEmpty() && cachedConfig.getVPNKickMessage().isEmpty()) {
                this.issuer.sendError(Message.KICK__API_MODE, new String[0]);
                return;
            }
            BukkitCommandUtil.dispatchCommands(ipManager.getVpnCommands(p.getName(), p.getUniqueId(), ip), (CommandSender)Bukkit.getConsoleSender(), this.plugin, false);
            String kickMessage = ipManager.getVpnKickMessage(p.getName(), p.getUniqueId(), ip);
            if (kickMessage != null) {
                p.kickPlayer(kickMessage);
            }
            this.issuer.sendInfo(Message.KICK__END_VPN, "{player}", this.player);
        } else if (this.type.equalsIgnoreCase("mcleaks")) {
            PlayerManager playerManager = VPNAPIProvider.getInstance().getPlayerManager();
            if (cachedConfig.getMCLeaksActionCommands().isEmpty() && cachedConfig.getMCLeaksKickMessage().isEmpty()) {
                this.issuer.sendError(Message.KICK__API_MODE, new String[0]);
                return;
            }
            BukkitCommandUtil.dispatchCommands(playerManager.getMcLeaksCommands(p.getName(), p.getUniqueId(), ip), (CommandSender)Bukkit.getConsoleSender(), this.plugin, false);
            String kickMessage = playerManager.getMcLeaksKickMessage(p.getName(), p.getUniqueId(), ip);
            if (kickMessage != null) {
                p.kickPlayer(kickMessage);
            }
            this.issuer.sendInfo(Message.KICK__END_MCLEAKS, "{player}", this.player);
        }
    }

    private @Nullable String getIp(@NonNull Player player) {
        InetSocketAddress address = player.getAddress();
        if (address == null) {
            return null;
        }
        InetAddress host = address.getAddress();
        if (host == null) {
            return null;
        }
        return host.getHostAddress();
    }
}

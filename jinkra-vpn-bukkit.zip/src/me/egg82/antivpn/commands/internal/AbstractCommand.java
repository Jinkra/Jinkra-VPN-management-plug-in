/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.commands.internal;

import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import me.egg82.antivpn.external.co.aikar.commands.CommandIssuer;
import me.egg82.antivpn.external.co.aikar.taskchain.TaskChain;
import me.egg82.antivpn.external.co.aikar.taskchain.TaskChainAbortAction;
import me.egg82.antivpn.external.co.aikar.taskchain.TaskChainFactory;
import me.egg82.antivpn.lang.Message;
import me.egg82.antivpn.services.lookup.PlayerInfo;
import me.egg82.antivpn.services.lookup.PlayerLookup;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class AbstractCommand
implements Runnable {
    protected final Logger logger = LoggerFactory.getLogger(this.getClass());
    protected final CommandIssuer issuer;
    protected final TaskChainFactory taskFactory;
    protected final TaskChainAbortAction<?, ?, ?> handleAbort = new TaskChainAbortAction<Object, Object, Object>(){

        @Override
        public void onAbort(TaskChain<?> chain, Object arg1, Object arg2, Object arg3) {
            AbstractCommand.this.issuer.sendError(Message.ERROR__INTERNAL, new String[0]);
        }
    };

    protected AbstractCommand(@NonNull CommandIssuer issuer, @NonNull TaskChainFactory taskFactory) {
        this.issuer = issuer;
        this.taskFactory = taskFactory;
    }

    protected @NonNull CompletableFuture<UUID> fetchUuid(@NonNull String name) {
        return PlayerLookup.get(name).thenApply(PlayerInfo::getUUID);
    }
}

/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.commands.internal;

import me.egg82.antivpn.external.co.aikar.taskchain.TaskChain;
import me.egg82.antivpn.external.co.aikar.taskchain.TaskChainAbortAction;
import me.egg82.antivpn.lang.Message;

class AbstractCommand.1
implements TaskChainAbortAction<Object, Object, Object> {
    AbstractCommand.1() {
    }

    @Override
    public void onAbort(TaskChain<?> chain, Object arg1, Object arg2, Object arg3) {
        AbstractCommand.this.issuer.sendError(Message.ERROR__INTERNAL, new String[0]);
    }
}

/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.commands.internal;

import java.util.UUID;
import me.egg82.antivpn.api.VPNAPIProvider;
import me.egg82.antivpn.api.model.ip.AlgorithmMethod;
import me.egg82.antivpn.api.model.ip.IPManager;
import me.egg82.antivpn.api.model.player.PlayerManager;
import me.egg82.antivpn.commands.internal.AbstractCommand;
import me.egg82.antivpn.external.co.aikar.commands.CommandIssuer;
import me.egg82.antivpn.external.co.aikar.taskchain.TaskChain;
import me.egg82.antivpn.external.co.aikar.taskchain.TaskChainFactory;
import me.egg82.antivpn.lang.Message;
import me.egg82.antivpn.utils.ExceptionUtil;
import me.egg82.antivpn.utils.ValidationUtil;
import org.checkerframework.checker.nullness.qual.NonNull;

public class CheckCommand
extends AbstractCommand {
    private final String type;

    public CheckCommand(@NonNull CommandIssuer issuer, @NonNull TaskChainFactory taskFactory, @NonNull String type) {
        super(issuer, taskFactory);
        this.type = type;
    }

    @Override
    public void run() {
        this.issuer.sendInfo(Message.CHECK__BEGIN, "{type}", this.type);
        if (ValidationUtil.isValidIp(this.type)) {
            this.checkIp(this.type);
        } else {
            this.checkPlayer(this.type);
        }
    }

    private void checkIp(@NonNull String ip) {
        IPManager ipManager = VPNAPIProvider.getInstance().getIPManager();
        if (ipManager.getCurrentAlgorithmMethod() == AlgorithmMethod.CONSESNSUS) {
            TaskChain chain = this.taskFactory.newChain();
            chain.setErrorHandler((ex, task) -> ExceptionUtil.handleException(ex, this.logger));
            chain.asyncFirstFuture(() -> ipManager.consensus(ip, true)).abortIfNull(this.handleAbort).syncLast(v -> this.issuer.sendInfo(v >= ipManager.getMinConsensusValue() ? Message.CHECK__VPN_DETECTED : Message.CHECK__NO_VPN_DETECTED, new String[0])).execute();
        } else {
            TaskChain chain = this.taskFactory.newChain();
            chain.setErrorHandler((ex, task) -> ExceptionUtil.handleException(ex, this.logger));
            chain.asyncFirstFuture(() -> ipManager.cascade(ip, true)).abortIfNull(this.handleAbort).syncLast(v -> this.issuer.sendInfo(Boolean.TRUE.equals(v) ? Message.CHECK__VPN_DETECTED : Message.CHECK__NO_VPN_DETECTED, new String[0])).execute();
        }
    }

    private void checkPlayer(@NonNull String playerName) {
        PlayerManager playerManager = VPNAPIProvider.getInstance().getPlayerManager();
        TaskChain chain = this.taskFactory.newChain();
        chain.setErrorHandler((ex, task) -> ExceptionUtil.handleException(ex, this.logger));
        chain.asyncFirstFuture(() -> this.fetchUuid(playerName)).abortIfNull(this.handleAbort).asyncFuture(v -> playerManager.checkMcLeaks((UUID)v, true)).abortIfNull(this.handleAbort).syncLast(v -> this.issuer.sendInfo(Boolean.TRUE.equals(v) ? Message.CHECK__MCLEAKS_DETECTED : Message.CHECK__NO_MCLEAKS_DETECTED, new String[0])).execute();
    }
}

/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.commands.internal;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import me.egg82.antivpn.api.VPNAPIProvider;
import me.egg82.antivpn.api.model.source.Source;
import me.egg82.antivpn.api.model.source.SourceManager;
import me.egg82.antivpn.api.model.source.models.SourceModel;
import me.egg82.antivpn.commands.internal.AbstractCommand;
import me.egg82.antivpn.config.CachedConfig;
import me.egg82.antivpn.config.ConfigUtil;
import me.egg82.antivpn.external.co.aikar.commands.CommandIssuer;
import me.egg82.antivpn.external.co.aikar.taskchain.TaskChain;
import me.egg82.antivpn.external.co.aikar.taskchain.TaskChainFactory;
import me.egg82.antivpn.lang.Message;
import me.egg82.antivpn.utils.ExceptionUtil;
import org.checkerframework.checker.nullness.qual.NonNull;

public class TestCommand
extends AbstractCommand {
    private final String ip;

    public TestCommand(@NonNull CommandIssuer issuer, @NonNull TaskChainFactory taskFactory, @NonNull String ip) {
        super(issuer, taskFactory);
        this.ip = ip;
    }

    @Override
    public void run() {
        this.issuer.sendInfo(Message.TEST__BEGIN, "{ip}", this.ip);
        SourceManager sourceManager = VPNAPIProvider.getInstance().getSourceManager();
        TaskChain<Void> chain = this.taskFactory.newChain();
        chain.setErrorHandler((ex, task) -> ExceptionUtil.handleException(ex, this.logger));
        chain.asyncCallback((v, r) -> {
            CachedConfig cachedConfig = ConfigUtil.getCachedConfig();
            if (cachedConfig == null) {
                this.logger.error("Cached config could not be fetched.");
                r.accept(new HashMap());
                return;
            }
            ArrayList<CompletionStage> futures = new ArrayList<CompletionStage>();
            List<Source<? extends SourceModel>> sources = sourceManager.getSources();
            CountDownLatch latch = new CountDownLatch(sources.size());
            ConcurrentHashMap<String, Optional> results = new ConcurrentHashMap<String, Optional>(sources.size());
            for (Source<? extends SourceModel> source : sources) {
                if (cachedConfig.getDebug()) {
                    this.logger.info("Getting result from source " + source.getName() + ".");
                }
                futures.add(source.getResult(this.ip).whenCompleteAsync((val, ex) -> {
                    if (ex != null) {
                        ExceptionUtil.handleException(ex, this.logger);
                        latch.countDown();
                        return;
                    }
                    results.put(source.getName(), Optional.ofNullable(val));
                    latch.countDown();
                }));
            }
            try {
                if (!latch.await(20L, TimeUnit.SECONDS)) {
                    this.logger.warn("Test timed out before all sources could be queried.");
                }
            }
            catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
            }
            for (CompletableFuture completableFuture : futures) {
                completableFuture.cancel(true);
            }
            LinkedHashMap<String, Optional> retVal = new LinkedHashMap<String, Optional>(sources.size());
            for (Source<? extends SourceModel> source : sources) {
                retVal.put(source.getName(), results.computeIfAbsent(source.getName(), k -> Optional.empty()));
            }
            r.accept(retVal);
        }).syncLast(v -> {
            if (v.isEmpty()) {
                this.issuer.sendError(Message.ERROR__INTERNAL, new String[0]);
                return;
            }
            for (Map.Entry kvp : v.entrySet()) {
                if (!((Optional)kvp.getValue()).isPresent()) {
                    this.issuer.sendInfo(Message.TEST__ERROR, "{source}", (String)kvp.getKey());
                    continue;
                }
                this.issuer.sendInfo((Boolean)((Optional)kvp.getValue()).get() != false ? Message.TEST__VPN_DETECTED : Message.TEST__NO_VPN_DETECTED, "{source}", (String)kvp.getKey());
            }
            this.issuer.sendInfo(Message.TEST__END, "{ip}", this.ip);
        }).execute();
    }
}

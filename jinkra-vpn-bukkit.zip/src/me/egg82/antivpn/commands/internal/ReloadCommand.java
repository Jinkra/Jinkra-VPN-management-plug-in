/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.bukkit.plugin.Plugin
 */
package me.egg82.antivpn.commands.internal;

import java.io.File;
import me.egg82.antivpn.api.APIRegistrationUtil;
import me.egg82.antivpn.api.APIUtil;
import me.egg82.antivpn.api.GenericVPNAPI;
import me.egg82.antivpn.api.VPNAPI;
import me.egg82.antivpn.api.VPNAPIProvider;
import me.egg82.antivpn.api.event.api.GenericAPILoadedEvent;
import me.egg82.antivpn.api.event.api.GenericAPIReloadEvent;
import me.egg82.antivpn.api.model.ip.BukkitIPManager;
import me.egg82.antivpn.api.model.player.BukkitPlayerManager;
import me.egg82.antivpn.api.model.source.GenericSourceManager;
import me.egg82.antivpn.commands.internal.AbstractCommand;
import me.egg82.antivpn.config.CachedConfig;
import me.egg82.antivpn.config.ConfigUtil;
import me.egg82.antivpn.config.ConfigurationFileUtil;
import me.egg82.antivpn.external.co.aikar.commands.CommandIssuer;
import me.egg82.antivpn.external.co.aikar.taskchain.TaskChain;
import me.egg82.antivpn.external.co.aikar.taskchain.TaskChainFactory;
import me.egg82.antivpn.external.ninja.egg82.service.ServiceLocator;
import me.egg82.antivpn.lang.Message;
import me.egg82.antivpn.messaging.GenericMessagingHandler;
import me.egg82.antivpn.utils.ExceptionUtil;
import net.engio.mbassy.bus.publication.SyncAsyncPostCommand;
import org.bukkit.plugin.Plugin;
import org.checkerframework.checker.nullness.qual.NonNull;

public class ReloadCommand
extends AbstractCommand {
    private final File dataFolder;
    private final CommandIssuer console;
    private final Plugin plugin;

    public ReloadCommand(@NonNull CommandIssuer issuer, @NonNull TaskChainFactory taskFactory, @NonNull File dataFolder, @NonNull CommandIssuer console, @NonNull Plugin plugin) {
        super(issuer, taskFactory);
        this.dataFolder = dataFolder;
        this.console = console;
        this.plugin = plugin;
    }

    @Override
    public void run() {
        this.issuer.sendInfo(Message.RELOAD__BEGIN, new String[0]);
        TaskChain chain = this.taskFactory.newChain();
        chain.setErrorHandler((ex, task) -> ExceptionUtil.handleException(ex, this.logger));
        chain.async(() -> {
            CachedConfig cachedConfig = ConfigUtil.getCachedConfig();
            if (cachedConfig == null) {
                this.logger.error("Could not get cached config.");
                return;
            }
            for (Object service : cachedConfig.getMessaging()) {
                service.close();
            }
            for (Object service : cachedConfig.getStorage()) {
                service.close();
            }
            GenericSourceManager sourceManager = new GenericSourceManager();
            GenericMessagingHandler messagingHandler = new GenericMessagingHandler();
            ServiceLocator.register(messagingHandler);
            ConfigurationFileUtil.reloadConfig(this.dataFolder, this.console, messagingHandler, sourceManager);
            cachedConfig = ConfigUtil.getCachedConfig();
            BukkitIPManager ipManager = new BukkitIPManager(this.plugin, sourceManager, cachedConfig.getCacheTime().getTime(), cachedConfig.getCacheTime().getUnit());
            BukkitPlayerManager playerManager = new BukkitPlayerManager(this.plugin, cachedConfig.getThreads(), cachedConfig.getMcLeaksKey(), cachedConfig.getCacheTime().getTime(), cachedConfig.getCacheTime().getUnit());
            VPNAPI api = VPNAPIProvider.getInstance();
            ((SyncAsyncPostCommand)api.getEventBus().post((Object)new GenericAPIReloadEvent(api, ipManager, playerManager, sourceManager))).now();
            api = new GenericVPNAPI(api.getPlatform(), api.getPluginMetadata(), ipManager, playerManager, sourceManager, cachedConfig, api.getEventBus());
            APIUtil.setManagers(ipManager, playerManager, sourceManager);
            APIRegistrationUtil.register(api);
            ((SyncAsyncPostCommand)api.getEventBus().post((Object)new GenericAPILoadedEvent(api))).now();
        }).syncLast(v -> this.issuer.sendInfo(Message.RELOAD__END, new String[0])).execute();
    }
}

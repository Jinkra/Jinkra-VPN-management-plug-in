/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.commands.internal;

import java.text.DecimalFormat;
import java.util.Set;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import me.egg82.antivpn.api.APIException;
import me.egg82.antivpn.api.VPNAPIProvider;
import me.egg82.antivpn.api.model.source.Source;
import me.egg82.antivpn.api.model.source.SourceManager;
import me.egg82.antivpn.api.model.source.models.SourceModel;
import me.egg82.antivpn.commands.internal.AbstractCommand;
import me.egg82.antivpn.config.ConfigUtil;
import me.egg82.antivpn.external.co.aikar.commands.CommandIssuer;
import me.egg82.antivpn.external.co.aikar.taskchain.TaskChain;
import me.egg82.antivpn.external.co.aikar.taskchain.TaskChainFactory;
import me.egg82.antivpn.lang.Message;
import me.egg82.antivpn.utils.DNSUtil;
import me.egg82.antivpn.utils.ExceptionUtil;
import org.checkerframework.checker.nullness.qual.NonNull;

public class ScoreCommand
extends AbstractCommand {
    private final String sourceName;
    private static final DecimalFormat format = new DecimalFormat("##0.00");

    public ScoreCommand(@NonNull CommandIssuer issuer, @NonNull TaskChainFactory taskFactory, @NonNull String sourceName) {
        super(issuer, taskFactory);
        this.sourceName = sourceName;
    }

    @Override
    public void run() {
        this.issuer.sendInfo(Message.SCORE__BEGIN, "{source}", this.sourceName);
        SourceManager sourceManager = VPNAPIProvider.getInstance().getSourceManager();
        TaskChain<Void> chain = this.taskFactory.newChain();
        chain.setErrorHandler((ex, task) -> ExceptionUtil.handleException(ex, this.logger));
        chain.currentCallback((v, r) -> r.accept(sourceManager.getSource(this.sourceName))).abortIfNull(this.handleAbort).sync(v -> {
            this.issuer.sendInfo(Message.SCORE__TYPE, "{type}", "NordVPN");
            return v;
        }).async(v -> {
            this.test((Source<? extends SourceModel>)v, "NordVPN", DNSUtil.getNordVpnIps());
            return v;
        }).sync(v -> {
            this.issuer.sendInfo(Message.SCORE__SLEEP, new String[0]);
            return v;
        }).delay(60, TimeUnit.SECONDS).sync(v -> {
            this.issuer.sendInfo(Message.SCORE__TYPE, "{type}", "Cryptostorm");
            return v;
        }).async(v -> {
            this.test((Source<? extends SourceModel>)v, "Cryptostorm", DNSUtil.getCryptostormIps());
            return v;
        }).sync(v -> {
            this.issuer.sendInfo(Message.SCORE__SLEEP, new String[0]);
            return v;
        }).delay(60, TimeUnit.SECONDS).sync(v -> {
            this.issuer.sendInfo(Message.SCORE__TYPE, "{type}", "random home IPs");
            return v;
        }).async(v -> {
            this.test((Source<? extends SourceModel>)v, "Random home IP", DNSUtil.getHomeIps(), true);
            return v;
        }).syncLast(v -> this.issuer.sendInfo(Message.SCORE__END, "{source}", v.getName())).execute();
    }

    private void test(@NonNull Source<? extends SourceModel> source, @NonNull String vpnName, @NonNull Set<String> ips) {
        this.test(source, vpnName, ips, false);
    }

    private void test(@NonNull Source<? extends SourceModel> source, @NonNull String vpnName, @NonNull Set<String> ips, boolean flipResult) {
        if (ConfigUtil.getDebugOrFalse()) {
            this.logger.info("Testing against " + vpnName);
        }
        double error = 0.0;
        double good = 0.0;
        int i = 0;
        for (String ip : ips) {
            boolean result;
            ++i;
            try {
                if (source.getName().equalsIgnoreCase("getipintel")) {
                    Thread.sleep(5000L);
                } else {
                    Thread.sleep(1000L);
                }
            }
            catch (IllegalArgumentException ex) {
                this.logger.error(ex.getMessage(), ex);
            }
            catch (InterruptedException ex) {
                this.logger.error(ex.getMessage(), ex);
                Thread.currentThread().interrupt();
            }
            if (ConfigUtil.getDebugOrFalse()) {
                this.logger.info("Testing " + ip + " (" + i + "/" + ips.size() + ")");
            }
            try {
                Boolean val = source.getResult(ip).get();
                if (val == null) {
                    error += 1.0;
                    continue;
                }
                result = val;
            }
            catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
                error += 1.0;
                continue;
            }
            catch (CancellationException | ExecutionException ex) {
                ExceptionUtil.handleException(ex, this.logger);
                if (ex.getCause() instanceof APIException && ((APIException)ex.getCause()).isHard()) continue;
                error += 1.0;
                continue;
            }
            if ((flipResult || !result) && (!flipResult || result)) continue;
            good += 1.0;
        }
        if (error > 0.0) {
            this.issuer.sendInfo(Message.SCORE__ERROR, "{source}", source.getName(), "{type}", vpnName, "{percent}", format.format(error / (double)ips.size() * 100.0));
        }
        this.issuer.sendInfo(Message.SCORE__SCORE, "{source}", source.getName(), "{type}", vpnName, "{percent}", format.format(good / (double)ips.size() * 100.0));
    }
}

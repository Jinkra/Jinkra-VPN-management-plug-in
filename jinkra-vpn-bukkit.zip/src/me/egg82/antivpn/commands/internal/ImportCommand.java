/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.commands.internal;

import java.util.Set;
import me.egg82.antivpn.commands.internal.AbstractCommand;
import me.egg82.antivpn.config.CachedConfig;
import me.egg82.antivpn.config.ConfigUtil;
import me.egg82.antivpn.external.co.aikar.commands.CommandIssuer;
import me.egg82.antivpn.external.co.aikar.taskchain.TaskChain;
import me.egg82.antivpn.external.co.aikar.taskchain.TaskChainFactory;
import me.egg82.antivpn.lang.Message;
import me.egg82.antivpn.storage.StorageService;
import me.egg82.antivpn.storage.models.IPModel;
import me.egg82.antivpn.storage.models.PlayerModel;
import me.egg82.antivpn.utils.ExceptionUtil;
import org.checkerframework.checker.nullness.qual.NonNull;

public class ImportCommand
extends AbstractCommand {
    private final String masterName;
    private final String slaveName;
    private final String batchMax;

    public ImportCommand(@NonNull CommandIssuer issuer, @NonNull TaskChainFactory taskFactory, @NonNull String masterName, @NonNull String slaveName, @NonNull String batchMax) {
        super(issuer, taskFactory);
        this.masterName = masterName;
        this.slaveName = slaveName;
        this.batchMax = batchMax;
    }

    @Override
    public void run() {
        if (this.masterName.isEmpty()) {
            this.issuer.sendError(Message.IMPORT__NO_MASTER, new String[0]);
            return;
        }
        if (this.slaveName.isEmpty()) {
            this.issuer.sendError(Message.IMPORT__NO_SLAVE, new String[0]);
            return;
        }
        if (this.masterName.equalsIgnoreCase(this.slaveName)) {
            this.issuer.sendError(Message.IMPORT__SAME_STORAGE, new String[0]);
            return;
        }
        CachedConfig cachedConfig = ConfigUtil.getCachedConfig();
        if (cachedConfig == null) {
            this.logger.error("Cached config could not be fetched.");
            this.issuer.sendError(Message.ERROR__INTERNAL, new String[0]);
            return;
        }
        int max = this.batchMax == null ? 50 : Integer.parseInt(this.batchMax);
        int masterIndex = -1;
        int slaveIndex = -1;
        for (int i = 0; i < cachedConfig.getStorage().size(); ++i) {
            StorageService storage = (StorageService)cachedConfig.getStorage().get(i);
            if (masterIndex == -1 && this.masterName.equalsIgnoreCase(storage.getName())) {
                masterIndex = i;
                continue;
            }
            if (slaveIndex != -1 || !this.slaveName.equalsIgnoreCase(storage.getName())) continue;
            slaveIndex = i;
        }
        if (masterIndex == -1) {
            this.issuer.sendError(Message.IMPORT__NO_MASTER, new String[0]);
            return;
        }
        if (slaveIndex == -1) {
            this.issuer.sendError(Message.IMPORT__NO_SLAVE, new String[0]);
            return;
        }
        this.issuer.sendInfo(Message.IMPORT__BEGIN, new String[0]);
        StorageService master = (StorageService)cachedConfig.getStorage().get(masterIndex);
        StorageService slave = (StorageService)cachedConfig.getStorage().get(slaveIndex);
        TaskChain chain = this.taskFactory.newChain();
        chain.setErrorHandler((ex, task) -> ExceptionUtil.handleException(ex, this.logger));
        chain.sync(() -> this.issuer.sendInfo(Message.IMPORT__IPS, "{id}", "0")).asyncCallback((v, r) -> {
            Set<IPModel> models;
            int start = 1;
            do {
                models = master.getAllIps(start, max);
                slave.storeModels(models);
                this.issuer.sendInfo(Message.IMPORT__IPS, "{id}", String.valueOf(start + models.size()));
                start += max;
            } while (models.size() == max);
            r.accept(start);
        }).sync(() -> this.issuer.sendInfo(Message.IMPORT__PLAYERS, "{id}", "0")).asyncCallback((v, r) -> {
            Set<PlayerModel> models;
            int start = 1;
            do {
                models = master.getAllPlayers(start, max);
                slave.storeModels(models);
                this.issuer.sendInfo(Message.IMPORT__PLAYERS, "{id}", String.valueOf(start + models.size()));
                start += max;
            } while (models.size() == max);
            r.accept(start);
        }).syncLast(v -> this.issuer.sendInfo(Message.IMPORT__END, new String[0])).execute();
    }
}

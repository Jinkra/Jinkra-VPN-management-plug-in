package me.egg82.antivpn.commands;

import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import me.egg82.antivpn.api.VPNAPIProvider;
import me.egg82.antivpn.api.model.player.PlayerManager;
import me.egg82.antivpn.config.CachedConfig;
import me.egg82.antivpn.external.co.aikar.commands.BaseCommand;
import me.egg82.antivpn.external.co.aikar.commands.annotation.CommandAlias;
import me.egg82.antivpn.external.co.aikar.commands.annotation.Subcommand;
import me.egg82.antivpn.external.co.aikar.commands.annotation.Default;
import me.egg82.antivpn.external.co.aikar.commands.annotation.Description;
import me.egg82.antivpn.external.co.aikar.commands.annotation.CommandCompletion;
import me.egg82.antivpn.utils.StatisticsManager;
import me.egg82.antivpn.lang.Message;
import org.bukkit.ChatColor;

/**
 * Jinkra VPN Management Commands
 * Main command handler for administrative features
 */
@CommandAlias("jinkra")
public class JinkraCommand extends BaseCommand {

    private static final String PERMISSION_ADMIN = "jinkra.admin";
    private static final String PERMISSION_CHECK = "jinkra.check";
    private static final String PERMISSION_WHITELIST = "jinkra.whitelist.manage";
    private static final String PERMISSION_STATS = "jinkra.stats";

    @Default
    @Description("显示 Jinkra VPN 帮助信息")
    public void onHelp(CommandSender sender) {
        if (!sender.hasPermission(PERMISSION_ADMIN)) {
            sender.sendMessage(ChatColor.RED + "权限不足");
            return;
        }

        sender.sendMessage(ChatColor.GOLD + "========== Jinkra VPN 管理 ==========");
        sender.sendMessage(ChatColor.YELLOW + "/jinkra check <玩家名> " + ChatColor.GRAY + "- 检查玩家 VPN 状态");
        sender.sendMessage(ChatColor.YELLOW + "/jinkra whitelist add <IP/玩家> " + ChatColor.GRAY + "- 添加白名单");
        sender.sendMessage(ChatColor.YELLOW + "/jinkra whitelist remove <IP/玩家> " + ChatColor.GRAY + "- 移除白名单");
        sender.sendMessage(ChatColor.YELLOW + "/jinkra whitelist list " + ChatColor.GRAY + "- 查看白名单");
        sender.sendMessage(ChatColor.YELLOW + "/jinkra stats " + ChatColor.GRAY + "- 查看统计信息");
        sender.sendMessage(ChatColor.YELLOW + "/jinkra reload " + ChatColor.GRAY + "- 重新加载配置");
        sender.sendMessage(ChatColor.GOLD + "====================================");
    }

    @Subcommand("check")
    @Description("检查指定玩家的 VPN 状态")
    @CommandCompletion("@players")
    public void onCheck(CommandSender sender, String playerName) {
        if (!sender.hasPermission(PERMISSION_CHECK)) {
            sender.sendMessage(ChatColor.RED + "权限不足");
            return;
        }

        Player target = org.bukkit.Bukkit.getPlayer(playerName);
        if (target == null) {
            sender.sendMessage(ChatColor.RED + "玩家未在线");
            return;
        }

        try {
            PlayerManager playerManager = VPNAPIProvider.getInstance().getPlayerManager();
            String ip = target.getAddress().getAddress().getHostAddress();

            boolean isVPN = VPNAPIProvider.getInstance().isVPN(ip).get();
            boolean isMCLeaks = VPNAPIProvider.getInstance().isMCLeaks(target.getUniqueId()).get();

            sender.sendMessage(ChatColor.GREEN + "玩家: " + target.getName());
            sender.sendMessage(ChatColor.YELLOW + "  IP: " + ip);
            sender.sendMessage((isVPN ? ChatColor.RED : ChatColor.GREEN) + "  VPN: " + (isVPN ? "是" : "否"));
            sender.sendMessage((isMCLeaks ? ChatColor.RED : ChatColor.GREEN) + "  MCLeaks: " + (isMCLeaks ? "是" : "否"));

            // Record check in statistics
            StatisticsManager.recordManualCheck(target.getName(), ip, isVPN, isMCLeaks);

        } catch (Exception e) {
            sender.sendMessage(ChatColor.RED + "检查失败: " + e.getMessage());
        }
    }

    @Subcommand("whitelist add")
    @Description("添加 IP 到白名单")
    public void onWhitelistAdd(CommandSender sender, String target) {
        if (!sender.hasPermission(PERMISSION_WHITELIST)) {
            sender.sendMessage(ChatColor.RED + "权限不足");
            return;
        }

        if (CachedConfig.add_to_ip_whitelist(target)) {
            sender.sendMessage(ChatColor.GREEN + "已将 " + target + " 添加到白名单");
            StatisticsManager.recordWhitelistChange("ADD", target, sender.getName());
        } else {
            sender.sendMessage(ChatColor.RED + "添加白名单失败");
        }
    }

    @Subcommand("whitelist remove")
    @Description("从白名单移除 IP")
    public void onWhitelistRemove(CommandSender sender, String target) {
        if (!sender.hasPermission(PERMISSION_WHITELIST)) {
            sender.sendMessage(ChatColor.RED + "权限不足");
            return;
        }

        if (CachedConfig.remove_from_ip_whitelist(target)) {
            sender.sendMessage(ChatColor.GREEN + "已将 " + target + " 从白名单移除");
            StatisticsManager.recordWhitelistChange("REMOVE", target, sender.getName());
        } else {
            sender.sendMessage(ChatColor.RED + "移除白名单失败");
        }
    }

    @Subcommand("whitelist list")
    @Description("查看当前白名单")
    public void onWhitelistList(CommandSender sender) {
        if (!sender.hasPermission(PERMISSION_WHITELIST)) {
            sender.sendMessage(ChatColor.RED + "权限不足");
            return;
        }

        java.util.Set<String> whitelist = CachedConfig.get_ip_whitelist();
        sender.sendMessage(ChatColor.GOLD + "========== IP 白名单 ==========");
        if (whitelist.isEmpty()) {
            sender.sendMessage(ChatColor.YELLOW + "白名单为空");
        } else {
            for (String ip : whitelist) {
                sender.sendMessage(ChatColor.GREEN + "  " + ip);
            }
        }
        sender.sendMessage(ChatColor.GOLD + "==============================");
    }

    @Subcommand("stats")
    @Description("查看 VPN 检测统计信息")
    public void onStats(CommandSender sender) {
        if (!sender.hasPermission(PERMISSION_STATS)) {
            sender.sendMessage(ChatColor.RED + "权限不足");
            return;
        }

        StatisticsManager.Stats stats = StatisticsManager.getStats();

        sender.sendMessage(ChatColor.GOLD + "========== VPN 检测统计 ==========");
        sender.sendMessage(ChatColor.YELLOW + "总检查次数: " + ChatColor.GREEN + stats.getTotalChecks());
        sender.sendMessage(ChatColor.YELLOW + "VPN 检测数: " + ChatColor.RED + stats.getVpnDetected());
        sender.sendMessage(ChatColor.YELLOW + "MCLeaks 检测数: " + ChatColor.RED + stats.getMcleaksDetected());
        sender.sendMessage(ChatColor.YELLOW + "玩家被拦截: " + ChatColor.RED + stats.getPlayersBlocked());
        sender.sendMessage(ChatColor.YELLOW + "缓存命中率: " + ChatColor.GREEN + String.format("%.2f%%", stats.getCacheHitRate() * 100));
        sender.sendMessage(ChatColor.YELLOW + "平均响应时间: " + ChatColor.GREEN + stats.getAverageResponseTime() + "ms");
        sender.sendMessage(ChatColor.GOLD + "==================================");
    }

    @Subcommand("reload")
    @Description("重新加载配置文件")
    public void onReload(CommandSender sender) {
        if (!sender.hasPermission(PERMISSION_ADMIN)) {
            sender.sendMessage(ChatColor.RED + "权限不足");
            return;
        }

        try {
            sender.sendMessage(ChatColor.YELLOW + "正在重新加载配置...");
            ConfigurationFileUtil.reloadConfig();
            sender.sendMessage(ChatColor.GREEN + "配置重新加载成功");
        } catch (Exception e) {
            sender.sendMessage(ChatColor.RED + "重新加载失败: " + e.getMessage());
        }
    }
}

/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.bukkit.ChatColor
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.PluginDescriptionFile
 *  org.bukkit.plugin.java.JavaPlugin
 *  org.bukkit.plugin.java.JavaPluginLoader
 */
package me.egg82.antivpn;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.net.URISyntaxException;
import java.net.URLClassLoader;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import javax.xml.xpath.XPathExpressionException;
import me.egg82.antivpn.AntiVPN;
import me.egg82.antivpn.bukkit.BukkitEnvironmentUtil;
import me.egg82.antivpn.external.me.lucko.jarrelocator.JarRelocator;
import me.egg82.antivpn.external.me.lucko.jarrelocator.Relocation;
import me.egg82.antivpn.external.ninja.egg82.maven.Artifact;
import me.egg82.antivpn.external.ninja.egg82.maven.Repository;
import me.egg82.antivpn.external.ninja.egg82.maven.Scope;
import me.egg82.antivpn.external.ninja.egg82.utils.DownloadUtil;
import me.egg82.antivpn.external.ninja.egg82.utils.InjectUtil;
import me.egg82.antivpn.utils.BukkitLogUtil;
import org.bukkit.ChatColor;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginDescriptionFile;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.plugin.java.JavaPluginLoader;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.SAXException;

public class BukkitBootstrap
extends JavaPlugin {
    private final Logger logger = LoggerFactory.getLogger(((Object)((Object)this)).getClass());
    private AntiVPN concrete;
    private final boolean isBukkit;
    private final ExecutorService downloadPool = Executors.newWorkStealingPool(Math.max(4, Runtime.getRuntime().availableProcessors() / 2));

    public BukkitBootstrap() {
        this.isBukkit = BukkitEnvironmentUtil.getEnvironment() == BukkitEnvironmentUtil.Environment.BUKKIT;
    }

    protected BukkitBootstrap(JavaPluginLoader loader, PluginDescriptionFile description, File dataFolder, File file) {
        super(loader, description, dataFolder, file);
        this.isBukkit = BukkitEnvironmentUtil.getEnvironment() == BukkitEnvironmentUtil.Environment.BUKKIT;
    }

    public void onLoad() {
        ClassLoader origClassLoader = Thread.currentThread().getContextClassLoader();
        try {
            Thread.currentThread().setContextClassLoader(((Object)((Object)this)).getClass().getClassLoader());
            this.loadJars(new File(this.getDataFolder(), "external"), (URLClassLoader)((Object)((Object)this)).getClass().getClassLoader());
        }
        catch (IOException | ClassCastException ex) {
            Thread.currentThread().setContextClassLoader(origClassLoader);
            this.logger.error(ex.getMessage(), ex);
            throw new RuntimeException("Could not load required dependencies.");
        }
        this.downloadPool.shutdown();
        try {
            if (!this.downloadPool.awaitTermination(1L, TimeUnit.HOURS)) {
                this.logger.error("Could not download all dependencies. Please try again later.");
                Thread.currentThread().setContextClassLoader(origClassLoader);
                return;
            }
        }
        catch (InterruptedException ex) {
            Thread.currentThread().setContextClassLoader(origClassLoader);
            this.logger.error(ex.getMessage(), ex);
            Thread.currentThread().interrupt();
        }
        try {
            this.concrete = new AntiVPN((Plugin)this);
            this.concrete.onLoad();
        }
        finally {
            Thread.currentThread().setContextClassLoader(origClassLoader);
        }
    }

    public void onEnable() {
        ClassLoader origClassLoader = Thread.currentThread().getContextClassLoader();
        Thread.currentThread().setContextClassLoader(((Object)((Object)this)).getClass().getClassLoader());
        try {
            this.concrete.onEnable();
        }
        finally {
            Thread.currentThread().setContextClassLoader(origClassLoader);
        }
    }

    public void onDisable() {
        ClassLoader origClassLoader = Thread.currentThread().getContextClassLoader();
        Thread.currentThread().setContextClassLoader(((Object)((Object)this)).getClass().getClassLoader());
        try {
            this.concrete.onDisable();
        }
        finally {
            Thread.currentThread().setContextClassLoader(origClassLoader);
        }
    }

    private void loadJars(@NonNull File jarsDir, @NonNull URLClassLoader parentLoader) throws IOException {
        if (jarsDir.exists() && !jarsDir.isDirectory()) {
            Files.delete(jarsDir.toPath());
        }
        if (!jarsDir.exists() && !jarsDir.mkdirs()) {
            throw new IOException("Could not create parent directory structure.");
        }
        File cacheDir = new File(jarsDir, "cache");
        Artifact.Builder checkerframework = Artifact.builder(this.getCheckerFrameworkPackage(), "checker", "3.9.0", cacheDir).addRepository(Repository.builder("https://repo1.maven.org/maven2/").addProxy("https://nexus.egg82.me/repository/maven-central/").build());
        this.buildRelocateInject(checkerframework, jarsDir, Arrays.asList(new Relocation(this.getAnnotatedJdkPackage(), "me.egg82.antivpn.external." + this.getAnnotatedJdkPackage()), new Relocation(this.getAnnotatorPackage(), "me.egg82.antivpn.external." + this.getAnnotatorPackage()), new Relocation(this.getCheckerFrameworkPackage(), "me.egg82.antivpn.external." + this.getCheckerFrameworkPackage()), new Relocation(this.getJmlSpecsPackage(), "me.egg82.antivpn.external." + this.getJmlSpecsPackage()), new Relocation(this.getSceneLibPackage(), "me.egg82.antivpn.external." + this.getSceneLibPackage())), parentLoader, "Checker Framework");
        Artifact.Builder caffeine = Artifact.builder("com.github.ben-manes.caffeine", "caffeine", "2.8.8", cacheDir).addRepository(Repository.builder("https://repo1.maven.org/maven2/").addProxy("https://nexus.egg82.me/repository/maven-central/").build());
        this.buildRelocateInject(caffeine, jarsDir, Collections.singletonList(new Relocation(this.getCaffeinePackage(), "me.egg82.antivpn.external." + this.getCaffeinePackage())), parentLoader, "Caffeine");
        try {
            Class.forName("com.github.luben.zstd.Zstd");
        }
        catch (ClassNotFoundException ignored) {
            Artifact.Builder zstd = Artifact.builder("com.github.luben", "zstd-jni", "1.4.8-1", cacheDir).addRepository(Repository.builder("https://repo1.maven.org/maven2/").addProxy("https://nexus.egg82.me/repository/maven-central/").build());
            this.buildRelocateInject(zstd, jarsDir, Collections.emptyList(), parentLoader, "Zstd");
        }
        Artifact.Builder ipaddr = Artifact.builder("com.github.seancfoley", "ipaddress", "5.3.3", cacheDir).addRepository(Repository.builder("https://repo1.maven.org/maven2/").addProxy("https://nexus.egg82.me/repository/maven-central/").build());
        this.buildRelocateInject(ipaddr, jarsDir, Collections.singletonList(new Relocation(this.getInetIpaddrPackage(), "me.egg82.antivpn.external." + this.getInetIpaddrPackage())), parentLoader, "IP Address");
        try {
            Class.forName("org.h2.Driver");
        }
        catch (ClassNotFoundException ignored) {
            Artifact.Builder h2 = Artifact.builder("com.h2database", "h2", "1.4.200", cacheDir).addRepository(Repository.builder("https://repo1.maven.org/maven2/").addProxy("https://nexus.egg82.me/repository/maven-central/").build());
            this.buildRelocateInject(h2, jarsDir, Collections.emptyList(), parentLoader, "H2");
        }
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        }
        catch (ClassNotFoundException ignored) {
            Artifact.Builder mysql = Artifact.builder("mysql", "mysql-connector-java", "8.0.22", cacheDir).addRepository(Repository.builder("https://repo1.maven.org/maven2/").addProxy("https://nexus.egg82.me/repository/maven-central/").build());
            this.buildRelocateInject(mysql, jarsDir, Collections.emptyList(), parentLoader, "MySQL");
        }
        Artifact.Builder rabbitmq = Artifact.builder(this.getRabbitMqPackage(), "amqp-client", "5.10.0", cacheDir).addRepository(Repository.builder("https://repo1.maven.org/maven2/").addProxy("https://nexus.egg82.me/repository/maven-central/").build());
        this.buildRelocateInject(rabbitmq, jarsDir, Collections.singletonList(new Relocation(this.getRabbitMqPackage(), "me.egg82.antivpn.external." + this.getRabbitMqPackage())), parentLoader, "RabbitMQ");
        Artifact.Builder ebeanCore = Artifact.builder(this.getEbeanPackage(), "ebean-core", "12.6.5", cacheDir).addRepository(Repository.builder("https://repo1.maven.org/maven2/").addProxy("https://nexus.egg82.me/repository/maven-central/").build());
        this.buildRelocateInject(ebeanCore, jarsDir, Arrays.asList(new Relocation(this.getEbeanPackage(), "me.egg82.antivpn.external." + this.getEbeanPackage()), new Relocation(this.getEbeanInternalPackage(), "me.egg82.antivpn.external." + this.getEbeanInternalPackage()), new Relocation(this.getEbeanServicePackage(), "me.egg82.antivpn.external." + this.getEbeanServicePackage())), parentLoader, "Ebean Core");
        Artifact.Builder fastutil = Artifact.builder("it.unimi.dsi", "fastutil", "8.4.4", cacheDir).addRepository(Repository.builder("https://repo1.maven.org/maven2/").addProxy("https://nexus.egg82.me/repository/maven-central/").build());
        this.buildRelocateInject(fastutil, jarsDir, Collections.singletonList(new Relocation(this.getFastUtilPackage(), "me.egg82.antivpn.external." + this.getFastUtilPackage())), parentLoader, "FastUtil");
        Artifact.Builder mcleaks = Artifact.builder("me.gong", "mcleaks-api", "1.9.5-SNAPSHOT", cacheDir).addRepository(Repository.builder("https://nexus.wesjd.net/repository/thirdparty/").addProxy("https://nexus.egg82.me/repository/wesjd/").build());
        this.buildRelocateInject(mcleaks, jarsDir, Arrays.asList(new Relocation(this.getMcLeaksPackage(), "me.egg82.antivpn.external." + this.getMcLeaksPackage()), new Relocation(this.getOkhttp3Package(), "me.egg82.antivpn.external." + this.getOkhttp3Package()), new Relocation(this.getOkioPackage(), "me.egg82.antivpn.external." + this.getOkioPackage())), parentLoader, "MC Leaks API");
        Artifact.Builder javassist = Artifact.builder("org.javassist", this.getJavassistPackage(), "3.27.0-GA", cacheDir).addRepository(Repository.builder("https://repo1.maven.org/maven2/").addProxy("https://nexus.egg82.me/repository/maven-central/").build());
        this.buildRelocateInject(javassist, jarsDir, Collections.singletonList(new Relocation(this.getJavassistPackage(), "me.egg82.antivpn.external." + this.getJavassistPackage())), parentLoader, "Javassist");
        try {
            Class.forName("org.postgresql.Driver");
        }
        catch (ClassNotFoundException ignored) {
            Artifact.Builder postgresql = Artifact.builder("org.postgresql", "postgresql", "42.2.18", cacheDir).addRepository(Repository.builder("https://repo1.maven.org/maven2/").addProxy("https://nexus.egg82.me/repository/maven-central/").build());
            this.buildRelocateInject(postgresql, jarsDir, Collections.emptyList(), parentLoader, "PostgreSQL");
        }
        try {
            Class.forName("org.sqlite.JDBC");
        }
        catch (ClassNotFoundException ignored) {
            Artifact.Builder sqlite = Artifact.builder("org.xerial", "sqlite-jdbc", "3.34.0", cacheDir).addRepository(Repository.builder("https://repo1.maven.org/maven2/").addProxy("https://nexus.egg82.me/repository/maven-central/").build());
            this.buildRelocateInject(sqlite, jarsDir, Collections.emptyList(), parentLoader, "SQLite");
        }
        Artifact.Builder redis = Artifact.builder("redis.clients", "jedis", "3.4.1", cacheDir).addRepository(Repository.builder("https://repo1.maven.org/maven2/").addProxy("https://nexus.egg82.me/repository/maven-central/").build());
        this.buildRelocateInject(redis, jarsDir, Collections.singletonList(new Relocation(this.getJedisPackage(), "me.egg82.antivpn.external." + this.getJedisPackage())), parentLoader, "Jedis");
    }

    private @NonNull String getAnnotatedJdkPackage() {
        return new String(new byte[]{97, 110, 110, 111, 116, 97, 116, 101, 100, 45, 106, 100, 107});
    }

    private @NonNull String getAnnotatorPackage() {
        return new String(new byte[]{97, 110, 110, 111, 116, 97, 116, 111, 114});
    }

    private @NonNull String getCheckerFrameworkPackage() {
        return new String(new byte[]{111, 114, 103, 46, 99, 104, 101, 99, 107, 101, 114, 102, 114, 97, 109, 101, 119, 111, 114, 107});
    }

    private @NonNull String getJmlSpecsPackage() {
        return new String(new byte[]{111, 114, 103, 46, 106, 109, 108, 115, 112, 101, 99, 115});
    }

    private @NonNull String getSceneLibPackage() {
        return new String(new byte[]{115, 99, 101, 110, 101, 108, 105, 98});
    }

    private @NonNull String getCaffeinePackage() {
        return new String(new byte[]{99, 111, 109, 46, 103, 105, 116, 104, 117, 98, 46, 98, 101, 110, 109, 97, 110, 101, 115, 46, 99, 97, 102, 102, 101, 105, 110, 101});
    }

    private @NonNull String getInetIpaddrPackage() {
        return new String(new byte[]{105, 110, 101, 116, 46, 105, 112, 97, 100, 100, 114});
    }

    private @NonNull String getRabbitMqPackage() {
        return new String(new byte[]{99, 111, 109, 46, 114, 97, 98, 98, 105, 116, 109, 113});
    }

    private @NonNull String getEbeanPackage() {
        return new String(new byte[]{105, 111, 46, 101, 98, 101, 97, 110});
    }

    private @NonNull String getEbeanInternalPackage() {
        return new String(new byte[]{105, 111, 46, 101, 98, 101, 97, 110, 105, 110, 116, 101, 114, 110, 97, 108});
    }

    private @NonNull String getEbeanServicePackage() {
        return new String(new byte[]{105, 111, 46, 101, 98, 101, 97, 110, 115, 101, 114, 118, 105, 99, 101});
    }

    private @NonNull String getFastUtilPackage() {
        return new String(new byte[]{105, 116, 46, 117, 110, 105, 109, 105, 46, 100, 115, 105, 46, 102, 97, 115, 116, 117, 116, 105, 108});
    }

    private @NonNull String getMcLeaksPackage() {
        return new String(new byte[]{109, 101, 46, 103, 111, 110, 103, 46, 109, 99, 108, 101, 97, 107, 115});
    }

    private @NonNull String getOkhttp3Package() {
        return new String(new byte[]{111, 107, 104, 116, 116, 112});
    }

    private @NonNull String getOkioPackage() {
        return new String(new byte[]{111, 107, 105, 111});
    }

    private @NonNull String getJavassistPackage() {
        return new String(new byte[]{106, 97, 118, 97, 115, 115, 105, 115, 116});
    }

    private @NonNull String getJedisPackage() {
        return new String(new byte[]{114, 101, 100, 105, 115, 46, 99, 108, 105, 101, 110, 116, 115, 46, 106, 101, 100, 105, 115});
    }

    private void printLatest(@NonNull String friendlyName) {
        this.log(Level.INFO, BukkitLogUtil.HEADING + ChatColor.YELLOW + "Checking version of " + ChatColor.WHITE + friendlyName);
    }

    private void buildInject(Artifact.Builder builder, @NonNull File jarsDir, @NonNull URLClassLoader classLoader, @NonNull String friendlyName) {
        this.buildInject(builder, jarsDir, classLoader, friendlyName, 0);
    }

    private void buildInject(Artifact.Builder builder, @NonNull File jarsDir, @NonNull URLClassLoader classLoader, @NonNull String friendlyName, int depth) {
        this.downloadPool.submit(() -> this.buildInjectWait(builder, jarsDir, classLoader, friendlyName, depth));
    }

    private void buildInjectWait(Artifact.Builder builder, @NonNull File jarsDir, @NonNull URLClassLoader classLoader, @NonNull String friendlyName, int depth) {
        IOException lastEx;
        try {
            this.injectArtifact(builder.build(), jarsDir, classLoader, friendlyName, depth, null);
            return;
        }
        catch (IOException ex) {
            lastEx = ex;
        }
        catch (IllegalAccessException | InvocationTargetException | URISyntaxException | XPathExpressionException | SAXException ex) {
            this.logger.error(ex.getMessage(), ex);
            return;
        }
        if (depth > 0) {
            this.logger.error(lastEx.getMessage(), lastEx);
            return;
        }
        this.logger.warn("Failed to download/relocate " + builder.getGroupId() + ":" + builder.getArtifactId() + "-" + builder.getVersion() + ". Searching disk instead.", lastEx);
        try {
            this.injectArtifact(builder, jarsDir, classLoader, null);
        }
        catch (IOException | IllegalAccessException | InvocationTargetException ex) {
            throw new RuntimeException("Could not download/relocate " + builder.getGroupId() + ":" + builder.getArtifactId() + "-" + builder.getVersion() + ", and no on-disk option is available.", lastEx);
        }
    }

    private void buildRelocateInject(Artifact.Builder builder, @NonNull File jarsDir, @NonNull List<Relocation> rules, @NonNull URLClassLoader classLoader, @NonNull String friendlyName) {
        this.buildRelocateInject(builder, jarsDir, rules, classLoader, friendlyName, 0);
    }

    private void buildRelocateInject(Artifact.Builder builder, @NonNull File jarsDir, @NonNull List<Relocation> rules, @NonNull URLClassLoader classLoader, @NonNull String friendlyName, int depth) {
        this.downloadPool.submit(() -> this.buildRelocateInjectWait(builder, jarsDir, rules, classLoader, friendlyName, depth));
    }

    private void buildRelocateInjectWait(Artifact.Builder builder, @NonNull File jarsDir, @NonNull List<Relocation> rules, @NonNull URLClassLoader classLoader, @NonNull String friendlyName, int depth) {
        IOException lastEx;
        try {
            this.injectArtifact(builder.build(), jarsDir, classLoader, friendlyName, depth, rules);
            return;
        }
        catch (IOException ex) {
            lastEx = ex;
        }
        catch (IllegalAccessException | InvocationTargetException | URISyntaxException | XPathExpressionException | SAXException ex) {
            this.logger.error(ex.getMessage(), ex);
            return;
        }
        if (depth > 0) {
            this.logger.error(lastEx.getMessage(), lastEx);
            return;
        }
        this.logger.warn("Failed to download/relocate " + builder.getGroupId() + ":" + builder.getArtifactId() + "-" + builder.getVersion() + ". Searching disk instead.", lastEx);
        try {
            this.injectArtifact(builder, jarsDir, classLoader, rules);
        }
        catch (IOException | IllegalAccessException | InvocationTargetException ex) {
            throw new RuntimeException("Could not download/relocate " + builder.getGroupId() + ":" + builder.getArtifactId() + "-" + builder.getVersion() + ", and no on-disk option is available.", lastEx);
        }
    }

    private void injectArtifact(@NonNull Artifact artifact, @NonNull File jarsDir, @NonNull URLClassLoader classLoader, String friendlyName, int depth, List<Relocation> rules) throws IOException, IllegalAccessException, InvocationTargetException, URISyntaxException, XPathExpressionException, SAXException {
        File output = new File(jarsDir, artifact.getGroupId() + "-" + artifact.getArtifactId() + "-" + artifact.getRealVersion() + ".jar");
        if (friendlyName != null && !artifact.fileExists(output)) {
            this.log(Level.INFO, BukkitLogUtil.HEADING + ChatColor.YELLOW + "Downloading " + ChatColor.WHITE + friendlyName);
        }
        if (rules == null) {
            artifact.injectJar(output, classLoader);
        } else {
            File relocatedOutput;
            if (!DownloadUtil.hasFile(output)) {
                artifact.downloadJar(output);
            }
            if (!DownloadUtil.hasFile(relocatedOutput = new File(jarsDir, artifact.getGroupId() + "-" + artifact.getArtifactId() + "-" + artifact.getRealVersion() + "-relocated.jar"))) {
                JarRelocator relocator = new JarRelocator(output, relocatedOutput, rules);
                relocator.run();
            }
            InjectUtil.injectFile(relocatedOutput, classLoader);
        }
        if (depth > 0) {
            for (Artifact dependency : artifact.getDependencies()) {
                if (dependency.getScope() != Scope.COMPILE && dependency.getScope() != Scope.RUNTIME) continue;
                this.injectArtifact(dependency, jarsDir, classLoader, null, depth - 1, rules);
            }
        }
    }

    private void injectArtifact(Artifact.Builder builder, @NonNull File jarsDir, @NonNull URLClassLoader classLoader, List<Relocation> rules) throws IOException, IllegalAccessException, InvocationTargetException {
        File[] files = jarsDir.listFiles();
        if (files == null) {
            throw new IOException();
        }
        long latest = Long.MIN_VALUE;
        File retVal = null;
        for (File file : files) {
            if (!file.getName().startsWith(builder.getGroupId() + "-" + builder.getArtifactId()) || file.lastModified() < latest) continue;
            latest = file.lastModified();
            retVal = file;
        }
        if (retVal == null) {
            throw new IOException();
        }
        if (rules == null) {
            InjectUtil.injectFile(retVal, classLoader);
        } else {
            File output = new File(jarsDir, retVal.getName().substring(0, retVal.getName().length() - 4) + "-relocated.jar");
            if (!DownloadUtil.hasFile(output)) {
                JarRelocator relocator = new JarRelocator(retVal, output, rules);
                relocator.run();
            }
            InjectUtil.injectFile(output, classLoader);
        }
    }

    private void log(@NonNull Level level, @NonNull String message) {
        this.getServer().getLogger().log(level, this.isBukkit ? ChatColor.stripColor((String)message) : message);
    }
}

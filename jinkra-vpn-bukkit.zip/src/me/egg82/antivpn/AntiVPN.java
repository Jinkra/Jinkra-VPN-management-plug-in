/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 *  com.google.common.collect.SetMultimap
 *  com.google.common.util.concurrent.ThreadFactoryBuilder
 *  me.egg82.antivpn.external.it.unimi.dsi.fastutil.ints.IntArrayList
 *  me.egg82.antivpn.external.it.unimi.dsi.fastutil.ints.IntList
 *  me.egg82.antivpn.external.it.unimi.dsi.fastutil.ints.IntListIterator
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.configuration.InvalidConfigurationException
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.player.PlayerLoginEvent
 *  org.bukkit.metadata.MetadataValue
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.PluginManager
 */
package me.egg82.antivpn;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.SetMultimap;
import com.google.common.util.concurrent.ThreadFactoryBuilder;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.CancellationException;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Level;
import me.egg82.antivpn.api.APIRegistrationUtil;
import me.egg82.antivpn.api.APIUtil;
import me.egg82.antivpn.api.GenericVPNAPI;
import me.egg82.antivpn.api.VPNAPI;
import me.egg82.antivpn.api.VPNAPIProvider;
import me.egg82.antivpn.api.event.VPNEvent;
import me.egg82.antivpn.api.event.api.GenericAPIDisableEvent;
import me.egg82.antivpn.api.event.api.GenericAPILoadedEvent;
import me.egg82.antivpn.api.event.api.GenericPublicationErrorHandler;
import me.egg82.antivpn.api.model.ip.BukkitIPManager;
import me.egg82.antivpn.api.model.player.BukkitPlayerManager;
import me.egg82.antivpn.api.model.source.GenericSourceManager;
import me.egg82.antivpn.api.model.source.Source;
import me.egg82.antivpn.api.model.source.models.SourceModel;
import me.egg82.antivpn.api.platform.BukkitPlatform;
import me.egg82.antivpn.api.platform.BukkitPluginMetadata;
import me.egg82.antivpn.bukkit.BukkitEnvironmentUtil;
import me.egg82.antivpn.bukkit.BukkitVersionUtil;
import me.egg82.antivpn.commands.AntiVPNCommand;
import me.egg82.antivpn.config.CachedConfig;
import me.egg82.antivpn.config.ConfigUtil;
import me.egg82.antivpn.config.ConfigurationFileUtil;
import me.egg82.antivpn.events.EventHolder;
import me.egg82.antivpn.events.PlayerEvents;
import me.egg82.antivpn.events.PlayerLoginUpdateNotifyHandler;
import me.egg82.antivpn.external.co.aikar.commands.BukkitLocales;
import me.egg82.antivpn.external.co.aikar.commands.CommandIssuer;
import me.egg82.antivpn.external.co.aikar.commands.ConditionFailedException;
import me.egg82.antivpn.external.co.aikar.commands.MessageType;
import me.egg82.antivpn.external.co.aikar.commands.PaperCommandManager;
import me.egg82.antivpn.external.co.aikar.commands.RegisteredCommand;
import me.egg82.antivpn.external.co.aikar.taskchain.BukkitTaskChainFactory;
import me.egg82.antivpn.external.co.aikar.taskchain.TaskChainFactory;
import me.egg82.antivpn.external.it.unimi.dsi.fastutil.ints.IntArrayList;
import me.egg82.antivpn.external.it.unimi.dsi.fastutil.ints.IntList;
import me.egg82.antivpn.external.it.unimi.dsi.fastutil.ints.IntListIterator;
import me.egg82.antivpn.external.ninja.egg82.events.BukkitEventSubscriber;
import me.egg82.antivpn.external.ninja.egg82.events.BukkitEvents;
import me.egg82.antivpn.external.ninja.egg82.service.ServiceLocator;
import me.egg82.antivpn.external.ninja.egg82.service.ServiceNotFoundException;
import me.egg82.antivpn.external.ninja.egg82.updater.SpigotUpdater;
import me.egg82.antivpn.external.org.bstats.bukkit.Metrics;
import me.egg82.antivpn.external.org.spongepowered.configurate.ConfigurationNode;
import me.egg82.antivpn.hooks.LuckPermsHook;
import me.egg82.antivpn.hooks.PlaceholderAPIHook;
import me.egg82.antivpn.hooks.PlayerAnalyticsHook;
import me.egg82.antivpn.hooks.PluginHook;
import me.egg82.antivpn.hooks.VaultHook;
import me.egg82.antivpn.lang.LanguageFileUtil;
import me.egg82.antivpn.lang.Message;
import me.egg82.antivpn.lang.PluginMessageFormatter;
import me.egg82.antivpn.messaging.GenericMessagingHandler;
import me.egg82.antivpn.messaging.MessagingHandler;
import me.egg82.antivpn.messaging.MessagingService;
import me.egg82.antivpn.messaging.ServerIDUtil;
import me.egg82.antivpn.services.GameAnalyticsErrorHandler;
import me.egg82.antivpn.storage.StorageService;
import me.egg82.antivpn.utils.ExceptionUtil;
import me.egg82.antivpn.utils.ValidationUtil;
import me.egg82.antivpn.utils.VersionUtil;
import net.engio.mbassy.bus.MBassador;
import net.engio.mbassy.bus.publication.SyncAsyncPostCommand;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.entity.Player;
import org.bukkit.event.EventPriority;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginManager;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AntiVPN {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());
    private final ExecutorService workPool = Executors.newFixedThreadPool(1, new ThreadFactoryBuilder().setNameFormat("AntiVPN-%d").build());
    private TaskChainFactory taskFactory;
    private PaperCommandManager commandManager;
    private final List<EventHolder> eventHolders = new ArrayList<EventHolder>();
    private final List<BukkitEventSubscriber<?>> events = new ArrayList();
    private final IntList tasks = new IntArrayList();
    private final Plugin plugin;
    private final boolean isBukkit;
    private CommandIssuer consoleCommandIssuer = null;
    private static final AtomicLong blockedVPNs = new AtomicLong(0L);
    private static final AtomicLong blockedMCLeaks = new AtomicLong(0L);

    public AntiVPN(@NonNull Plugin plugin) {
        this.plugin = plugin;
        this.isBukkit = BukkitEnvironmentUtil.getEnvironment() == BukkitEnvironmentUtil.Environment.BUKKIT;
    }

    public void onLoad() {
        if (BukkitEnvironmentUtil.getEnvironment() != BukkitEnvironmentUtil.Environment.PAPER) {
            this.log(Level.INFO, ChatColor.AQUA + "====================================");
            this.log(Level.INFO, ChatColor.YELLOW + "Anti-VPN runs better on Paper!");
            this.log(Level.INFO, ChatColor.YELLOW + "https://whypaper.emc.gs/");
            this.log(Level.INFO, ChatColor.AQUA + "====================================");
        }
        if (!VersionUtil.isAtLeast("1.8", '.', BukkitVersionUtil.getGameVersion(), '.')) {
            this.log(Level.INFO, ChatColor.GOLD + "====================================");
            this.log(Level.INFO, ChatColor.DARK_RED + "Anti-VPN will likely not work on servers < 1.8");
            this.log(Level.INFO, ChatColor.GOLD + "====================================");
        }
        if (BukkitVersionUtil.getGameVersion().startsWith("1.8")) {
            this.log(Level.INFO, ChatColor.AQUA + "====================================");
            this.log(Level.INFO, ChatColor.DARK_RED + "DEAR LORD why are you on 1.8???");
            this.log(Level.INFO, ChatColor.DARK_RED + "Have you tried ViaVersion or ProtocolSupport lately?");
            this.log(Level.INFO, ChatColor.AQUA + "====================================");
        }
    }

    public void onEnable() {
        GameAnalyticsErrorHandler.open(ServerIDUtil.getId(new File(this.plugin.getDataFolder(), "stats-id.txt")), this.plugin.getDescription().getVersion(), Bukkit.getVersion());
        this.taskFactory = BukkitTaskChainFactory.create(this.plugin);
        this.taskFactory.setDefaultErrorHandler((ex, task) -> ExceptionUtil.handleException(ex, this.logger));
        this.commandManager = new PaperCommandManager(this.plugin);
        this.commandManager.enableUnstableAPI("help");
        this.setChatColors();
        this.consoleCommandIssuer = this.commandManager.getCommandIssuer(this.plugin.getServer().getConsoleSender());
        this.loadServices();
        this.loadLanguages();
        this.loadCommands();
        this.loadEvents();
        this.loadTasks();
        this.loadHooks();
        this.loadMetrics();
        int numEvents = this.events.size();
        for (EventHolder eventHolder : this.eventHolders) {
            numEvents += eventHolder.numEvents();
        }
        this.consoleCommandIssuer.sendInfo(Message.GENERAL__ENABLED, new String[0]);
        this.consoleCommandIssuer.sendInfo(Message.GENERAL__LOAD, "{version}", this.plugin.getDescription().getVersion(), "{apiversion}", VPNAPIProvider.getInstance().getPluginMetadata().getApiVersion(), "{commands}", String.valueOf(this.commandManager.getRegisteredRootCommands().size()), "{events}", String.valueOf(numEvents), "{tasks}", String.valueOf(this.tasks.size()));
        this.workPool.execute(this::checkUpdate);
    }

    public void onDisable() {
        this.workPool.shutdown();
        try {
            if (!this.workPool.awaitTermination(4L, TimeUnit.SECONDS)) {
                this.workPool.shutdownNow();
            }
        }
        catch (InterruptedException ignored) {
            Thread.currentThread().interrupt();
        }
        this.taskFactory.shutdown(2, TimeUnit.SECONDS);
        this.commandManager.unregisterCommands();
        IntListIterator ignored = this.tasks.iterator();
        while (ignored.hasNext()) {
            int n = (Integer)ignored.next();
            Bukkit.getScheduler().cancelTask(n);
        }
        this.tasks.clear();
        try {
            VPNAPIProvider.getInstance().runUpdateTask().join();
        }
        catch (CancellationException | CompletionException ex) {
            ExceptionUtil.handleException(ex, this.logger);
        }
        for (EventHolder eventHolder : this.eventHolders) {
            eventHolder.cancel();
        }
        this.eventHolders.clear();
        for (BukkitEventSubscriber bukkitEventSubscriber : this.events) {
            bukkitEventSubscriber.cancel();
        }
        this.events.clear();
        this.unloadHooks();
        this.unloadServices();
        this.consoleCommandIssuer.sendInfo(Message.GENERAL__DISABLED, new String[0]);
        GameAnalyticsErrorHandler.close();
    }

    private void loadLanguages() {
        CachedConfig cachedConfig = ConfigUtil.getCachedConfig();
        if (cachedConfig == null) {
            throw new RuntimeException("CachedConfig seems to be null.");
        }
        BukkitLocales locales = this.commandManager.getLocales();
        try {
            for (Locale locale : Locale.getAvailableLocales()) {
                Optional<File> localeFile = LanguageFileUtil.getLanguage(this.plugin.getDataFolder(), locale);
                if (!localeFile.isPresent()) continue;
                this.commandManager.addSupportedLanguage(locale);
                locales.loadYamlLanguageFile(localeFile.get(), locale);
            }
        }
        catch (IOException | InvalidConfigurationException ex) {
            this.logger.error(ex.getMessage(), ex);
        }
        locales.loadLanguages();
        locales.setDefaultLocale(cachedConfig.getLanguage());
        this.commandManager.usePerIssuerLocale(true, true);
        this.commandManager.setFormat(MessageType.ERROR, new PluginMessageFormatter(this.commandManager, Message.GENERAL__HEADER));
        this.commandManager.setFormat(MessageType.INFO, new PluginMessageFormatter(this.commandManager, Message.GENERAL__HEADER));
        this.setChatColors();
    }

    private void setChatColors() {
        this.commandManager.setFormat(MessageType.ERROR, (FT[])new ChatColor[]{ChatColor.DARK_RED, ChatColor.YELLOW, ChatColor.AQUA, ChatColor.WHITE});
        this.commandManager.setFormat(MessageType.INFO, (FT[])new ChatColor[]{ChatColor.WHITE, ChatColor.YELLOW, ChatColor.AQUA, ChatColor.GREEN, ChatColor.RED, ChatColor.GOLD, ChatColor.BLUE, ChatColor.GRAY, ChatColor.DARK_RED});
    }

    private void loadServices() {
        GenericSourceManager sourceManager = new GenericSourceManager();
        GenericMessagingHandler messagingHandler = new GenericMessagingHandler();
        ServiceLocator.register(messagingHandler);
        ConfigurationFileUtil.reloadConfig(this.plugin.getDataFolder(), this.consoleCommandIssuer, messagingHandler, sourceManager);
        CachedConfig cachedConfig = ConfigUtil.getCachedConfig();
        BukkitIPManager ipManager = new BukkitIPManager(this.plugin, sourceManager, cachedConfig.getCacheTime().getTime(), cachedConfig.getCacheTime().getUnit());
        BukkitPlayerManager playerManager = new BukkitPlayerManager(this.plugin, cachedConfig.getThreads(), cachedConfig.getMcLeaksKey(), cachedConfig.getCacheTime().getTime(), cachedConfig.getCacheTime().getUnit());
        BukkitPlatform platform = new BukkitPlatform(System.currentTimeMillis());
        BukkitPluginMetadata metadata = new BukkitPluginMetadata(this.plugin.getDescription().getVersion());
        GenericVPNAPI api = new GenericVPNAPI(platform, metadata, ipManager, playerManager, sourceManager, cachedConfig, new MBassador<VPNEvent>(new GenericPublicationErrorHandler()));
        APIUtil.setManagers(ipManager, playerManager, sourceManager);
        ServiceLocator.register(new SpigotUpdater(this.plugin, 58291));
        APIRegistrationUtil.register(api);
        ((SyncAsyncPostCommand)api.getEventBus().post((Object)new GenericAPILoadedEvent(api))).now();
    }

    private void loadCommands() {
        this.commandManager.getCommandConditions().addCondition(String.class, "ip", (c, exec, value) -> {
            if (!ValidationUtil.isValidIp(value)) {
                throw new ConditionFailedException("Value must be a valid IP address.");
            }
        });
        this.commandManager.getCommandConditions().addCondition(String.class, "source", (c, exec, value) -> {
            List<Source<? extends SourceModel>> sources = VPNAPIProvider.getInstance().getSourceManager().getSources();
            for (Source<? extends SourceModel> source : sources) {
                if (!source.getName().equalsIgnoreCase((String)value)) continue;
                return;
            }
            throw new ConditionFailedException("Value must be a valid source name.");
        });
        this.commandManager.getCommandCompletions().registerCompletion("source", c -> {
            String lower = c.getInput().toLowerCase().replace(" ", "_");
            List<Source<? extends SourceModel>> sources = VPNAPIProvider.getInstance().getSourceManager().getSources();
            LinkedHashSet<String> retVal = new LinkedHashSet<String>();
            for (Source<? extends SourceModel> source : sources) {
                String ss = source.getName();
                if (!ss.toLowerCase().startsWith(lower)) continue;
                retVal.add(ss);
            }
            return ImmutableList.copyOf(retVal);
        });
        this.commandManager.getCommandConditions().addCondition(String.class, "storage", (c, exec, value) -> {
            String v = value.replace(" ", "_");
            CachedConfig cachedConfig = ConfigUtil.getCachedConfig();
            if (cachedConfig == null) {
                this.logger.error("Cached config could not be fetched.");
                return;
            }
            for (StorageService service : cachedConfig.getStorage()) {
                if (!service.getName().equalsIgnoreCase(v)) continue;
                return;
            }
            throw new ConditionFailedException("Value must be a valid storage name.");
        });
        this.commandManager.getCommandCompletions().registerCompletion("storage", c -> {
            String lower = c.getInput().toLowerCase().replace(" ", "_");
            LinkedHashSet<String> retVal = new LinkedHashSet<String>();
            CachedConfig cachedConfig = ConfigUtil.getCachedConfig();
            if (cachedConfig == null) {
                this.logger.error("Cached config could not be fetched.");
                return ImmutableList.copyOf(retVal);
            }
            for (StorageService service : cachedConfig.getStorage()) {
                String ss = service.getName();
                if (!ss.toLowerCase().startsWith(lower)) continue;
                retVal.add(ss);
            }
            return ImmutableList.copyOf(retVal);
        });
        this.commandManager.getCommandCompletions().registerCompletion("player", c -> {
            String lower = c.getInput().toLowerCase();
            LinkedHashSet<String> players = new LinkedHashSet<String>();
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (!lower.isEmpty() && !p.getName().toLowerCase().startsWith(lower)) continue;
                Player player = c.getPlayer();
                if (!c.getSender().isOp() && (player == null || !player.canSee(p) || this.isVanished(p))) continue;
                players.add(p.getName());
            }
            return ImmutableList.copyOf(players);
        });
        this.commandManager.getCommandCompletions().registerCompletion("type", c -> {
            String lower = c.getInput().toLowerCase();
            LinkedHashSet<String> retVal = new LinkedHashSet<String>();
            if ("vpn".startsWith(lower)) {
                retVal.add("vpn");
            }
            if ("mcleaks".startsWith(lower)) {
                retVal.add("mcleaks");
            }
            return ImmutableList.copyOf(retVal);
        });
        this.commandManager.getCommandCompletions().registerCompletion("subcommand", c -> {
            String lower = c.getInput().toLowerCase();
            LinkedHashSet<String> commands = new LinkedHashSet<String>();
            SetMultimap<String, RegisteredCommand> subcommands = this.commandManager.getRootCommand("antivpn").getSubCommands();
            for (Map.Entry kvp : subcommands.entries()) {
                if (((RegisteredCommand)kvp.getValue()).isPrivate() || !lower.isEmpty() && !((String)kvp.getKey()).toLowerCase().startsWith(lower) || ((RegisteredCommand)kvp.getValue()).getCommand().indexOf(32) != -1) continue;
                commands.add(((RegisteredCommand)kvp.getValue()).getCommand());
            }
            return ImmutableList.copyOf(commands);
        });
        this.commandManager.registerCommand(new AntiVPNCommand(this.plugin, this.taskFactory, this.consoleCommandIssuer));
    }

    private void loadEvents() {
        this.events.add((BukkitEventSubscriber<?>)BukkitEvents.subscribe(this.plugin, PlayerLoginEvent.class, EventPriority.LOW).handler(e -> new PlayerLoginUpdateNotifyHandler(this.plugin, this.commandManager).accept((PlayerLoginEvent)e)));
        this.eventHolders.add(new PlayerEvents(this.plugin, this.consoleCommandIssuer));
    }

    private void loadTasks() {
        this.tasks.add(Bukkit.getScheduler().runTaskTimerAsynchronously(this.plugin, () -> {
            try {
                VPNAPIProvider.getInstance().runUpdateTask().join();
            }
            catch (CancellationException | CompletionException ex) {
                ExceptionUtil.handleException(ex, this.logger);
            }
        }, 1L, 20L).getTaskId());
    }

    private void loadHooks() {
        PluginManager manager = this.plugin.getServer().getPluginManager();
        Plugin plan = manager.getPlugin("Plan");
        if (plan != null) {
            this.consoleCommandIssuer.sendInfo(Message.GENERAL__HOOK_ENABLE, "{plugin}", "Plan");
            PlayerAnalyticsHook.create(this.plugin, plan);
        } else {
            this.consoleCommandIssuer.sendInfo(Message.GENERAL__HOOK_DISABLE, "{plugin}", "Plan");
        }
        if (manager.getPlugin("PlaceholderAPI") != null) {
            this.consoleCommandIssuer.sendInfo(Message.GENERAL__HOOK_ENABLE, "{plugin}", "PlaceholderAPI");
            ServiceLocator.register(new PlaceholderAPIHook());
        } else {
            this.consoleCommandIssuer.sendInfo(Message.GENERAL__HOOK_DISABLE, "{plugin}", "PlaceholderAPI");
        }
        Plugin luckperms = manager.getPlugin("LuckPerms");
        if (luckperms != null) {
            this.consoleCommandIssuer.sendInfo(Message.GENERAL__HOOK_ENABLE, "{plugin}", "LuckPerms");
            if (ConfigUtil.getDebugOrFalse()) {
                this.consoleCommandIssuer.sendMessage("<c2>Running actions on async pre-login.</c2>");
            }
            LuckPermsHook.create(this.plugin, luckperms, this.consoleCommandIssuer);
        } else {
            this.consoleCommandIssuer.sendInfo(Message.GENERAL__HOOK_DISABLE, "{plugin}", "LuckPerms");
            Plugin vault = manager.getPlugin("Vault");
            if (vault != null) {
                this.consoleCommandIssuer.sendInfo(Message.GENERAL__HOOK_ENABLE, "{plugin}", "Vault");
                if (ConfigUtil.getDebugOrFalse()) {
                    this.consoleCommandIssuer.sendMessage("<c2>Running actions on async pre-login.</c2>");
                }
                VaultHook.create(this.plugin, vault, this.consoleCommandIssuer);
            } else {
                this.consoleCommandIssuer.sendInfo(Message.GENERAL__HOOK_DISABLE, "{plugin}", "Vault");
                if (ConfigUtil.getDebugOrFalse()) {
                    this.consoleCommandIssuer.sendMessage("<c2>Running actions on sync login.</c2>");
                }
            }
        }
    }

    public static void incrementBlockedVPNs() {
        blockedVPNs.getAndIncrement();
    }

    public static void incrementBlockedMCLeaks() {
        blockedMCLeaks.getAndIncrement();
    }

    private void loadMetrics() {
        Metrics metrics = new Metrics(this.plugin, 3249);
        metrics.addCustomChart(new Metrics.SingleLineChart("blocked_vpns", () -> {
            ConfigurationNode config = ConfigUtil.getConfig();
            if (config == null) {
                return null;
            }
            if (!config.node("stats", "usage").getBoolean(true)) {
                return null;
            }
            return (int)blockedVPNs.getAndSet(0L);
        }));
        metrics.addCustomChart(new Metrics.SingleLineChart("blocked_mcleaks", () -> {
            ConfigurationNode config = ConfigUtil.getConfig();
            if (config == null) {
                return null;
            }
            if (!config.node("stats", "usage").getBoolean(true)) {
                return null;
            }
            return (int)blockedMCLeaks.getAndSet(0L);
        }));
        metrics.addCustomChart(new Metrics.AdvancedPie("storage", () -> {
            ConfigurationNode config = ConfigUtil.getConfig();
            CachedConfig cachedConfig = ConfigUtil.getCachedConfig();
            if (config == null || cachedConfig == null) {
                return null;
            }
            if (!config.node("stats", "usage").getBoolean(true)) {
                return null;
            }
            HashMap<String, Integer> retVal = new HashMap<String, Integer>();
            for (StorageService service : cachedConfig.getStorage()) {
                retVal.compute(service.getClass().getSimpleName(), (k, v) -> {
                    if (v == null) {
                        return 1;
                    }
                    return v + 1;
                });
            }
            if (retVal.isEmpty()) {
                retVal.put("None", 1);
            }
            return retVal;
        }));
        metrics.addCustomChart(new Metrics.AdvancedPie("messaging", () -> {
            ConfigurationNode config = ConfigUtil.getConfig();
            CachedConfig cachedConfig = ConfigUtil.getCachedConfig();
            if (config == null || cachedConfig == null) {
                return null;
            }
            if (!config.node("stats", "usage").getBoolean(true)) {
                return null;
            }
            HashMap<String, Integer> retVal = new HashMap<String, Integer>();
            for (MessagingService service : cachedConfig.getMessaging()) {
                retVal.compute(service.getClass().getSimpleName(), (k, v) -> {
                    if (v == null) {
                        return 1;
                    }
                    return v + 1;
                });
            }
            if (retVal.isEmpty()) {
                retVal.put("None", 1);
            }
            return retVal;
        }));
        metrics.addCustomChart(new Metrics.AdvancedPie("sources", () -> {
            ConfigurationNode config = ConfigUtil.getConfig();
            CachedConfig cachedConfig = ConfigUtil.getCachedConfig();
            if (config == null || cachedConfig == null) {
                return null;
            }
            if (!config.node("stats", "usage").getBoolean(true)) {
                return null;
            }
            HashMap<String, Integer> retVal = new HashMap<String, Integer>();
            List<Source<? extends SourceModel>> sources = VPNAPIProvider.getInstance().getSourceManager().getSources();
            for (Source<? extends SourceModel> source : sources) {
                retVal.compute(source.getName(), (k, v) -> {
                    if (v == null) {
                        return 1;
                    }
                    return v + 1;
                });
            }
            if (retVal.isEmpty()) {
                retVal.put("None", 1);
            }
            return retVal;
        }));
        metrics.addCustomChart(new Metrics.SimplePie("algorithm", () -> {
            ConfigurationNode config = ConfigUtil.getConfig();
            CachedConfig cachedConfig = ConfigUtil.getCachedConfig();
            if (config == null || cachedConfig == null) {
                return null;
            }
            if (!config.node("stats", "usage").getBoolean(true)) {
                return null;
            }
            return cachedConfig.getVPNAlgorithmMethod().getName();
        }));
        metrics.addCustomChart(new Metrics.SimplePie("vpn_action", () -> {
            ConfigurationNode config = ConfigUtil.getConfig();
            CachedConfig cachedConfig = ConfigUtil.getCachedConfig();
            if (config == null || cachedConfig == null) {
                return null;
            }
            if (!config.node("stats", "usage").getBoolean(true)) {
                return null;
            }
            if (!cachedConfig.getVPNKickMessage().isEmpty() && !cachedConfig.getVPNActionCommands().isEmpty()) {
                return "multi";
            }
            if (!cachedConfig.getVPNKickMessage().isEmpty()) {
                return "kick";
            }
            if (!cachedConfig.getVPNActionCommands().isEmpty()) {
                return "commands";
            }
            return "none";
        }));
        metrics.addCustomChart(new Metrics.SimplePie("mcleaks_action", () -> {
            ConfigurationNode config = ConfigUtil.getConfig();
            CachedConfig cachedConfig = ConfigUtil.getCachedConfig();
            if (config == null || cachedConfig == null) {
                return null;
            }
            if (!config.node("stats", "usage").getBoolean(true)) {
                return null;
            }
            if (!cachedConfig.getMCLeaksKickMessage().isEmpty() && !cachedConfig.getMCLeaksActionCommands().isEmpty()) {
                return "multi";
            }
            if (!cachedConfig.getMCLeaksKickMessage().isEmpty()) {
                return "kick";
            }
            if (!cachedConfig.getMCLeaksActionCommands().isEmpty()) {
                return "commands";
            }
            return "none";
        }));
    }

    private void checkUpdate() {
        SpigotUpdater updater;
        ConfigurationNode config = ConfigUtil.getConfig();
        if (config == null) {
            return;
        }
        try {
            updater = ServiceLocator.get(SpigotUpdater.class);
        }
        catch (IllegalAccessException | InstantiationException | ServiceNotFoundException ex) {
            this.logger.error(ex.getMessage(), ex);
            return;
        }
        if (!config.node("update", "check").getBoolean(true)) {
            return;
        }
        updater.isUpdateAvailable().thenAccept(v -> {
            if (!v.booleanValue()) {
                return;
            }
            try {
                this.consoleCommandIssuer.sendInfo(Message.GENERAL__UPDATE, "{version}", updater.getLatestVersion().get());
            }
            catch (ExecutionException ex) {
                this.logger.error(ex.getMessage(), ex);
            }
            catch (InterruptedException ex) {
                this.logger.error(ex.getMessage(), ex);
                Thread.currentThread().interrupt();
            }
        });
        try {
            Thread.sleep(3600000L);
        }
        catch (InterruptedException ignored) {
            Thread.currentThread().interrupt();
        }
        try {
            this.workPool.execute(this::checkUpdate);
        }
        catch (RejectedExecutionException rejectedExecutionException) {
            // empty catch block
        }
    }

    private void unloadHooks() {
        Set<PluginHook> hooks = ServiceLocator.remove(PluginHook.class);
        for (PluginHook hook : hooks) {
            hook.cancel();
        }
    }

    public void unloadServices() {
        VPNAPI api = VPNAPIProvider.getInstance();
        ((SyncAsyncPostCommand)api.getEventBus().post((Object)new GenericAPIDisableEvent(api))).now();
        api.getEventBus().shutdown();
        APIRegistrationUtil.deregister();
        CachedConfig cachedConfig = ConfigUtil.getCachedConfig();
        if (cachedConfig != null) {
            for (Object service : cachedConfig.getMessaging()) {
                service.close();
            }
            for (Object service : cachedConfig.getStorage()) {
                service.close();
            }
        }
        Set<MessagingHandler> messagingHandlers = ServiceLocator.remove(MessagingHandler.class);
        for (MessagingHandler handler : messagingHandlers) {
            handler.cancel();
        }
    }

    private void log(@NonNull Level level, @NonNull String message) {
        this.plugin.getServer().getLogger().log(level, this.isBukkit ? ChatColor.stripColor((String)message) : message);
    }

    private boolean isVanished(@NonNull Player player) {
        for (MetadataValue meta : player.getMetadata("vanished")) {
            if (!meta.asBoolean()) continue;
            return true;
        }
        return false;
    }
}

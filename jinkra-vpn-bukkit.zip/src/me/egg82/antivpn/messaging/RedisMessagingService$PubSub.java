/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  io.netty.buffer.ByteBuf
 *  me.egg82.antivpn.external.redis.clients.jedis.BinaryJedisPubSub
 */
package me.egg82.antivpn.messaging;

import io.netty.buffer.ByteBuf;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import me.egg82.antivpn.config.ConfigUtil;
import me.egg82.antivpn.external.redis.clients.jedis.BinaryJedisPubSub;
import me.egg82.antivpn.messaging.AbstractMessagingService;
import me.egg82.antivpn.messaging.RedisMessagingService;
import me.egg82.antivpn.messaging.packets.Packet;
import me.egg82.antivpn.utils.PacketUtil;
import org.checkerframework.checker.nullness.qual.NonNull;

private static class RedisMessagingService.PubSub
extends BinaryJedisPubSub {
    private final RedisMessagingService service;

    private RedisMessagingService.PubSub(@NonNull RedisMessagingService service) {
        this.service = service;
    }

    public void onMessage(byte @NonNull [] c, byte @NonNull [] m) {
        String channel = new String(c, StandardCharsets.UTF_8);
        if (ConfigUtil.getDebugOrFalse()) {
            this.service.logger.info("Got message from channel: " + channel);
        }
        try {
            switch (channel) {
                case "avpn-data": {
                    this.handleMessage(m);
                    break;
                }
                default: {
                    this.service.logger.warn("Got data from channel that should not exist: " + channel);
                    break;
                }
            }
        }
        catch (IOException ex) {
            this.service.logger.error("Could not handle message.", ex);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private void handleMessage(byte @NonNull [] body) throws IOException {
        ByteBuf b = AbstractMessagingService.alloc.buffer(body.length, body.length);
        ByteBuf data = null;
        try {
            b.writeBytes(body);
            data = this.service.decompressData(b);
            UUID sender = new UUID(data.readLong(), data.readLong());
            if (this.service.serverId.equals(sender)) {
                return;
            }
            UUID messageId = new UUID(data.readLong(), data.readLong());
            byte packetId = data.readByte();
            Class packetClass = (Class)PacketUtil.getPacketCache().get(packetId);
            if (packetClass == null) {
                this.service.logger.warn("Got packet ID that doesn't exist: " + packetId);
                return;
            }
            try {
                this.service.handler.handlePacket(messageId, this.service.getName(), (Packet)packetClass.getConstructor(ByteBuf.class).newInstance(data));
            }
            catch (ExceptionInInitializerError | IllegalAccessException | InstantiationException | NoSuchMethodException | SecurityException | InvocationTargetException ex) {
                this.service.logger.error("Could not instantiate packet.", ex);
            }
        }
        finally {
            b.release();
            if (data != null) {
                data.release();
            }
        }
    }
}

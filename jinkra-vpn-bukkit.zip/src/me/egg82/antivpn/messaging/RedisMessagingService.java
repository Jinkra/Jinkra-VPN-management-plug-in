/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.google.common.util.concurrent.ThreadFactoryBuilder
 *  io.netty.buffer.ByteBuf
 *  me.egg82.antivpn.external.redis.clients.jedis.BinaryJedisPubSub
 *  me.egg82.antivpn.external.redis.clients.jedis.Jedis
 *  me.egg82.antivpn.external.redis.clients.jedis.JedisPool
 *  me.egg82.antivpn.external.redis.clients.jedis.JedisPoolConfig
 *  me.egg82.antivpn.external.redis.clients.jedis.exceptions.JedisException
 */
package me.egg82.antivpn.messaging;

import com.google.common.util.concurrent.ThreadFactoryBuilder;
import io.netty.buffer.ByteBuf;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import me.egg82.antivpn.config.ConfigUtil;
import me.egg82.antivpn.external.redis.clients.jedis.BinaryJedisPubSub;
import me.egg82.antivpn.external.redis.clients.jedis.Jedis;
import me.egg82.antivpn.external.redis.clients.jedis.JedisPool;
import me.egg82.antivpn.external.redis.clients.jedis.JedisPoolConfig;
import me.egg82.antivpn.external.redis.clients.jedis.exceptions.JedisException;
import me.egg82.antivpn.messaging.AbstractMessagingService;
import me.egg82.antivpn.messaging.MessagingHandler;
import me.egg82.antivpn.messaging.packets.Packet;
import me.egg82.antivpn.utils.PacketUtil;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.checkerframework.checker.nullness.qual.NonNull;

public class RedisMessagingService
extends AbstractMessagingService {
    private final ExecutorService workPool = Executors.newFixedThreadPool(1, new ThreadFactoryBuilder().setNameFormat("AntiVPN-Redis-%d").build());
    private JedisPool pool;
    private final PubSub pubSub = new PubSub(this);
    private volatile boolean closed = false;
    private final ReadWriteLock queueLock = new ReentrantReadWriteLock();
    private static final String CHANNEL_NAME = "avpn-data";
    private static final byte[] CHANNEL_NAME_BYTES = "avpn-data".getBytes(StandardCharsets.UTF_8);

    private RedisMessagingService(@NonNull String name) {
        super(name);
    }

    @Override
    public void close() {
        this.queueLock.writeLock().lock();
        try {
            this.closed = true;
            this.workPool.shutdown();
            try {
                if (!this.workPool.awaitTermination(4L, TimeUnit.SECONDS)) {
                    this.workPool.shutdownNow();
                }
            }
            catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
            }
            this.pool.close();
        }
        finally {
            this.queueLock.writeLock().unlock();
        }
    }

    @Override
    public boolean isClosed() {
        return this.closed || this.pool.isClosed();
    }

    public static Builder builder(@NonNull String name, @NonNull UUID serverId, @NonNull MessagingHandler handler) {
        return new Builder(name, serverId, handler);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public void sendPacket(@NonNull UUID messageId, @NonNull Packet packet) throws IOException {
        this.queueLock.readLock().lock();
        try (Jedis redis = this.pool.getResource();){
            ByteBuf buffer = alloc.buffer(this.getInitialCapacity());
            try {
                buffer.writeBytes(this.serverIdBytes);
                buffer.writeLong(messageId.getMostSignificantBits());
                buffer.writeLong(messageId.getLeastSignificantBits());
                buffer.writeByte((int)packet.getPacketId());
                packet.write(buffer);
                this.addCapacity(buffer.writerIndex());
                redis.publish(CHANNEL_NAME_BYTES, this.compressData(buffer));
            }
            finally {
                buffer.release();
            }
        }
        catch (JedisException ex) {
            throw new IOException(ex);
        }
        finally {
            this.queueLock.readLock().unlock();
        }
    }

    private static class PubSub
    extends BinaryJedisPubSub {
        private final RedisMessagingService service;

        private PubSub(@NonNull RedisMessagingService service) {
            this.service = service;
        }

        public void onMessage(byte @NonNull [] c, byte @NonNull [] m) {
            String channel = new String(c, StandardCharsets.UTF_8);
            if (ConfigUtil.getDebugOrFalse()) {
                this.service.logger.info("Got message from channel: " + channel);
            }
            try {
                switch (channel) {
                    case "avpn-data": {
                        this.handleMessage(m);
                        break;
                    }
                    default: {
                        this.service.logger.warn("Got data from channel that should not exist: " + channel);
                        break;
                    }
                }
            }
            catch (IOException ex) {
                this.service.logger.error("Could not handle message.", ex);
            }
        }

        /*
         * WARNING - Removed try catching itself - possible behaviour change.
         */
        private void handleMessage(byte @NonNull [] body) throws IOException {
            ByteBuf b = AbstractMessagingService.alloc.buffer(body.length, body.length);
            ByteBuf data = null;
            try {
                b.writeBytes(body);
                data = this.service.decompressData(b);
                UUID sender = new UUID(data.readLong(), data.readLong());
                if (this.service.serverId.equals(sender)) {
                    return;
                }
                UUID messageId = new UUID(data.readLong(), data.readLong());
                byte packetId = data.readByte();
                Class packetClass = (Class)PacketUtil.getPacketCache().get(packetId);
                if (packetClass == null) {
                    this.service.logger.warn("Got packet ID that doesn't exist: " + packetId);
                    return;
                }
                try {
                    this.service.handler.handlePacket(messageId, this.service.getName(), (Packet)packetClass.getConstructor(ByteBuf.class).newInstance(data));
                }
                catch (ExceptionInInitializerError | IllegalAccessException | InstantiationException | NoSuchMethodException | SecurityException | InvocationTargetException ex) {
                    this.service.logger.error("Could not instantiate packet.", ex);
                }
            }
            finally {
                b.release();
                if (data != null) {
                    data.release();
                }
            }
        }
    }

    public static class Builder {
        private final RedisMessagingService service;
        private final JedisPoolConfig config = new JedisPoolConfig();
        private String address = "127.0.0.1";
        private int port = 6379;
        private int timeout = 5000;
        private String pass = "";

        /*
         * WARNING - Removed try catching itself - possible behaviour change.
         */
        public Builder(@NonNull String name, @NonNull UUID serverId, @NonNull MessagingHandler handler) {
            this.service = new RedisMessagingService(name);
            this.service.serverId = serverId;
            this.service.serverIdString = serverId.toString();
            ByteBuf buffer = AbstractMessagingService.alloc.buffer(16, 16);
            try {
                buffer.writeLong(serverId.getMostSignificantBits());
                buffer.writeLong(serverId.getLeastSignificantBits());
                if (buffer.isDirect()) {
                    this.service.serverIdBytes = new byte[16];
                    buffer.readBytes(this.service.serverIdBytes);
                } else {
                    this.service.serverIdBytes = buffer.array();
                }
            }
            finally {
                buffer.release();
            }
            this.service.handler = handler;
        }

        public Builder url(@NonNull String address, int port) {
            this.address = address;
            this.port = port;
            return this;
        }

        public Builder credentials(@NonNull String pass) {
            this.pass = pass;
            return this;
        }

        public Builder poolSize(int min, int max) {
            this.config.setMinIdle(min);
            this.config.setMaxTotal(max);
            return this;
        }

        public Builder life(long lifetime, int timeout) {
            this.config.setMinEvictableIdleTimeMillis(lifetime);
            this.config.setMaxWaitMillis((long)timeout);
            this.timeout = timeout;
            return this;
        }

        public @NonNull RedisMessagingService build() {
            this.service.pool = new JedisPool((GenericObjectPoolConfig)this.config, this.address, this.port, this.timeout, this.pass == null || this.pass.isEmpty() ? null : this.pass);
            this.warmup(this.service.pool);
            this.subscribe();
            return this.service;
        }

        private void subscribe() {
            this.service.workPool.execute(() -> {
                while (!this.service.isClosed()) {
                    try {
                        Jedis redis = this.service.pool.getResource();
                        Throwable throwable = null;
                        try {
                            redis.subscribe((BinaryJedisPubSub)this.service.pubSub, (byte[][])new byte[][]{CHANNEL_NAME_BYTES});
                        }
                        catch (Throwable throwable2) {
                            throwable = throwable2;
                            throw throwable2;
                        }
                        finally {
                            if (redis == null) continue;
                            if (throwable != null) {
                                try {
                                    redis.close();
                                }
                                catch (Throwable throwable3) {
                                    throwable.addSuppressed(throwable3);
                                }
                                continue;
                            }
                            redis.close();
                        }
                    }
                    catch (JedisException ex) {
                        if (this.service.isClosed()) continue;
                        this.service.logger.warn("Redis pub/sub disconnected. Reconnecting..");
                    }
                }
            });
        }

        private void warmup(@NonNull JedisPool pool) {
            Jedis jedis;
            int i;
            Jedis[] warmpupArr = new Jedis[this.config.getMinIdle()];
            for (i = 0; i < this.config.getMinIdle(); ++i) {
                warmpupArr[i] = jedis = pool.getResource();
                jedis.ping();
            }
            for (i = 0; i < this.config.getMinIdle(); ++i) {
                jedis = warmpupArr[i];
                jedis.close();
            }
        }
    }
}

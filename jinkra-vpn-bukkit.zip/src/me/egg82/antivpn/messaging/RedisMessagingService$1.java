/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.messaging;

static class RedisMessagingService.1 {
}

/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.messaging;

private static enum RabbitMQMessagingService.DeliveryMode {
    TRANSIENT(1),
    PERSISTENT(2);

    private final int mode;

    private RabbitMQMessagingService.DeliveryMode(int mode) {
        this.mode = mode;
    }

    public int getMode() {
        return this.mode;
    }
}

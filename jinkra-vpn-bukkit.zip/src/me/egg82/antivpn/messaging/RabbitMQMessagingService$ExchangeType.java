/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.messaging;

import org.checkerframework.checker.nullness.qual.NonNull;

private static enum RabbitMQMessagingService.ExchangeType {
    DIRECT("direct"),
    FANOUT("fanout"),
    TOPIC("topic"),
    HEADERS("match");

    private final String type;

    private RabbitMQMessagingService.ExchangeType(String type) {
        this.type = type;
    }

    public @NonNull String getType() {
        return this.type;
    }
}

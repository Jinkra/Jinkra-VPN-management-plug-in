/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.messaging;

import java.util.UUID;
import me.egg82.antivpn.messaging.packets.Packet;
import org.checkerframework.checker.nullness.qual.NonNull;

public interface MessagingHandler {
    public void handlePacket(@NonNull UUID var1, @NonNull String var2, @NonNull Packet var3);

    public void cancel();
}

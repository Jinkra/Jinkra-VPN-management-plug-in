/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  io.netty.buffer.ByteBuf
 *  me.egg82.antivpn.external.com.rabbitmq.client.AMQP$BasicProperties
 *  me.egg82.antivpn.external.com.rabbitmq.client.Channel
 *  me.egg82.antivpn.external.com.rabbitmq.client.DefaultConsumer
 *  me.egg82.antivpn.external.com.rabbitmq.client.Envelope
 */
package me.egg82.antivpn.messaging;

import io.netty.buffer.ByteBuf;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.UUID;
import me.egg82.antivpn.config.ConfigUtil;
import me.egg82.antivpn.external.com.rabbitmq.client.AMQP;
import me.egg82.antivpn.external.com.rabbitmq.client.Channel;
import me.egg82.antivpn.external.com.rabbitmq.client.DefaultConsumer;
import me.egg82.antivpn.external.com.rabbitmq.client.Envelope;
import me.egg82.antivpn.messaging.AbstractMessagingService;
import me.egg82.antivpn.messaging.packets.Packet;
import me.egg82.antivpn.utils.PacketUtil;

class RabbitMQMessagingService.1
extends DefaultConsumer {
    RabbitMQMessagingService.1(Channel x0) {
        super(x0);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void handleDelivery(String tag, Envelope envelope, AMQP.BasicProperties properties, byte[] body) throws IOException {
        if (ConfigUtil.getDebugOrFalse()) {
            RabbitMQMessagingService.this.logger.info("Got message from exchange: " + envelope.getExchange());
        }
        if (!RabbitMQMessagingService.this.validateProperties(properties)) {
            return;
        }
        ByteBuf b = AbstractMessagingService.alloc.buffer(body.length, body.length);
        ByteBuf data = null;
        try {
            b.writeBytes(body);
            data = RabbitMQMessagingService.this.decompressData(b);
            byte packetId = data.readByte();
            Class packetClass = (Class)PacketUtil.getPacketCache().get(packetId);
            if (packetClass == null) {
                RabbitMQMessagingService.this.logger.warn("Got packet ID that doesn't exist: " + packetId);
                return;
            }
            try {
                RabbitMQMessagingService.this.handler.handlePacket(UUID.fromString(properties.getMessageId()), RabbitMQMessagingService.this.getName(), (Packet)packetClass.getConstructor(ByteBuf.class).newInstance(data));
            }
            catch (ExceptionInInitializerError | IllegalAccessException | InstantiationException | NoSuchMethodException | SecurityException | InvocationTargetException ex) {
                RabbitMQMessagingService.this.logger.error("Could not instantiate packet.", ex);
            }
        }
        finally {
            b.release();
            if (data != null) {
                data.release();
            }
        }
    }
}

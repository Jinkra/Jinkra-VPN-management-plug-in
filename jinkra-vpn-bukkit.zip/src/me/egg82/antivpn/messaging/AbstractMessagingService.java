/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.github.luben.zstd.Zstd
 *  com.github.luben.zstd.ZstdException
 *  io.netty.buffer.ByteBuf
 *  io.netty.buffer.ByteBufAllocator
 *  io.netty.buffer.PooledByteBufAllocator
 *  me.egg82.antivpn.external.it.unimi.dsi.fastutil.ints.IntArrayList
 *  me.egg82.antivpn.external.it.unimi.dsi.fastutil.ints.IntList
 */
package me.egg82.antivpn.messaging;

import com.github.luben.zstd.Zstd;
import com.github.luben.zstd.ZstdException;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufAllocator;
import io.netty.buffer.PooledByteBufAllocator;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.text.DecimalFormat;
import java.util.UUID;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import me.egg82.antivpn.config.ConfigUtil;
import me.egg82.antivpn.external.it.unimi.dsi.fastutil.ints.IntArrayList;
import me.egg82.antivpn.external.it.unimi.dsi.fastutil.ints.IntList;
import me.egg82.antivpn.messaging.MessagingHandler;
import me.egg82.antivpn.messaging.MessagingService;
import me.egg82.antivpn.utils.MathUtil;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class AbstractMessagingService
implements MessagingService {
    protected final Logger logger = LoggerFactory.getLogger(this.getClass());
    private static final DecimalFormat ratioFormat = new DecimalFormat("0.#####");
    protected static final ByteBufAllocator alloc = PooledByteBufAllocator.DEFAULT;
    protected final String name;
    protected UUID serverId;
    protected String serverIdString;
    protected byte[] serverIdBytes;
    protected MessagingHandler handler;
    private static final double TOLERANCE = 1.1;
    private final IntList capacities = new IntArrayList();
    private volatile int capacity = 2048;
    private final ReadWriteLock capacityLock = new ReentrantReadWriteLock();

    protected AbstractMessagingService(@NonNull String name) {
        this.name = name;
    }

    @Override
    public @NonNull String getName() {
        return this.name;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    protected final byte @NonNull [] compressData(ByteBuf data) throws IOException {
        if (data == null || data.capacity() == 0) {
            return new byte[0];
        }
        data.readerIndex(0);
        int uncompressedBytes = data.writerIndex();
        int upperBound = (int)Zstd.compressBound((long)uncompressedBytes) + 5;
        ByteBuf nd = alloc.directBuffer(uncompressedBytes, uncompressedBytes);
        ByteBuf ndd = alloc.directBuffer(upperBound, upperBound);
        try {
            data.readBytes(nd);
            ByteBuffer d = nd.nioBuffer(0, uncompressedBytes);
            ByteBuffer dest = ndd.nioBuffer(0, upperBound);
            long compressedBytes = Zstd.compressDirectByteBuffer((ByteBuffer)dest, (int)5, (int)(upperBound - 5), (ByteBuffer)d, (int)0, (int)uncompressedBytes, (int)9);
            if (Zstd.isError((long)compressedBytes)) {
                throw new IOException((Throwable)new ZstdException(compressedBytes));
            }
            if ((double)uncompressedBytes / (double)(compressedBytes + 4L) < 1.1) {
                byte[] out = new byte[uncompressedBytes + 1];
                out[0] = 0;
                nd.readBytes(out, 1, uncompressedBytes);
                if (ConfigUtil.getDebugOrFalse()) {
                    this.logger.info("Sent (no) compression: " + out.length + "/" + uncompressedBytes + " (" + ratioFormat.format((double)uncompressedBytes / (double)out.length) + ")");
                }
                byte[] byArray = out;
                return byArray;
            }
            if (ConfigUtil.getDebugOrFalse()) {
                this.logger.info("Sent compression: " + (compressedBytes + 5L) + "/" + uncompressedBytes + " (" + ratioFormat.format((double)uncompressedBytes / (double)(compressedBytes + 5L)) + ")");
            }
            dest.put(0, (byte)1);
            dest.putInt(1, uncompressedBytes);
            dest.rewind();
            byte[] out = new byte[(int)compressedBytes + 5];
            dest.get(out);
            byte[] byArray = out;
            return byArray;
        }
        finally {
            nd.release();
            ndd.release();
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    protected final @NonNull ByteBuf decompressData(ByteBuf data) throws IOException {
        boolean compressed;
        if (data == null || data.capacity() == 0) {
            return alloc.buffer(0, 0);
        }
        int compressedBytes = data.writerIndex();
        data.readerIndex(0);
        boolean bl = compressed = data.readByte() != 0;
        if (!compressed) {
            ByteBuf retVal = alloc.buffer(compressedBytes - 1, compressedBytes - 1);
            data.readBytes(retVal);
            if (ConfigUtil.getDebugOrFalse()) {
                this.logger.info("Received (no) compression: " + compressedBytes + "/" + (compressedBytes - 1) + " (" + ratioFormat.format((double)(compressedBytes - 1) / (double)compressedBytes) + ")");
            }
            return retVal;
        }
        int uncompressedBytes = data.readInt();
        ByteBuf nd = alloc.directBuffer(compressedBytes - 5, compressedBytes - 5);
        ByteBuf ndd = alloc.directBuffer(uncompressedBytes, uncompressedBytes);
        try {
            data.readBytes(nd);
            ByteBuffer d = nd.nioBuffer(0, compressedBytes - 5);
            ByteBuffer dest = ndd.nioBuffer(0, uncompressedBytes);
            long decompressedBytes = Zstd.decompressDirectByteBuffer((ByteBuffer)dest, (int)0, (int)uncompressedBytes, (ByteBuffer)d, (int)0, (int)(compressedBytes - 5));
            if (Zstd.isError((long)decompressedBytes)) {
                throw new IOException((Throwable)new ZstdException(decompressedBytes));
            }
            if (ConfigUtil.getDebugOrFalse()) {
                this.logger.info("Received compression: " + compressedBytes + "/" + uncompressedBytes + " (" + ratioFormat.format((double)uncompressedBytes / (double)compressedBytes) + ")");
            }
            dest.rewind();
            ByteBuf retVal = alloc.buffer(uncompressedBytes, uncompressedBytes);
            retVal.writeBytes(dest);
            ByteBuf byteBuf = retVal;
            return byteBuf;
        }
        finally {
            nd.release();
            ndd.release();
        }
    }

    protected int getInitialCapacity() {
        this.capacityLock.readLock().lock();
        try {
            int n = this.capacity;
            return n;
        }
        finally {
            this.capacityLock.readLock().unlock();
        }
    }

    protected void addCapacity(int capacity) {
        this.capacities.add(capacity);
        if (this.capacities.size() >= 50) {
            this.capacityLock.writeLock().lock();
            try {
                if (this.capacities.size() >= 50) {
                    this.capacity = MathUtil.percentile(this.capacities, 80.0);
                    if (ConfigUtil.getDebugOrFalse()) {
                        this.logger.info("Set initial capacity to " + ratioFormat.format((double)this.capacity / 1024.0) + "kb");
                    }
                    this.capacities.clear();
                }
            }
            finally {
                this.capacityLock.writeLock().unlock();
            }
        }
    }

    private void printBytes(@NonNull ByteBuf buffer) {
        StringBuilder sb = new StringBuilder();
        sb.append('\n');
        sb.append("-- Begin Message --");
        sb.append('\n');
        sb.append("Bytes:");
        sb.append('\n');
        int index = buffer.readerIndex();
        buffer.readerIndex(0);
        while (buffer.readableBytes() > 0) {
            sb.append(String.format("0x%02X ", buffer.readByte()));
        }
        sb.append('\n');
        buffer.readerIndex(0);
        while (buffer.readableBytes() > 0) {
            sb.append(String.format("%8s ", Integer.toBinaryString(buffer.readByte() & 0xFF)).replace(' ', '0') + " ");
        }
        sb.append('\n');
        buffer.readerIndex(0);
        while (buffer.readableBytes() > 0) {
            sb.append(buffer.readByte() + " ");
        }
        buffer.readerIndex(index);
        sb.append('\n');
        sb.append("-- End Message --");
        this.logger.info(sb.toString());
    }

    private void printBytes(byte @NonNull [] bytes) {
        int i;
        StringBuilder sb = new StringBuilder();
        sb.append('\n');
        sb.append("-- Begin Message --");
        sb.append('\n');
        sb.append("Bytes:");
        sb.append('\n');
        for (i = 0; i < bytes.length; ++i) {
            sb.append(String.format("0x%02X ", bytes[i]));
        }
        sb.append('\n');
        for (i = 0; i < bytes.length; ++i) {
            sb.append(String.format("%8s ", Integer.toBinaryString(bytes[i] & 0xFF)).replace(' ', '0') + " ");
        }
        sb.append('\n');
        for (i = 0; i < bytes.length; ++i) {
            sb.append(bytes[i] + " ");
        }
        sb.append('\n');
        sb.append("-- End Message --");
        this.logger.info(sb.toString());
    }
}

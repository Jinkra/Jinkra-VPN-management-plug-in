/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  io.netty.buffer.ByteBuf
 *  me.egg82.antivpn.external.redis.clients.jedis.BinaryJedisPubSub
 *  me.egg82.antivpn.external.redis.clients.jedis.Jedis
 *  me.egg82.antivpn.external.redis.clients.jedis.JedisPool
 *  me.egg82.antivpn.external.redis.clients.jedis.JedisPoolConfig
 *  me.egg82.antivpn.external.redis.clients.jedis.exceptions.JedisException
 */
package me.egg82.antivpn.messaging;

import io.netty.buffer.ByteBuf;
import java.util.UUID;
import me.egg82.antivpn.external.redis.clients.jedis.BinaryJedisPubSub;
import me.egg82.antivpn.external.redis.clients.jedis.Jedis;
import me.egg82.antivpn.external.redis.clients.jedis.JedisPool;
import me.egg82.antivpn.external.redis.clients.jedis.JedisPoolConfig;
import me.egg82.antivpn.external.redis.clients.jedis.exceptions.JedisException;
import me.egg82.antivpn.messaging.AbstractMessagingService;
import me.egg82.antivpn.messaging.MessagingHandler;
import me.egg82.antivpn.messaging.RedisMessagingService;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.checkerframework.checker.nullness.qual.NonNull;

public static class RedisMessagingService.Builder {
    private final RedisMessagingService service;
    private final JedisPoolConfig config = new JedisPoolConfig();
    private String address = "127.0.0.1";
    private int port = 6379;
    private int timeout = 5000;
    private String pass = "";

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public RedisMessagingService.Builder(@NonNull String name, @NonNull UUID serverId, @NonNull MessagingHandler handler) {
        this.service = new RedisMessagingService(name, null);
        this.service.serverId = serverId;
        this.service.serverIdString = serverId.toString();
        ByteBuf buffer = AbstractMessagingService.alloc.buffer(16, 16);
        try {
            buffer.writeLong(serverId.getMostSignificantBits());
            buffer.writeLong(serverId.getLeastSignificantBits());
            if (buffer.isDirect()) {
                this.service.serverIdBytes = new byte[16];
                buffer.readBytes(this.service.serverIdBytes);
            } else {
                this.service.serverIdBytes = buffer.array();
            }
        }
        finally {
            buffer.release();
        }
        this.service.handler = handler;
    }

    public RedisMessagingService.Builder url(@NonNull String address, int port) {
        this.address = address;
        this.port = port;
        return this;
    }

    public RedisMessagingService.Builder credentials(@NonNull String pass) {
        this.pass = pass;
        return this;
    }

    public RedisMessagingService.Builder poolSize(int min, int max) {
        this.config.setMinIdle(min);
        this.config.setMaxTotal(max);
        return this;
    }

    public RedisMessagingService.Builder life(long lifetime, int timeout) {
        this.config.setMinEvictableIdleTimeMillis(lifetime);
        this.config.setMaxWaitMillis((long)timeout);
        this.timeout = timeout;
        return this;
    }

    public @NonNull RedisMessagingService build() {
        this.service.pool = new JedisPool((GenericObjectPoolConfig)this.config, this.address, this.port, this.timeout, this.pass == null || this.pass.isEmpty() ? null : this.pass);
        this.warmup(this.service.pool);
        this.subscribe();
        return this.service;
    }

    private void subscribe() {
        this.service.workPool.execute(() -> {
            while (!this.service.isClosed()) {
                try {
                    Jedis redis = this.service.pool.getResource();
                    Throwable throwable = null;
                    try {
                        redis.subscribe((BinaryJedisPubSub)this.service.pubSub, (byte[][])new byte[][]{CHANNEL_NAME_BYTES});
                    }
                    catch (Throwable throwable2) {
                        throwable = throwable2;
                        throw throwable2;
                    }
                    finally {
                        if (redis == null) continue;
                        if (throwable != null) {
                            try {
                                redis.close();
                            }
                            catch (Throwable throwable3) {
                                throwable.addSuppressed(throwable3);
                            }
                            continue;
                        }
                        redis.close();
                    }
                }
                catch (JedisException ex) {
                    if (this.service.isClosed()) continue;
                    this.service.logger.warn("Redis pub/sub disconnected. Reconnecting..");
                }
            }
        });
    }

    private void warmup(@NonNull JedisPool pool) {
        Jedis jedis;
        int i;
        Jedis[] warmpupArr = new Jedis[this.config.getMinIdle()];
        for (i = 0; i < this.config.getMinIdle(); ++i) {
            warmpupArr[i] = jedis = pool.getResource();
            jedis.ping();
        }
        for (i = 0; i < this.config.getMinIdle(); ++i) {
            jedis = warmpupArr[i];
            jedis.close();
        }
    }
}

/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.messaging;

import java.io.IOException;
import java.util.UUID;
import java.util.concurrent.TimeoutException;
import me.egg82.antivpn.messaging.packets.Packet;
import org.checkerframework.checker.nullness.qual.NonNull;

public interface MessagingService {
    public String getName();

    public void close();

    public boolean isClosed();

    public void sendPacket(@NonNull UUID var1, @NonNull Packet var2) throws IOException, TimeoutException;
}

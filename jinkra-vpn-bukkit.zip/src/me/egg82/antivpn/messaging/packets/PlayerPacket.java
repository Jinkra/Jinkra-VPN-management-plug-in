/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  io.netty.buffer.ByteBuf
 */
package me.egg82.antivpn.messaging.packets;

import io.netty.buffer.ByteBuf;
import java.util.Objects;
import java.util.UUID;
import me.egg82.antivpn.messaging.packets.AbstractPacket;
import org.checkerframework.checker.nullness.qual.NonNull;

public class PlayerPacket
extends AbstractPacket {
    private UUID uuid;
    private boolean value;

    @Override
    public byte getPacketId() {
        return 2;
    }

    public PlayerPacket(@NonNull ByteBuf data) {
        this.read(data);
    }

    public PlayerPacket() {
        this.uuid = new UUID(0L, 0L);
        this.value = false;
    }

    @Override
    public void read(@NonNull ByteBuf buffer) {
        if (!this.checkVersion(buffer)) {
            return;
        }
        this.uuid = this.readUUID(buffer);
        this.value = buffer.readBoolean();
        this.checkReadPacket(buffer);
    }

    @Override
    public void write(@NonNull ByteBuf buffer) {
        buffer.writeByte(1);
        this.writeUUID(this.uuid, buffer);
        buffer.writeBoolean(this.value);
    }

    public @NonNull UUID getUuid() {
        return this.uuid;
    }

    public void setUuid(@NonNull UUID uuid) {
        this.uuid = uuid;
    }

    public boolean getValue() {
        return this.value;
    }

    public void setValue(boolean value) {
        this.value = value;
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof PlayerPacket)) {
            return false;
        }
        PlayerPacket that = (PlayerPacket)o;
        return this.value == that.value && this.uuid.equals(that.uuid);
    }

    public int hashCode() {
        return Objects.hash(this.uuid, this.value);
    }

    public String toString() {
        return "PlayerPacket{uuid=" + this.uuid + ", value=" + this.value + '}';
    }
}

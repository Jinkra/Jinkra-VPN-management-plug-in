/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  io.netty.buffer.ByteBuf
 */
package me.egg82.antivpn.messaging.packets;

import io.netty.buffer.ByteBuf;
import java.io.Serializable;
import org.checkerframework.checker.nullness.qual.NonNull;

public interface Packet
extends Serializable {
    public static final byte VERSION = 1;

    public byte getPacketId();

    public void read(@NonNull ByteBuf var1);

    public void write(@NonNull ByteBuf var1);
}

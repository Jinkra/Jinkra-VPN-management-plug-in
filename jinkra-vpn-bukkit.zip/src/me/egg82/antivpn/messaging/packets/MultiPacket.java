/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  io.netty.buffer.ByteBuf
 *  io.netty.buffer.ByteBufAllocator
 *  io.netty.buffer.PooledByteBufAllocator
 */
package me.egg82.antivpn.messaging.packets;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufAllocator;
import io.netty.buffer.PooledByteBufAllocator;
import java.lang.reflect.InvocationTargetException;
import java.util.LinkedHashSet;
import java.util.Objects;
import java.util.Set;
import me.egg82.antivpn.messaging.packets.AbstractPacket;
import me.egg82.antivpn.messaging.packets.Packet;
import me.egg82.antivpn.utils.PacketUtil;
import org.checkerframework.checker.nullness.qual.NonNull;

public class MultiPacket
extends AbstractPacket {
    private static final ByteBufAllocator alloc = PooledByteBufAllocator.DEFAULT;
    private Set<Packet> packets = new LinkedHashSet<Packet>();

    @Override
    public byte getPacketId() {
        return 33;
    }

    public MultiPacket(@NonNull ByteBuf data) {
        this.read(data);
    }

    public MultiPacket() {
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public void read(@NonNull ByteBuf buffer) {
        byte nextPacket;
        if (!this.checkVersion(buffer)) {
            return;
        }
        this.packets.clear();
        while (buffer.readableBytes() > 0 && (nextPacket = buffer.readByte()) != 0) {
            Class packetClass = (Class)PacketUtil.getPacketCache().get(nextPacket);
            if (packetClass == null) {
                this.logger.warn("Got packet ID that doesn't exist: " + nextPacket);
                continue;
            }
            int packetLen = buffer.readInt();
            ByteBuf packetBuf = alloc.buffer(packetLen, packetLen);
            try {
                buffer.readBytes(packetBuf);
                try {
                    this.packets.add((Packet)packetClass.getConstructor(ByteBuf.class).newInstance(packetBuf));
                }
                catch (ExceptionInInitializerError | IllegalAccessException | InstantiationException | NoSuchMethodException | SecurityException | InvocationTargetException ex) {
                    this.logger.error("Could not instantiate packet " + packetClass.getSimpleName() + ".", ex);
                }
            }
            finally {
                packetBuf.release();
            }
        }
        this.checkReadPacket(buffer);
    }

    @Override
    public void write(@NonNull ByteBuf buffer) {
        buffer.writeByte(1);
        if (this.packets.isEmpty()) {
            buffer.writeByte(0);
            return;
        }
        for (Packet packet : this.packets) {
            if (packet == null) continue;
            buffer.writeByte((int)packet.getPacketId());
            int start = buffer.writerIndex();
            buffer.writeInt(0);
            packet.write(buffer);
            buffer.setInt(start, buffer.writerIndex() - start - 4);
        }
        buffer.writeByte(0);
    }

    public @NonNull Set<Packet> getPackets() {
        return this.packets;
    }

    public void setPackets(@NonNull Set<Packet> packets) {
        this.packets = packets;
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof MultiPacket)) {
            return false;
        }
        MultiPacket that = (MultiPacket)o;
        return this.packets.equals(that.packets);
    }

    public int hashCode() {
        return Objects.hash(this.packets);
    }

    public String toString() {
        return "MultiPacket{packets=" + this.packets + '}';
    }
}

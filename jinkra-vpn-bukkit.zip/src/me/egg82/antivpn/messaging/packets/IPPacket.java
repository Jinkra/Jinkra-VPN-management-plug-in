/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  io.netty.buffer.ByteBuf
 */
package me.egg82.antivpn.messaging.packets;

import io.netty.buffer.ByteBuf;
import java.util.Objects;
import me.egg82.antivpn.api.model.ip.AlgorithmMethod;
import me.egg82.antivpn.messaging.packets.AbstractPacket;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.checkerframework.checker.nullness.qual.Nullable;

public class IPPacket
extends AbstractPacket {
    private String ip;
    private int type;
    private Boolean cascade;
    private Double consensus;

    @Override
    public byte getPacketId() {
        return 1;
    }

    public IPPacket(@NonNull ByteBuf data) {
        this.read(data);
    }

    public IPPacket() {
        this.ip = "";
        this.type = -1;
        this.cascade = null;
        this.consensus = null;
    }

    @Override
    public void read(@NonNull ByteBuf buffer) {
        if (!this.checkVersion(buffer)) {
            return;
        }
        this.ip = this.readString(buffer);
        this.type = this.readVarInt(buffer);
        AlgorithmMethod method = AlgorithmMethod.values()[this.type];
        if (method == AlgorithmMethod.CASCADE) {
            this.cascade = buffer.readBoolean();
        } else {
            this.consensus = buffer.readDouble();
        }
        this.checkReadPacket(buffer);
    }

    @Override
    public void write(@NonNull ByteBuf buffer) {
        buffer.writeByte(1);
        this.writeString(this.ip, buffer);
        this.writeVarInt(this.type, buffer);
        AlgorithmMethod method = AlgorithmMethod.values()[this.type];
        if (method == AlgorithmMethod.CASCADE) {
            if (this.cascade == null) {
                throw new RuntimeException("cascade was selected as type but value is null.");
            }
            buffer.writeBoolean(this.cascade.booleanValue());
        } else {
            if (this.consensus == null) {
                throw new RuntimeException("consensus was selected as type but value is null.");
            }
            buffer.writeDouble(this.consensus.doubleValue());
        }
    }

    public @NonNull String getIp() {
        return this.ip;
    }

    public void setIp(@NonNull String ip) {
        this.ip = ip;
    }

    public @Nullable Boolean getCascade() {
        return this.cascade;
    }

    public void setCascade(Boolean cascade) {
        this.cascade = cascade;
    }

    public @Nullable Double getConsensus() {
        return this.consensus;
    }

    public void setConsensus(Double consensus) {
        this.consensus = consensus;
    }

    public int getType() {
        return this.type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof IPPacket)) {
            return false;
        }
        IPPacket ipPacket = (IPPacket)o;
        return this.type == ipPacket.type && this.ip.equals(ipPacket.ip) && Objects.equals(this.cascade, ipPacket.cascade) && Objects.equals(this.consensus, ipPacket.consensus);
    }

    public int hashCode() {
        return Objects.hash(this.ip, this.type, this.cascade, this.consensus);
    }

    public String toString() {
        return "IPPacket{ip='" + this.ip + '\'' + ", type=" + this.type + ", cascade=" + this.cascade + ", consensus=" + this.consensus + '}';
    }
}

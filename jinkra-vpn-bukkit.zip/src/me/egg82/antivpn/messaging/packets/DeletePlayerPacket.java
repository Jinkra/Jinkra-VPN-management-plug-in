/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  io.netty.buffer.ByteBuf
 */
package me.egg82.antivpn.messaging.packets;

import io.netty.buffer.ByteBuf;
import java.util.Objects;
import java.util.UUID;
import me.egg82.antivpn.messaging.packets.AbstractPacket;
import org.checkerframework.checker.nullness.qual.NonNull;

public class DeletePlayerPacket
extends AbstractPacket {
    private UUID uuid;

    @Override
    public byte getPacketId() {
        return 4;
    }

    public DeletePlayerPacket(@NonNull ByteBuf data) {
        this.read(data);
    }

    public DeletePlayerPacket() {
        this.uuid = new UUID(0L, 0L);
    }

    @Override
    public void read(@NonNull ByteBuf buffer) {
        if (!this.checkVersion(buffer)) {
            return;
        }
        this.uuid = this.readUUID(buffer);
        this.checkReadPacket(buffer);
    }

    @Override
    public void write(@NonNull ByteBuf buffer) {
        buffer.writeByte(1);
        this.writeUUID(this.uuid, buffer);
    }

    public @NonNull UUID getUuid() {
        return this.uuid;
    }

    public void setUuid(@NonNull UUID uuid) {
        this.uuid = uuid;
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof DeletePlayerPacket)) {
            return false;
        }
        DeletePlayerPacket that = (DeletePlayerPacket)o;
        return this.uuid.equals(that.uuid);
    }

    public int hashCode() {
        return Objects.hash(this.uuid);
    }

    public String toString() {
        return "DeletePlayerPacket{uuid=" + this.uuid + '}';
    }
}

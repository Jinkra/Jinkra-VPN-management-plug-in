/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  io.netty.buffer.ByteBuf
 */
package me.egg82.antivpn.messaging.packets;

import io.netty.buffer.ByteBuf;
import java.util.Objects;
import me.egg82.antivpn.messaging.packets.AbstractPacket;
import org.checkerframework.checker.nullness.qual.NonNull;

public class DeleteIPPacket
extends AbstractPacket {
    private String ip;

    @Override
    public byte getPacketId() {
        return 3;
    }

    public DeleteIPPacket(@NonNull ByteBuf data) {
        this.read(data);
    }

    public DeleteIPPacket() {
        this.ip = "";
    }

    @Override
    public void read(@NonNull ByteBuf buffer) {
        if (!this.checkVersion(buffer)) {
            return;
        }
        this.ip = this.readString(buffer);
        this.checkReadPacket(buffer);
    }

    @Override
    public void write(@NonNull ByteBuf buffer) {
        buffer.writeByte(1);
        this.writeString(this.ip, buffer);
    }

    public @NonNull String getIp() {
        return this.ip;
    }

    public void setIp(@NonNull String ip) {
        this.ip = ip;
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof DeleteIPPacket)) {
            return false;
        }
        DeleteIPPacket that = (DeleteIPPacket)o;
        return this.ip.equals(that.ip);
    }

    public int hashCode() {
        return Objects.hash(this.ip);
    }

    public String toString() {
        return "DeleteIPPacket{ip='" + this.ip + '\'' + '}';
    }
}

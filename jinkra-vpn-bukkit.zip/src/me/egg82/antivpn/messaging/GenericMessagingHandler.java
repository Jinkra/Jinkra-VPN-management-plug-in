/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  me.egg82.antivpn.external.com.github.benmanes.caffeine.cache.Caffeine
 *  me.egg82.antivpn.external.com.github.benmanes.caffeine.cache.LoadingCache
 */
package me.egg82.antivpn.messaging;

import java.util.UUID;
import java.util.concurrent.TimeUnit;
import me.egg82.antivpn.api.APIUtil;
import me.egg82.antivpn.api.model.ip.AbstractIPManager;
import me.egg82.antivpn.api.model.ip.AlgorithmMethod;
import me.egg82.antivpn.api.model.player.AbstractPlayerManager;
import me.egg82.antivpn.config.CachedConfig;
import me.egg82.antivpn.config.ConfigUtil;
import me.egg82.antivpn.core.Pair;
import me.egg82.antivpn.external.com.github.benmanes.caffeine.cache.Caffeine;
import me.egg82.antivpn.external.com.github.benmanes.caffeine.cache.LoadingCache;
import me.egg82.antivpn.messaging.MessagingHandler;
import me.egg82.antivpn.messaging.packets.DeleteIPPacket;
import me.egg82.antivpn.messaging.packets.DeletePlayerPacket;
import me.egg82.antivpn.messaging.packets.IPPacket;
import me.egg82.antivpn.messaging.packets.MultiPacket;
import me.egg82.antivpn.messaging.packets.Packet;
import me.egg82.antivpn.messaging.packets.PlayerPacket;
import me.egg82.antivpn.storage.StorageService;
import me.egg82.antivpn.storage.models.IPModel;
import me.egg82.antivpn.storage.models.PlayerModel;
import me.egg82.antivpn.utils.PacketUtil;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GenericMessagingHandler
implements MessagingHandler {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());
    public static final LoadingCache<UUID, Boolean> messageCache = Caffeine.newBuilder().expireAfterWrite(2L, TimeUnit.MINUTES).expireAfterAccess(30L, TimeUnit.SECONDS).build(k -> Boolean.FALSE);
    private final Object messageCacheLock = new Object();

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public void handlePacket(@NonNull UUID messageId, @NonNull String fromService, @NonNull Packet packet) {
        if (this.isDuplicate(messageId)) {
            return;
        }
        try {
            this.handleGenericPacket(packet);
        }
        finally {
            PacketUtil.repeatPacket(messageId, packet, fromService);
        }
    }

    private void handleIp(@NonNull IPPacket packet) {
        AbstractIPManager ipManager;
        if (ConfigUtil.getDebugOrFalse()) {
            this.logger.info("Handling packet for " + packet.getIp() + ".");
        }
        if ((ipManager = APIUtil.getIpManager()) == null) {
            this.logger.error("IP manager could not be fetched.");
            return;
        }
        IPModel m = new IPModel();
        m.setIp(packet.getIp());
        m.setType(packet.getType());
        m.setCascade(packet.getCascade());
        m.setConsensus(packet.getConsensus());
        ipManager.getIpCache().put(new Pair<String, AlgorithmMethod>(packet.getIp(), AlgorithmMethod.values()[packet.getType()]), (Object)m);
        CachedConfig cachedConfig = ConfigUtil.getCachedConfig();
        if (cachedConfig == null) {
            this.logger.error("Cached config could not be fetched.");
            return;
        }
        for (StorageService service : cachedConfig.getStorage()) {
            IPModel model = service.getOrCreateIpModel(packet.getIp(), packet.getType());
            model.setCascade(packet.getCascade());
            model.setConsensus(packet.getConsensus());
            service.storeModel(model);
        }
    }

    private void handleDeleteIp(@NonNull DeleteIPPacket packet) {
        AbstractIPManager ipManager;
        if (ConfigUtil.getDebugOrFalse()) {
            this.logger.info("Handling deletion packet for " + packet.getIp() + ".");
        }
        if ((ipManager = APIUtil.getIpManager()) == null) {
            this.logger.error("IP manager could not be fetched.");
            return;
        }
        ipManager.getIpCache().invalidate(new Pair<String, AlgorithmMethod>(packet.getIp(), AlgorithmMethod.CASCADE));
        ipManager.getIpCache().invalidate(new Pair<String, AlgorithmMethod>(packet.getIp(), AlgorithmMethod.CONSESNSUS));
        CachedConfig cachedConfig = ConfigUtil.getCachedConfig();
        if (cachedConfig == null) {
            this.logger.error("Cached config could not be fetched.");
            return;
        }
        for (StorageService service : cachedConfig.getStorage()) {
            IPModel model = new IPModel();
            model.setIp(packet.getIp());
            service.deleteModel(model);
        }
    }

    private void handlePlayer(@NonNull PlayerPacket packet) {
        AbstractPlayerManager playerManager;
        if (ConfigUtil.getDebugOrFalse()) {
            this.logger.info("Handling packet for " + packet.getUuid() + ".");
        }
        if ((playerManager = APIUtil.getPlayerManager()) == null) {
            this.logger.error("Player manager could not be fetched.");
            return;
        }
        PlayerModel m = new PlayerModel();
        m.setUuid(packet.getUuid());
        m.setMcleaks(packet.getValue());
        playerManager.getPlayerCache().put((Object)packet.getUuid(), (Object)m);
        CachedConfig cachedConfig = ConfigUtil.getCachedConfig();
        if (cachedConfig == null) {
            this.logger.error("Cached config could not be fetched.");
            return;
        }
        for (StorageService service : cachedConfig.getStorage()) {
            PlayerModel model = service.getOrCreatePlayerModel(packet.getUuid(), packet.getValue());
            service.storeModel(model);
        }
    }

    private void handleDeletePlayer(@NonNull DeletePlayerPacket packet) {
        AbstractPlayerManager playerManager;
        if (ConfigUtil.getDebugOrFalse()) {
            this.logger.info("Handling deletion packet for " + packet.getUuid() + ".");
        }
        if ((playerManager = APIUtil.getPlayerManager()) == null) {
            this.logger.error("Player manager could not be fetched.");
            return;
        }
        playerManager.getPlayerCache().invalidate((Object)packet.getUuid());
        CachedConfig cachedConfig = ConfigUtil.getCachedConfig();
        if (cachedConfig == null) {
            this.logger.error("Cached config could not be fetched.");
            return;
        }
        for (StorageService service : cachedConfig.getStorage()) {
            PlayerModel model = new PlayerModel();
            model.setUuid(packet.getUuid());
            service.deleteModel(model);
        }
    }

    private void handleMulti(@NonNull MultiPacket packet) {
        if (ConfigUtil.getDebugOrFalse()) {
            this.logger.info("Handling multi-packet.");
        }
        for (Packet p : packet.getPackets()) {
            this.handleGenericPacket(p);
        }
    }

    private void handleGenericPacket(@NonNull Packet packet) {
        if (packet instanceof IPPacket) {
            this.handleIp((IPPacket)packet);
        } else if (packet instanceof PlayerPacket) {
            this.handlePlayer((PlayerPacket)packet);
        } else if (packet instanceof DeleteIPPacket) {
            this.handleDeleteIp((DeleteIPPacket)packet);
        } else if (packet instanceof DeletePlayerPacket) {
            this.handleDeletePlayer((DeletePlayerPacket)packet);
        } else if (packet instanceof MultiPacket) {
            this.handleMulti((MultiPacket)packet);
        }
    }

    @Override
    public void cancel() {
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private boolean isDuplicate(@NonNull UUID messageId) {
        if (Boolean.TRUE.equals(messageCache.getIfPresent((Object)messageId))) {
            return true;
        }
        Object object = this.messageCacheLock;
        synchronized (object) {
            if (Boolean.TRUE.equals(messageCache.getIfPresent((Object)messageId))) {
                return true;
            }
            messageCache.put((Object)messageId, (Object)Boolean.TRUE);
        }
        return false;
    }
}

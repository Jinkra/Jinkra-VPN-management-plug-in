/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  io.netty.buffer.ByteBuf
 *  me.egg82.antivpn.external.com.rabbitmq.client.AMQP$BasicProperties
 *  me.egg82.antivpn.external.com.rabbitmq.client.AMQP$BasicProperties$Builder
 *  me.egg82.antivpn.external.com.rabbitmq.client.Channel
 *  me.egg82.antivpn.external.com.rabbitmq.client.ConnectionFactory
 *  me.egg82.antivpn.external.com.rabbitmq.client.Consumer
 *  me.egg82.antivpn.external.com.rabbitmq.client.DefaultConsumer
 *  me.egg82.antivpn.external.com.rabbitmq.client.Envelope
 *  me.egg82.antivpn.external.com.rabbitmq.client.RecoverableChannel
 *  me.egg82.antivpn.external.com.rabbitmq.client.RecoverableConnection
 */
package me.egg82.antivpn.messaging;

import io.netty.buffer.ByteBuf;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.UUID;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import me.egg82.antivpn.config.ConfigUtil;
import me.egg82.antivpn.external.com.rabbitmq.client.AMQP;
import me.egg82.antivpn.external.com.rabbitmq.client.Channel;
import me.egg82.antivpn.external.com.rabbitmq.client.ConnectionFactory;
import me.egg82.antivpn.external.com.rabbitmq.client.Consumer;
import me.egg82.antivpn.external.com.rabbitmq.client.DefaultConsumer;
import me.egg82.antivpn.external.com.rabbitmq.client.Envelope;
import me.egg82.antivpn.external.com.rabbitmq.client.RecoverableChannel;
import me.egg82.antivpn.external.com.rabbitmq.client.RecoverableConnection;
import me.egg82.antivpn.messaging.AbstractMessagingService;
import me.egg82.antivpn.messaging.MessagingHandler;
import me.egg82.antivpn.messaging.packets.Packet;
import me.egg82.antivpn.utils.PacketUtil;
import me.egg82.antivpn.utils.ValidationUtil;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.checkerframework.checker.nullness.qual.Nullable;

public class RabbitMQMessagingService
extends AbstractMessagingService {
    private ConnectionFactory factory;
    private RecoverableConnection connection;
    private volatile boolean closed = false;
    private final ReadWriteLock queueLock = new ReentrantReadWriteLock();
    private static final String EXCHANGE_NAME = "avpn-data";

    private RabbitMQMessagingService(@NonNull String name) {
        super(name);
    }

    @Override
    public void close() {
        this.queueLock.writeLock().lock();
        try {
            this.closed = true;
            try {
                this.connection.close(8000);
            }
            catch (IOException iOException) {
                // empty catch block
            }
        }
        finally {
            this.queueLock.writeLock().unlock();
        }
    }

    @Override
    public boolean isClosed() {
        return this.closed || !this.connection.isOpen();
    }

    public static Builder builder(@NonNull String name, @NonNull UUID serverId, @NonNull MessagingHandler handler) {
        return new Builder(name, serverId, handler);
    }

    private void bind() throws IOException {
        RecoverableChannel channel = this.getChannel();
        channel.exchangeDeclare(EXCHANGE_NAME, ExchangeType.FANOUT.getType(), true);
        String queue = channel.queueDeclare().getQueue();
        channel.queueBind(queue, EXCHANGE_NAME, "");
        DefaultConsumer consumer = new DefaultConsumer((Channel)channel){

            /*
             * WARNING - Removed try catching itself - possible behaviour change.
             */
            public void handleDelivery(String tag, Envelope envelope, AMQP.BasicProperties properties, byte[] body) throws IOException {
                if (ConfigUtil.getDebugOrFalse()) {
                    RabbitMQMessagingService.this.logger.info("Got message from exchange: " + envelope.getExchange());
                }
                if (!RabbitMQMessagingService.this.validateProperties(properties)) {
                    return;
                }
                ByteBuf b = AbstractMessagingService.alloc.buffer(body.length, body.length);
                ByteBuf data = null;
                try {
                    b.writeBytes(body);
                    data = RabbitMQMessagingService.this.decompressData(b);
                    byte packetId = data.readByte();
                    Class packetClass = (Class)PacketUtil.getPacketCache().get(packetId);
                    if (packetClass == null) {
                        RabbitMQMessagingService.this.logger.warn("Got packet ID that doesn't exist: " + packetId);
                        return;
                    }
                    try {
                        RabbitMQMessagingService.this.handler.handlePacket(UUID.fromString(properties.getMessageId()), RabbitMQMessagingService.this.getName(), (Packet)packetClass.getConstructor(ByteBuf.class).newInstance(data));
                    }
                    catch (ExceptionInInitializerError | IllegalAccessException | InstantiationException | NoSuchMethodException | SecurityException | InvocationTargetException ex) {
                        RabbitMQMessagingService.this.logger.error("Could not instantiate packet.", ex);
                    }
                }
                finally {
                    b.release();
                    if (data != null) {
                        data.release();
                    }
                }
            }
        };
        channel.addShutdownListener(cause -> {
            try {
                this.bind();
            }
            catch (IOException ex) {
                this.logger.error("Could not re-bind channel.", ex);
            }
        });
        channel.basicConsume(queue, true, (Consumer)consumer);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public void sendPacket(@NonNull UUID messageId, @NonNull Packet packet) throws IOException, TimeoutException {
        this.queueLock.readLock().lock();
        try (RecoverableChannel channel = this.getChannel();){
            ByteBuf buffer = alloc.buffer(this.getInitialCapacity());
            try {
                buffer.writeByte((int)packet.getPacketId());
                packet.write(buffer);
                this.addCapacity(buffer.writerIndex());
                AMQP.BasicProperties properties = this.getProperties(DeliveryMode.PERSISTENT, messageId);
                channel.exchangeDeclare(EXCHANGE_NAME, ExchangeType.FANOUT.getType(), true);
                channel.basicPublish(EXCHANGE_NAME, "", properties, this.compressData(buffer));
            }
            finally {
                buffer.release();
            }
        }
        catch (IOException | TimeoutException ex) {
            throw ex;
        }
        finally {
            this.queueLock.readLock().unlock();
        }
    }

    private AMQP.BasicProperties getProperties(@NonNull DeliveryMode deliveryMode, @NonNull UUID messageId) {
        HashMap<String, byte[]> headers = new HashMap<String, byte[]>();
        headers.put("sender", this.serverIdBytes);
        AMQP.BasicProperties.Builder retVal = new AMQP.BasicProperties.Builder();
        retVal.contentType("application/octet-stream");
        retVal.messageId(messageId.toString());
        retVal.deliveryMode(Integer.valueOf(deliveryMode.getMode()));
        retVal.headers(headers);
        return retVal.build();
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private boolean validateProperties(AMQP.BasicProperties properties) {
        UUID sender;
        byte[] data = (byte[])properties.getHeaders().get("sender");
        ByteBuf buffer = alloc.buffer(16, 16);
        try {
            buffer.writeBytes(data);
            sender = new UUID(buffer.readLong(), buffer.readLong());
        }
        finally {
            buffer.release();
        }
        if (this.serverId.equals(sender)) {
            return false;
        }
        if (!ValidationUtil.isValidUuid(properties.getMessageId())) {
            this.logger.warn("Non-valid message ID received: \"" + properties.getMessageId() + "\".");
            return false;
        }
        return true;
    }

    private @NonNull RecoverableConnection getConnection() throws IOException, TimeoutException {
        return (RecoverableConnection)this.factory.newConnection();
    }

    private @Nullable RecoverableChannel getChannel() throws IOException {
        return (RecoverableChannel)this.connection.createChannel();
    }

    private static enum ExchangeType {
        DIRECT("direct"),
        FANOUT("fanout"),
        TOPIC("topic"),
        HEADERS("match");

        private final String type;

        private ExchangeType(String type) {
            this.type = type;
        }

        public @NonNull String getType() {
            return this.type;
        }
    }

    private static enum DeliveryMode {
        TRANSIENT(1),
        PERSISTENT(2);

        private final int mode;

        private DeliveryMode(int mode) {
            this.mode = mode;
        }

        public int getMode() {
            return this.mode;
        }
    }

    public static class Builder {
        private final RabbitMQMessagingService service;
        private final ConnectionFactory config = new ConnectionFactory();

        /*
         * WARNING - Removed try catching itself - possible behaviour change.
         */
        public Builder(@NonNull String name, @NonNull UUID serverId, @NonNull MessagingHandler handler) {
            this.service = new RabbitMQMessagingService(name);
            this.service.serverId = serverId;
            this.service.serverIdString = serverId.toString();
            ByteBuf buffer = AbstractMessagingService.alloc.buffer(16, 16);
            try {
                buffer.writeLong(serverId.getMostSignificantBits());
                buffer.writeLong(serverId.getLeastSignificantBits());
                if (buffer.isDirect()) {
                    this.service.serverIdBytes = new byte[16];
                    buffer.readBytes(this.service.serverIdBytes);
                } else {
                    this.service.serverIdBytes = buffer.array();
                }
            }
            finally {
                buffer.release();
            }
            this.service.handler = handler;
            this.config.setAutomaticRecoveryEnabled(true);
            this.config.setTopologyRecoveryEnabled(true);
        }

        public Builder url(@NonNull String address, int port, @NonNull String vhost) {
            this.config.setHost(address);
            this.config.setPort(port);
            this.config.setVirtualHost(vhost);
            return this;
        }

        public Builder credentials(@NonNull String user, @NonNull String pass) {
            this.config.setUsername(user);
            this.config.setPassword(pass);
            return this;
        }

        public Builder timeout(int timeout) {
            this.config.setConnectionTimeout(timeout);
            return this;
        }

        public @NonNull RabbitMQMessagingService build() throws IOException, TimeoutException {
            this.service.factory = this.config;
            this.service.connection = this.service.getConnection();
            this.service.bind();
            return this.service;
        }
    }
}

/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  io.netty.buffer.ByteBuf
 *  me.egg82.antivpn.external.com.rabbitmq.client.ConnectionFactory
 */
package me.egg82.antivpn.messaging;

import io.netty.buffer.ByteBuf;
import java.io.IOException;
import java.util.UUID;
import java.util.concurrent.TimeoutException;
import me.egg82.antivpn.external.com.rabbitmq.client.ConnectionFactory;
import me.egg82.antivpn.messaging.AbstractMessagingService;
import me.egg82.antivpn.messaging.MessagingHandler;
import me.egg82.antivpn.messaging.RabbitMQMessagingService;
import org.checkerframework.checker.nullness.qual.NonNull;

public static class RabbitMQMessagingService.Builder {
    private final RabbitMQMessagingService service;
    private final ConnectionFactory config = new ConnectionFactory();

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public RabbitMQMessagingService.Builder(@NonNull String name, @NonNull UUID serverId, @NonNull MessagingHandler handler) {
        this.service = new RabbitMQMessagingService(name, null);
        this.service.serverId = serverId;
        this.service.serverIdString = serverId.toString();
        ByteBuf buffer = AbstractMessagingService.alloc.buffer(16, 16);
        try {
            buffer.writeLong(serverId.getMostSignificantBits());
            buffer.writeLong(serverId.getLeastSignificantBits());
            if (buffer.isDirect()) {
                this.service.serverIdBytes = new byte[16];
                buffer.readBytes(this.service.serverIdBytes);
            } else {
                this.service.serverIdBytes = buffer.array();
            }
        }
        finally {
            buffer.release();
        }
        this.service.handler = handler;
        this.config.setAutomaticRecoveryEnabled(true);
        this.config.setTopologyRecoveryEnabled(true);
    }

    public RabbitMQMessagingService.Builder url(@NonNull String address, int port, @NonNull String vhost) {
        this.config.setHost(address);
        this.config.setPort(port);
        this.config.setVirtualHost(vhost);
        return this;
    }

    public RabbitMQMessagingService.Builder credentials(@NonNull String user, @NonNull String pass) {
        this.config.setUsername(user);
        this.config.setPassword(pass);
        return this;
    }

    public RabbitMQMessagingService.Builder timeout(int timeout) {
        this.config.setConnectionTimeout(timeout);
        return this;
    }

    public @NonNull RabbitMQMessagingService build() throws IOException, TimeoutException {
        this.service.factory = this.config;
        this.service.connection = this.service.getConnection();
        this.service.bind();
        return this.service;
    }
}

/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.google.common.io.Files
 */
package me.egg82.antivpn.lang;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.util.Locale;
import java.util.Optional;
import me.egg82.antivpn.external.org.spongepowered.configurate.CommentedConfigurationNode;
import me.egg82.antivpn.external.org.spongepowered.configurate.yaml.NodeStyle;
import me.egg82.antivpn.external.org.spongepowered.configurate.yaml.YamlConfigurationLoader;
import org.checkerframework.checker.nullness.qual.NonNull;

public class LanguageFileUtil {
    private LanguageFileUtil() {
    }

    public static @NonNull Optional<File> getLanguage(@NonNull File dataDirectory, @NonNull Locale locale) throws IOException {
        return LanguageFileUtil.getLanguage(dataDirectory, locale, false);
    }

    public static @NonNull Optional<File> getLanguage(@NonNull File dataDirectory, @NonNull Locale locale, boolean ignoreCountry) throws IOException {
        File fileOnDisk;
        block70: {
            Throwable throwable;
            InputStream inStream;
            String resourcePath;
            block69: {
                resourcePath = ignoreCountry || locale.getCountry() == null || locale.getCountry().isEmpty() ? "lang_" + locale.getLanguage() + ".yml" : "lang_" + locale.getLanguage() + "_" + locale.getCountry() + ".yml";
                File langDir = new File(dataDirectory, "lang");
                fileOnDisk = new File(langDir, resourcePath);
                if (langDir.exists() && !langDir.isDirectory()) {
                    Files.delete(langDir.toPath());
                }
                if (!langDir.exists() && !langDir.mkdirs()) {
                    throw new IOException("Could not create parent directory structure.");
                }
                if (fileOnDisk.exists() && fileOnDisk.isDirectory()) {
                    Files.delete(fileOnDisk.toPath());
                }
                if (fileOnDisk.exists()) {
                    inStream = LanguageFileUtil.class.getResourceAsStream("/lang/" + resourcePath);
                    throwable = null;
                    try {
                        if (inStream == null) break block69;
                        YamlConfigurationLoader fileLoader = ((YamlConfigurationLoader.Builder)YamlConfigurationLoader.builder().nodeStyle(NodeStyle.BLOCK).indent(2).file(fileOnDisk)).build();
                        CommentedConfigurationNode fileRoot = (CommentedConfigurationNode)fileLoader.load();
                        double fileVersion = ((CommentedConfigurationNode)fileRoot.node(new Object[]{"acf-minecraft", "version"})).getDouble(1.0);
                        try (InputStreamReader reader = new InputStreamReader(inStream);
                             BufferedReader in = new BufferedReader(reader);){
                            YamlConfigurationLoader streamLoader = ((YamlConfigurationLoader.Builder)YamlConfigurationLoader.builder().nodeStyle(NodeStyle.BLOCK).indent(2).source(() -> in)).build();
                            CommentedConfigurationNode streamRoot = (CommentedConfigurationNode)streamLoader.load();
                            double streamVersion = ((CommentedConfigurationNode)streamRoot.node(new Object[]{"acf-minecraft", "version"})).getDouble(1.0);
                            if (streamVersion > fileVersion) {
                                File backupFile = new File(fileOnDisk.getParent(), fileOnDisk.getName() + ".bak");
                                if (backupFile.exists()) {
                                    Files.delete(backupFile.toPath());
                                }
                                com.google.common.io.Files.copy((File)fileOnDisk, (File)backupFile);
                                Files.delete(fileOnDisk.toPath());
                            }
                        }
                    }
                    catch (Throwable fileLoader) {
                        throwable = fileLoader;
                        throw fileLoader;
                    }
                    finally {
                        if (inStream != null) {
                            if (throwable != null) {
                                try {
                                    inStream.close();
                                }
                                catch (Throwable fileLoader) {
                                    throwable.addSuppressed(fileLoader);
                                }
                            } else {
                                inStream.close();
                            }
                        }
                    }
                }
            }
            if (!fileOnDisk.exists()) {
                inStream = LanguageFileUtil.class.getResourceAsStream("/lang/" + resourcePath);
                throwable = null;
                try {
                    if (inStream == null) break block70;
                    try (FileOutputStream outStream = new FileOutputStream(fileOnDisk);){
                        int read;
                        byte[] buffer = new byte[4096];
                        while ((read = inStream.read(buffer, 0, buffer.length)) > 0) {
                            outStream.write(buffer, 0, read);
                        }
                    }
                }
                catch (Throwable throwable2) {
                    throwable = throwable2;
                    throw throwable2;
                }
                finally {
                    if (inStream != null) {
                        if (throwable != null) {
                            try {
                                inStream.close();
                            }
                            catch (Throwable throwable3) {
                                throwable.addSuppressed(throwable3);
                            }
                        } else {
                            inStream.close();
                        }
                    }
                }
            }
        }
        if (fileOnDisk.exists()) {
            return Optional.of(fileOnDisk);
        }
        return ignoreCountry ? Optional.empty() : LanguageFileUtil.getLanguage(dataDirectory, locale, true);
    }
}

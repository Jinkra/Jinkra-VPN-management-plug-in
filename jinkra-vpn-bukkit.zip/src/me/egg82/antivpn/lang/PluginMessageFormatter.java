/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.bukkit.ChatColor
 */
package me.egg82.antivpn.lang;

import me.egg82.antivpn.external.co.aikar.commands.BukkitMessageFormatter;
import me.egg82.antivpn.external.co.aikar.commands.CommandManager;
import me.egg82.antivpn.external.co.aikar.locales.MessageKeyProvider;
import org.bukkit.ChatColor;
import org.checkerframework.checker.nullness.qual.NonNull;

public class PluginMessageFormatter
extends BukkitMessageFormatter {
    private final String header;

    public PluginMessageFormatter(@NonNull CommandManager manager, @NonNull MessageKeyProvider header) {
        this(manager.getLocales().getMessage(null, header));
    }

    public PluginMessageFormatter(@NonNull String header) {
        super(new ChatColor[0]);
        this.header = header;
    }

    @Override
    public @NonNull String format(@NonNull String message) {
        message = this.header + message;
        return super.format(message);
    }
}

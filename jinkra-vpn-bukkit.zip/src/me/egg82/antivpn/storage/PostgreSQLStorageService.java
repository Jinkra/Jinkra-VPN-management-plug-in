/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.storage;

import java.io.IOException;
import java.io.StringReader;
import java.util.Properties;
import me.egg82.antivpn.external.com.zaxxer.hikari.HikariConfig;
import me.egg82.antivpn.external.io.ebean.config.dbplatform.postgres.Postgres9Platform;
import me.egg82.antivpn.storage.AbstractJDBCStorageService;
import org.checkerframework.checker.nullness.qual.NonNull;

public class PostgreSQLStorageService
extends AbstractJDBCStorageService {
    private PostgreSQLStorageService(@NonNull String name) {
        super(name);
    }

    public static Builder builder(@NonNull String name) {
        return new Builder(name);
    }

    public static class Builder {
        private final PostgreSQLStorageService service;
        private final HikariConfig config = new HikariConfig();

        private Builder(@NonNull String name) {
            this.service = new PostgreSQLStorageService(name);
            this.config.setPoolName("AntiVPN-PostgreSQL");
            this.config.setDriverClassName("org.postgresql.Driver");
            this.config.setConnectionTestQuery("SELECT 1;");
            this.config.addDataSourceProperty("useLegacyDatetimeCode", "false");
            this.config.addDataSourceProperty("serverTimezone", "UTC");
        }

        public Builder url(@NonNull String address, int port, @NonNull String database) {
            this.config.setJdbcUrl("jdbc:postgresql://" + address + ":" + port + "/" + database);
            return this;
        }

        public Builder credentials(@NonNull String user, @NonNull String pass) {
            this.config.setUsername(user);
            this.config.setPassword(pass);
            return this;
        }

        public Builder options(@NonNull String options) throws IOException {
            options = !options.isEmpty() && options.charAt(0) == '?' ? options.substring(1) : options;
            Properties p = new Properties();
            p.load(new StringReader(options.replace("&", "\n")));
            this.config.setDataSourceProperties(p);
            return this;
        }

        public Builder poolSize(int min, int max) {
            this.config.setMaximumPoolSize(max);
            this.config.setMinimumIdle(min);
            return this;
        }

        public Builder life(long lifetime, long timeout) {
            this.config.setMaxLifetime(lifetime);
            this.config.setConnectionTimeout(timeout);
            return this;
        }

        public @NonNull PostgreSQLStorageService build() {
            this.service.createSource(this.config, new Postgres9Platform(), false, "postgresql");
            return this.service;
        }
    }
}

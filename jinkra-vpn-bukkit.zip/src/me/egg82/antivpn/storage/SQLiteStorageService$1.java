/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.storage;

static class SQLiteStorageService.1 {
}

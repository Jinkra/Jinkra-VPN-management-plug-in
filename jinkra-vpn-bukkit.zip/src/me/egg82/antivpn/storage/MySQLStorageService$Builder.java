/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.storage;

import java.io.IOException;
import java.io.StringReader;
import java.util.Properties;
import me.egg82.antivpn.external.com.zaxxer.hikari.HikariConfig;
import me.egg82.antivpn.external.io.ebean.config.dbplatform.mysql.MySqlPlatform;
import me.egg82.antivpn.storage.MySQLStorageService;
import org.checkerframework.checker.nullness.qual.NonNull;

public static class MySQLStorageService.Builder {
    private final MySQLStorageService service;
    private final HikariConfig config = new HikariConfig();

    private MySQLStorageService.Builder(@NonNull String name) {
        this.service = new MySQLStorageService(name, null);
        this.config.setPoolName("AntiVPN-MySQL");
        this.config.setDriverClassName("com.mysql.cj.jdbc.Driver");
        this.config.setConnectionTestQuery("SELECT 1;");
        this.config.addDataSourceProperty("useLegacyDatetimeCode", "false");
        this.config.addDataSourceProperty("serverTimezone", "UTC");
        this.config.addDataSourceProperty("cacheServerConfiguration", "true");
        this.config.addDataSourceProperty("useLocalSessionState", "true");
        this.config.addDataSourceProperty("useLocalTransactionState", "true");
        this.config.addDataSourceProperty("rewriteBatchedStatements", "true");
        this.config.addDataSourceProperty("useServerPrepStmts", "true");
        this.config.addDataSourceProperty("cachePrepStmts", "true");
        this.config.addDataSourceProperty("maintainTimeStats", "false");
        this.config.addDataSourceProperty("useUnbufferedIO", "false");
        this.config.addDataSourceProperty("useReadAheadInput", "false");
        this.config.addDataSourceProperty("prepStmtCacheSize", "250");
        this.config.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");
        this.config.addDataSourceProperty("cacheResultSetMetadata", "true");
        this.config.addDataSourceProperty("elideSetAutoCommits", "true");
    }

    public MySQLStorageService.Builder url(@NonNull String address, int port, @NonNull String database) {
        this.config.setJdbcUrl("jdbc:mysql://" + address + ":" + port + "/" + database);
        return this;
    }

    public MySQLStorageService.Builder credentials(@NonNull String user, @NonNull String pass) {
        this.config.setUsername(user);
        this.config.setPassword(pass);
        return this;
    }

    public MySQLStorageService.Builder options(@NonNull String options) throws IOException {
        options = !options.isEmpty() && options.charAt(0) == '?' ? options.substring(1) : options;
        Properties p = new Properties();
        p.load(new StringReader(options.replace("&", "\n")));
        this.config.setDataSourceProperties(p);
        return this;
    }

    public MySQLStorageService.Builder poolSize(int min, int max) {
        this.config.setMaximumPoolSize(max);
        this.config.setMinimumIdle(min);
        return this;
    }

    public MySQLStorageService.Builder life(long lifetime, long timeout) {
        this.config.setMaxLifetime(lifetime);
        this.config.setConnectionTimeout(timeout);
        return this;
    }

    public @NonNull MySQLStorageService build() {
        this.service.createSource(this.config, new MySqlPlatform(), true, "mysql");
        return this.service;
    }
}

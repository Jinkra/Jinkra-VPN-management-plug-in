/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.storage;

import java.util.Collection;
import java.util.Set;
import java.util.UUID;
import me.egg82.antivpn.storage.models.BaseModel;
import me.egg82.antivpn.storage.models.DataModel;
import me.egg82.antivpn.storage.models.IPModel;
import me.egg82.antivpn.storage.models.PlayerModel;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.checkerframework.checker.nullness.qual.Nullable;

public interface StorageService {
    public @NonNull String getName();

    public void close();

    public boolean isClosed();

    public void storeModel(@NonNull BaseModel var1);

    public void storeModels(@NonNull Collection<? extends BaseModel> var1);

    public void deleteModel(@NonNull BaseModel var1);

    public @NonNull IPModel getOrCreateIpModel(@NonNull String var1, int var2);

    public @Nullable IPModel getIpModel(@NonNull String var1, long var2);

    public @Nullable IPModel getIpModel(long var1, long var3);

    public @NonNull Set<IPModel> getAllIps(long var1);

    public @NonNull Set<IPModel> getAllIps(int var1, int var2);

    public @NonNull PlayerModel getOrCreatePlayerModel(@NonNull UUID var1, boolean var2);

    public @Nullable PlayerModel getPlayerModel(@NonNull UUID var1, long var2);

    public @Nullable PlayerModel getPlayerModel(long var1, long var3);

    public @NonNull Set<PlayerModel> getAllPlayers(long var1);

    public @NonNull Set<PlayerModel> getAllPlayers(int var1, int var2);

    public @NonNull DataModel getOrCreateDataModel(@NonNull String var1, String var2);

    public @Nullable DataModel getDataModel(@NonNull String var1);

    public @Nullable DataModel getDataModel(long var1);
}

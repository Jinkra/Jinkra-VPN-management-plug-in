/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.storage;

import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import me.egg82.antivpn.storage.StorageService;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class AbstractStorageService
implements StorageService {
    protected final Logger logger = LoggerFactory.getLogger(this.getClass());
    protected final String name;
    protected volatile boolean closed = false;
    protected final ReadWriteLock queueLock = new ReentrantReadWriteLock();

    protected AbstractStorageService(@NonNull String name) {
        this.name = name;
    }

    @Override
    public @NonNull String getName() {
        return this.name;
    }

    @Override
    public boolean isClosed() {
        return this.closed;
    }
}

/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.storage;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.util.Properties;
import me.egg82.antivpn.external.com.zaxxer.hikari.HikariConfig;
import me.egg82.antivpn.external.io.ebean.config.dbplatform.h2.H2Platform;
import me.egg82.antivpn.storage.AbstractJDBCStorageService;
import org.checkerframework.checker.nullness.qual.NonNull;

public class H2StorageService
extends AbstractJDBCStorageService {
    private H2StorageService(@NonNull String name) {
        super(name);
    }

    public static Builder builder(@NonNull String name) {
        return new Builder(name);
    }

    public static class Builder {
        private final H2StorageService service;
        private final HikariConfig config = new HikariConfig();

        private Builder(@NonNull String name) {
            this.service = new H2StorageService(name);
            this.config.setPoolName("AntiVPN-H2");
            this.config.setDriverClassName("org.h2.Driver");
            this.config.setConnectionTestQuery("SELECT 1;");
            this.config.addDataSourceProperty("useLegacyDatetimeCode", "false");
            this.config.addDataSourceProperty("serverTimezone", "UTC");
        }

        public Builder file(@NonNull File file) {
            this.config.setJdbcUrl("jdbc:h2:" + file.getAbsolutePath());
            return this;
        }

        public Builder options(@NonNull String options) throws IOException {
            options = !options.isEmpty() && options.charAt(0) == '?' ? options.substring(1) : options;
            Properties p = new Properties();
            p.load(new StringReader(options.replace("&", "\n")));
            this.config.setDataSourceProperties(p);
            return this;
        }

        public Builder poolSize(int min, int max) {
            this.config.setMaximumPoolSize(max);
            this.config.setMinimumIdle(min);
            return this;
        }

        public Builder life(long lifetime, long timeout) {
            this.config.setMaxLifetime(lifetime);
            this.config.setConnectionTimeout(timeout);
            return this;
        }

        public @NonNull H2StorageService build() {
            this.service.createSource(this.config, new H2Platform(), false, "h2");
            return this.service;
        }
    }
}

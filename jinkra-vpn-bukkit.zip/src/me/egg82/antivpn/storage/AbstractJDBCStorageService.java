/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.storage;

import java.io.File;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import javax.persistence.PersistenceException;
import me.egg82.antivpn.external.com.zaxxer.hikari.HikariConfig;
import me.egg82.antivpn.external.com.zaxxer.hikari.HikariDataSource;
import me.egg82.antivpn.external.io.ebean.Database;
import me.egg82.antivpn.external.io.ebean.DatabaseFactory;
import me.egg82.antivpn.external.io.ebean.ProfileLocation;
import me.egg82.antivpn.external.io.ebean.Transaction;
import me.egg82.antivpn.external.io.ebean.bean.EnhancedTransactional;
import me.egg82.antivpn.external.io.ebean.config.DatabaseConfig;
import me.egg82.antivpn.external.io.ebean.config.dbplatform.DatabasePlatform;
import me.egg82.antivpn.storage.AbstractStorageService;
import me.egg82.antivpn.storage.models.BaseModel;
import me.egg82.antivpn.storage.models.DataModel;
import me.egg82.antivpn.storage.models.IPModel;
import me.egg82.antivpn.storage.models.PlayerModel;
import me.egg82.antivpn.storage.models.query.QDataModel;
import me.egg82.antivpn.storage.models.query.QIPModel;
import me.egg82.antivpn.storage.models.query.QPlayerModel;
import me.egg82.antivpn.utils.VersionUtil;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.checkerframework.checker.nullness.qual.Nullable;
import org.reflections.Reflections;
import org.reflections.scanners.ResourcesScanner;

public abstract class AbstractJDBCStorageService
extends AbstractStorageService
implements EnhancedTransactional {
    protected Database connection;
    protected HikariDataSource source;
    private static /* synthetic */ ProfileLocation _$ebpq0;
    private static /* synthetic */ ProfileLocation _$ebpq1;
    private static /* synthetic */ ProfileLocation _$ebpq2;
    private static /* synthetic */ ProfileLocation _$ebpq3;
    private static /* synthetic */ ProfileLocation _$ebpq4;
    private static /* synthetic */ ProfileLocation _$ebpq5;
    private static /* synthetic */ ProfileLocation _$ebpq6;
    private static /* synthetic */ ProfileLocation _$ebpq7;
    private static /* synthetic */ ProfileLocation _$ebpq8;
    private static /* synthetic */ ProfileLocation _$ebpq9;
    private static /* synthetic */ ProfileLocation _$ebpq10;
    private static /* synthetic */ ProfileLocation _$ebpq11;
    private static /* synthetic */ ProfileLocation _$ebpq12;
    private static /* synthetic */ ProfileLocation _$ebpq13;
    private static /* synthetic */ ProfileLocation _$ebpq14;
    private static /* synthetic */ ProfileLocation _$ebpq15;
    private static /* synthetic */ ProfileLocation _$ebpq16;
    private static /* synthetic */ ProfileLocation _$ebpq17;
    private static /* synthetic */ ProfileLocation _$ebpq18;

    protected AbstractJDBCStorageService(@NonNull String name) {
        super(name);
    }

    @Override
    public void close() {
        this.queueLock.writeLock().lock();
        try {
            this.closed = true;
            this.connection.shutdown(false, false);
            this.source.close();
        }
        finally {
            this.queueLock.writeLock().unlock();
        }
    }

    @Override
    public void storeModel(@NonNull BaseModel model) {
        this.queueLock.readLock().lock();
        try {
            this.createOrUpdate(model, false);
        }
        finally {
            this.queueLock.readLock().unlock();
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public void storeModels(@NonNull Collection<? extends BaseModel> models) {
        this.queueLock.readLock().lock();
        try (Transaction tx = this.connection.beginTransaction();){
            for (BaseModel baseModel : models) {
                this.createOrUpdate(baseModel, true);
            }
            tx.commit();
        }
        finally {
            this.queueLock.readLock().unlock();
        }
    }

    @Override
    public void deleteModel(@NonNull BaseModel model) {
        BaseModel newModel = this.duplicateModel(model, true);
        if (newModel == null) {
            return;
        }
        this.queueLock.readLock().lock();
        try {
            this.connection.delete(newModel);
        }
        finally {
            this.queueLock.readLock().unlock();
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public @NonNull IPModel getOrCreateIpModel(@NonNull String ip, int type) {
        this.queueLock.readLock().lock();
        try {
            IPModel model = (IPModel)((QIPModel)((QIPModel)new QIPModel(this.connection).setProfileLocation(_$ebpq0))._ip().equalTo(ip)).findOne();
            if (model == null) {
                model = new IPModel();
                model.setIp(ip);
                model.setType(type);
                this.connection.save(model);
                model = (IPModel)((QIPModel)((QIPModel)new QIPModel(this.connection).setProfileLocation(_$ebpq1))._ip().equalTo(ip)).findOne();
                if (model == null) {
                    throw new PersistenceException("findOne() returned null after saving.");
                }
            }
            if (model.getType() != type) {
                model.setType(type);
                model.setModified(null);
                this.connection.save(model);
            }
            IPModel iPModel = model;
            return iPModel;
        }
        finally {
            this.queueLock.readLock().unlock();
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public @Nullable IPModel getIpModel(@NonNull String ip, long cacheTimeMillis) {
        this.queueLock.readLock().lock();
        try {
            IPModel iPModel = (IPModel)((QIPModel)((QIPModel)((QIPModel)new QIPModel(this.connection).setProfileLocation(_$ebpq2))._ip().equalTo(ip))._modified().after(Instant.now().minusMillis(cacheTimeMillis))).findOne();
            return iPModel;
        }
        finally {
            this.queueLock.readLock().unlock();
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public @Nullable IPModel getIpModel(long ipId, long cacheTimeMillis) {
        this.queueLock.readLock().lock();
        try {
            IPModel iPModel = (IPModel)((QIPModel)((QIPModel)((QIPModel)new QIPModel(this.connection).setProfileLocation(_$ebpq3))._id().equalTo(ipId))._modified().after(Instant.now().minusMillis(cacheTimeMillis))).findOne();
            return iPModel;
        }
        finally {
            this.queueLock.readLock().unlock();
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public @NonNull Set<IPModel> getAllIps(long cacheTimeMillis) {
        this.queueLock.readLock().lock();
        try {
            Set<IPModel> set = ((QIPModel)((QIPModel)new QIPModel(this.connection).setProfileLocation(_$ebpq4))._modified().after(Instant.now().minusMillis(cacheTimeMillis))).findSet();
            return set;
        }
        finally {
            this.queueLock.readLock().unlock();
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public @NonNull Set<IPModel> getAllIps(int start, int end) {
        this.queueLock.readLock().lock();
        try {
            Set<IPModel> set = ((QIPModel)((QIPModel)new QIPModel(this.connection).setProfileLocation(_$ebpq5))._id().between(start - 1, end + 1)).findSet();
            return set;
        }
        finally {
            this.queueLock.readLock().unlock();
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public @NonNull PlayerModel getOrCreatePlayerModel(@NonNull UUID player, boolean isMcLeaks) {
        this.queueLock.readLock().lock();
        try {
            PlayerModel model = (PlayerModel)((QPlayerModel)((QPlayerModel)new QPlayerModel(this.connection).setProfileLocation(_$ebpq6))._uuid().equalTo(player)).findOne();
            if (model == null) {
                model = new PlayerModel();
                model.setUuid(player);
                model.setMcleaks(isMcLeaks);
                this.connection.save(model);
                model = (PlayerModel)((QPlayerModel)((QPlayerModel)new QPlayerModel(this.connection).setProfileLocation(_$ebpq7))._uuid().equalTo(player)).findOne();
                if (model == null) {
                    throw new PersistenceException("findOne() returned null after saving.");
                }
            }
            if (model.isMcleaks() != isMcLeaks) {
                model.setMcleaks(isMcLeaks);
                model.setModified(null);
                this.connection.save(model);
            }
            PlayerModel playerModel = model;
            return playerModel;
        }
        finally {
            this.queueLock.readLock().unlock();
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public @Nullable PlayerModel getPlayerModel(@NonNull UUID player, long cacheTimeMillis) {
        this.queueLock.readLock().lock();
        try {
            PlayerModel playerModel = (PlayerModel)((QPlayerModel)((QPlayerModel)((QPlayerModel)new QPlayerModel(this.connection).setProfileLocation(_$ebpq8))._uuid().equalTo(player))._modified().after(Instant.now().minusMillis(cacheTimeMillis))).findOne();
            return playerModel;
        }
        finally {
            this.queueLock.readLock().unlock();
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public @Nullable PlayerModel getPlayerModel(long playerId, long cacheTimeMillis) {
        this.queueLock.readLock().lock();
        try {
            PlayerModel playerModel = (PlayerModel)((QPlayerModel)((QPlayerModel)((QPlayerModel)new QPlayerModel(this.connection).setProfileLocation(_$ebpq9))._id().equalTo(playerId))._modified().after(Instant.now().minusMillis(cacheTimeMillis))).findOne();
            return playerModel;
        }
        finally {
            this.queueLock.readLock().unlock();
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public @NonNull Set<PlayerModel> getAllPlayers(long cacheTimeMillis) {
        this.queueLock.readLock().lock();
        try {
            Set<PlayerModel> set = ((QPlayerModel)((QPlayerModel)new QPlayerModel(this.connection).setProfileLocation(_$ebpq10))._modified().after(Instant.now().minusMillis(cacheTimeMillis))).findSet();
            return set;
        }
        finally {
            this.queueLock.readLock().unlock();
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public @NonNull Set<PlayerModel> getAllPlayers(int start, int end) {
        this.queueLock.readLock().lock();
        try {
            Set<PlayerModel> set = ((QPlayerModel)((QPlayerModel)new QPlayerModel(this.connection).setProfileLocation(_$ebpq11))._id().between(start - 1, end + 1)).findSet();
            return set;
        }
        finally {
            this.queueLock.readLock().unlock();
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public @NonNull DataModel getOrCreateDataModel(@NonNull String key, String value) {
        this.queueLock.readLock().lock();
        try {
            DataModel model = (DataModel)((QDataModel)((QDataModel)new QDataModel(this.connection).setProfileLocation(_$ebpq12))._key().equalTo(key)).findOne();
            if (model == null) {
                model = new DataModel();
                model.setKey(key);
                model.setValue(value);
                this.connection.save(model);
                model = (DataModel)((QDataModel)((QDataModel)new QDataModel(this.connection).setProfileLocation(_$ebpq13))._key().equalTo(key)).findOne();
                if (model == null) {
                    throw new PersistenceException("findOne() returned null after saving.");
                }
            }
            if (!Objects.equals(model.getValue(), value)) {
                model.setValue(value);
                model.setModified(null);
                this.connection.save(model);
            }
            DataModel dataModel = model;
            return dataModel;
        }
        finally {
            this.queueLock.readLock().unlock();
        }
    }

    @Override
    public @Nullable DataModel getDataModel(@NonNull String key) {
        this.queueLock.readLock().lock();
        try {
            DataModel dataModel = (DataModel)((QDataModel)((QDataModel)new QDataModel(this.connection).setProfileLocation(_$ebpq14))._key().equalTo(key)).findOne();
            return dataModel;
        }
        finally {
            this.queueLock.readLock().unlock();
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public @Nullable DataModel getDataModel(long dataId) {
        this.queueLock.readLock().lock();
        try {
            DataModel dataModel = (DataModel)((QDataModel)((QDataModel)new QDataModel(this.connection).setProfileLocation(_$ebpq15))._id().equalTo(dataId)).findOne();
            return dataModel;
        }
        finally {
            this.queueLock.readLock().unlock();
        }
    }

    protected final void createSource(HikariConfig config, DatabasePlatform platform, boolean quote, String scriptsName) {
        DataModel model;
        config.setAutoCommit(false);
        this.source = new HikariDataSource(config);
        DatabaseConfig dbConfig = new DatabaseConfig();
        dbConfig.setDataSource(this.source);
        dbConfig.setDatabasePlatform(platform);
        dbConfig.setAllQuotedIdentifiers(quote);
        dbConfig.setDefaultServer(false);
        dbConfig.setRegister(false);
        dbConfig.setName(this.name);
        dbConfig.setClasses(Arrays.asList(BaseModel.class, IPModel.class, PlayerModel.class, DataModel.class));
        this.connection = DatabaseFactory.createWithContextClassLoader(dbConfig, this.getClass().getClassLoader());
        try {
            model = this.getDataModel("schema-version");
        }
        catch (PersistenceException ignored) {
            this.connection.script().run("/db/" + scriptsName + ".sql");
            model = this.getDataModel("schema-version");
        }
        if (model == null) {
            model = new DataModel();
            model.setKey("schema-version");
            model.setValue("1.0");
        }
        if (model.getValue() == null) {
            model.setValue("1.0");
            model.setModified(null);
        }
        List<File> files = this.getResourceDirs("db.migration");
        for (File file : files) {
            if (VersionUtil.isAtLeast(file.getParentFile().getName().substring(1), '_', model.getValue(), '.') || !file.getName().equals(scriptsName + ".sql")) continue;
            this.connection.script().run("/" + file.getPath().replace('\\', '/'));
            model.setValue(file.getParentFile().getName().substring(1).replace('_', '.'));
            model.setModified(null);
        }
        if (!VersionUtil.isAtLeast(model.getValue(), '.', files.get(files.size() - 1).getParentFile().getName().substring(1), '_')) {
            throw new PersistenceException("This plugin is running against a database with a higher version than expected and requires an update to continue.");
        }
        if (model.getModified() == null) {
            this.connection.save(model);
        }
    }

    private List<File> getResourceDirs(@NonNull String prefix) {
        ArrayList<File> retVal = new ArrayList<File>();
        Reflections reflections = new Reflections(prefix, new ResourcesScanner());
        Set<String> files = reflections.getResources(x -> true);
        for (String file : files) {
            retVal.add(new File(file));
        }
        retVal.sort((f1, f2) -> {
            int[] v1 = VersionUtil.parseVersion(f1.getParentFile().getName().substring(1), '_');
            int[] v2 = VersionUtil.parseVersion(f2.getParentFile().getName().substring(1), '_');
            for (int i = 0; i < v1.length; ++i) {
                if (i > v2.length) {
                    return 1;
                }
                if (v2[i] >= v1[i]) continue;
                return -1;
            }
            return 0;
        });
        return retVal;
    }

    private @Nullable BaseModel duplicateModel(@NonNull BaseModel model, boolean keepModified) {
        BaseModel retVal = null;
        if (model instanceof IPModel) {
            IPModel m = new IPModel();
            m.setIp(((IPModel)model).getIp());
            m.setType(((IPModel)model).getType());
            m.setCascade(((IPModel)model).getCascade());
            m.setConsensus(((IPModel)model).getConsensus());
            retVal = m;
        } else if (model instanceof PlayerModel) {
            PlayerModel m = new PlayerModel();
            m.setUuid(((PlayerModel)model).getUuid());
            m.setMcleaks(((PlayerModel)model).isMcleaks());
            retVal = m;
        } else if (model instanceof DataModel) {
            DataModel m = new DataModel();
            m.setKey(((DataModel)model).getKey());
            m.setValue(((DataModel)model).getValue());
            retVal = m;
        }
        if (retVal != null) {
            retVal.setCreated(model.getCreated());
            retVal.setModified(keepModified ? model.getModified() : null);
        } else {
            this.logger.error("duplicateModel is returning null.");
        }
        return retVal;
    }

    private void createOrUpdate(@NonNull BaseModel model, boolean keepModified) {
        if (model instanceof IPModel) {
            IPModel m = (IPModel)((QIPModel)((QIPModel)new QIPModel(this.connection).setProfileLocation(_$ebpq16))._ip().equalTo(((IPModel)model).getIp())).findOne();
            if (m == null) {
                m = (IPModel)this.duplicateModel(model, keepModified);
                if (m == null) {
                    return;
                }
                this.connection.save(m);
            } else {
                m.setType(((IPModel)model).getType());
                m.setCascade(((IPModel)model).getCascade());
                m.setConsensus(((IPModel)model).getConsensus());
                m.setCreated(model.getCreated());
                m.setModified(keepModified ? model.getModified() : null);
                this.connection.update(m);
            }
        } else if (model instanceof PlayerModel) {
            PlayerModel m = (PlayerModel)((QPlayerModel)((QPlayerModel)new QPlayerModel(this.connection).setProfileLocation(_$ebpq17))._uuid().equalTo(((PlayerModel)model).getUuid())).findOne();
            if (m == null) {
                m = (PlayerModel)this.duplicateModel(model, keepModified);
                if (m == null) {
                    return;
                }
                this.connection.save(m);
            } else {
                m.setMcleaks(((PlayerModel)model).isMcleaks());
                m.setCreated(model.getCreated());
                m.setModified(keepModified ? model.getModified() : null);
                this.connection.update(m);
            }
        } else if (model instanceof DataModel) {
            DataModel m = (DataModel)((QDataModel)((QDataModel)new QDataModel(this.connection).setProfileLocation(_$ebpq18))._key().equalTo(((DataModel)model).getKey())).findOne();
            if (m == null) {
                m = (DataModel)this.duplicateModel(model, keepModified);
                if (m == null) {
                    return;
                }
                this.connection.save(m);
            } else {
                m.setKey(((DataModel)model).getKey());
                m.setValue(((DataModel)model).getValue());
                m.setCreated(model.getCreated());
                m.setModified(keepModified ? model.getModified() : null);
                this.connection.update(m);
            }
        }
    }

    private static /* synthetic */ void _$initProfileLocations() {
        _$ebpq0 = ProfileLocation.create();
        _$ebpq1 = ProfileLocation.create();
        _$ebpq2 = ProfileLocation.create();
        _$ebpq3 = ProfileLocation.create();
        _$ebpq4 = ProfileLocation.create();
        _$ebpq5 = ProfileLocation.create();
        _$ebpq6 = ProfileLocation.create();
        _$ebpq7 = ProfileLocation.create();
        _$ebpq8 = ProfileLocation.create();
        _$ebpq9 = ProfileLocation.create();
        _$ebpq10 = ProfileLocation.create();
        _$ebpq11 = ProfileLocation.create();
        _$ebpq12 = ProfileLocation.create();
        _$ebpq13 = ProfileLocation.create();
        _$ebpq14 = ProfileLocation.create();
        _$ebpq15 = ProfileLocation.create();
        _$ebpq16 = ProfileLocation.create();
        _$ebpq17 = ProfileLocation.create();
        _$ebpq18 = ProfileLocation.create();
    }

    static {
        AbstractJDBCStorageService._$initProfileLocations();
    }
}

/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.storage.models;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import me.egg82.antivpn.external.io.ebean.config.ModuleInfo;
import me.egg82.antivpn.external.io.ebean.config.ModuleInfoLoader;
import me.egg82.antivpn.storage.models.DataModel;
import me.egg82.antivpn.storage.models.IPModel;
import me.egg82.antivpn.storage.models.PlayerModel;

@ModuleInfo(entities={"me.egg82.antivpn.storage.models.DataModel", "me.egg82.antivpn.storage.models.IPModel", "me.egg82.antivpn.storage.models.PlayerModel"})
public class _ebean$ModuleInfo
implements ModuleInfoLoader {
    private List<Class<?>> otherClasses() {
        return Collections.emptyList();
    }

    @Override
    public List<Class<?>> entityClasses() {
        ArrayList entities = new ArrayList();
        entities.add(DataModel.class);
        entities.add(IPModel.class);
        entities.add(PlayerModel.class);
        return entities;
    }

    @Override
    public List<Class<?>> entityClassesFor(String dbName) {
        return Collections.emptyList();
    }
}

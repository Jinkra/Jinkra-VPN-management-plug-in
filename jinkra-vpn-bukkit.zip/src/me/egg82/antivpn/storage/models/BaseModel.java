/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.storage.models;

import java.io.Serializable;
import java.time.Instant;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.Version;
import me.egg82.antivpn.external.io.ebean.Model;
import me.egg82.antivpn.external.io.ebean.annotation.WhenCreated;
import me.egg82.antivpn.external.io.ebean.annotation.WhenModified;
import me.egg82.antivpn.external.io.ebean.bean.EntityBean;
import me.egg82.antivpn.external.io.ebean.bean.EntityBeanIntercept;
import org.checkerframework.checker.nullness.qual.Nullable;

@MappedSuperclass
public abstract class BaseModel
extends Model
implements Serializable,
EntityBean {
    @Id
    protected Long id;
    @Version
    protected Long version;
    @WhenCreated
    protected Instant created;
    @WhenModified
    protected Instant modified;
    private static /* synthetic */ String _EBEAN_MARKER = "me.egg82.antivpn.storage.models.BaseModel";
    public static /* synthetic */ String[] _ebean_props;
    protected /* synthetic */ EntityBeanIntercept _ebean_intercept;
    protected transient /* synthetic */ Object _ebean_identity;

    public BaseModel() {
        this._ebean_intercept = new EntityBeanIntercept(this);
        this._ebean_set_id(null);
        this._ebean_set_version(null);
        this._ebean_set_created(null);
        this._ebean_set_modified(null);
    }

    protected BaseModel(String dbName) {
        super(dbName);
        this._ebean_intercept = new EntityBeanIntercept(this);
        this._ebean_set_id(null);
        this._ebean_set_version(null);
        this._ebean_set_created(null);
        this._ebean_set_modified(null);
    }

    public @Nullable Long getId() {
        return this._ebean_get_id();
    }

    public void setId(Long id) {
        this._ebean_set_id(id);
    }

    public @Nullable Long getVersion() {
        return this._ebean_get_version();
    }

    public void setVersion(Long version) {
        this._ebean_set_version(version);
    }

    public @Nullable Instant getCreated() {
        return this._ebean_get_created();
    }

    public void setCreated(Instant created) {
        this._ebean_set_created(created);
    }

    public @Nullable Instant getModified() {
        return this._ebean_get_modified();
    }

    public void setModified(Instant modified) {
        this._ebean_set_modified(modified);
    }

    public String toString() {
        return "BaseModel{id=" + this.id + ", version=" + this.version + ", created=" + this.created + ", modified=" + this.modified + '}';
    }

    static {
        _ebean_props = new String[]{"id", "version", "created", "modified"};
    }

    @Override
    public /* synthetic */ String _ebean_getMarker() {
        return _EBEAN_MARKER;
    }

    @Override
    public /* synthetic */ String[] _ebean_getPropertyNames() {
        return _ebean_props;
    }

    @Override
    public /* synthetic */ String _ebean_getPropertyName(int pos) {
        return _ebean_props[pos];
    }

    @Override
    public /* synthetic */ EntityBeanIntercept _ebean_getIntercept() {
        return this._ebean_intercept;
    }

    @Override
    public /* synthetic */ EntityBeanIntercept _ebean_intercept() {
        if (this._ebean_intercept == null) {
            this._ebean_intercept = new EntityBeanIntercept(this);
        }
        return this._ebean_intercept;
    }

    protected /* synthetic */ Long _ebean_get_id() {
        this._ebean_intercept.preGetId();
        return this.id;
    }

    protected /* synthetic */ void _ebean_set_id(Long newValue) {
        this._ebean_intercept.preSetter(false, 0, this.id, newValue);
        this.id = newValue;
    }

    protected /* synthetic */ Long _ebean_getni_id() {
        return this.id;
    }

    protected /* synthetic */ void _ebean_setni_id(Long _newValue) {
        this.id = _newValue;
        this._ebean_intercept.setLoadedProperty(0);
    }

    protected /* synthetic */ Long _ebean_get_version() {
        this._ebean_intercept.preGetter(1);
        return this.version;
    }

    protected /* synthetic */ void _ebean_set_version(Long newValue) {
        this._ebean_intercept.preSetter(true, 1, this._ebean_get_version(), newValue);
        this.version = newValue;
    }

    protected /* synthetic */ Long _ebean_getni_version() {
        return this.version;
    }

    protected /* synthetic */ void _ebean_setni_version(Long _newValue) {
        this.version = _newValue;
        this._ebean_intercept.setLoadedProperty(1);
    }

    protected /* synthetic */ Instant _ebean_get_created() {
        this._ebean_intercept.preGetter(2);
        return this.created;
    }

    protected /* synthetic */ void _ebean_set_created(Instant newValue) {
        this._ebean_intercept.preSetter(true, 2, this._ebean_get_created(), newValue);
        this.created = newValue;
    }

    protected /* synthetic */ Instant _ebean_getni_created() {
        return this.created;
    }

    protected /* synthetic */ void _ebean_setni_created(Instant _newValue) {
        this.created = _newValue;
        this._ebean_intercept.setLoadedProperty(2);
    }

    protected /* synthetic */ Instant _ebean_get_modified() {
        this._ebean_intercept.preGetter(3);
        return this.modified;
    }

    protected /* synthetic */ void _ebean_set_modified(Instant newValue) {
        this._ebean_intercept.preSetter(true, 3, this._ebean_get_modified(), newValue);
        this.modified = newValue;
    }

    protected /* synthetic */ Instant _ebean_getni_modified() {
        return this.modified;
    }

    protected /* synthetic */ void _ebean_setni_modified(Instant _newValue) {
        this.modified = _newValue;
        this._ebean_intercept.setLoadedProperty(3);
    }

    @Override
    public /* synthetic */ Object _ebean_getField(int index) {
        switch (index) {
            case 0: {
                return this.id;
            }
            case 1: {
                return this.version;
            }
            case 2: {
                return this.created;
            }
            case 3: {
                return this.modified;
            }
        }
        throw new RuntimeException("Invalid index " + index);
    }

    @Override
    public /* synthetic */ Object _ebean_getFieldIntercept(int index) {
        switch (index) {
            case 0: {
                return this._ebean_get_id();
            }
            case 1: {
                return this._ebean_get_version();
            }
            case 2: {
                return this._ebean_get_created();
            }
            case 3: {
                return this._ebean_get_modified();
            }
        }
        throw new RuntimeException("Invalid index " + index);
    }

    @Override
    public /* synthetic */ void _ebean_setField(int index, Object o) {
        switch (index) {
            case 0: {
                this._ebean_setni_id((Long)o);
                return;
            }
            case 1: {
                this._ebean_setni_version((Long)o);
                return;
            }
            case 2: {
                this._ebean_setni_created((Instant)o);
                return;
            }
            case 3: {
                this._ebean_setni_modified((Instant)o);
                return;
            }
        }
        throw new RuntimeException("Invalid index " + index);
    }

    @Override
    public /* synthetic */ void _ebean_setFieldIntercept(int index, Object o) {
        switch (index) {
            case 0: {
                this._ebean_set_id((Long)o);
                return;
            }
            case 1: {
                this._ebean_set_version((Long)o);
                return;
            }
            case 2: {
                this._ebean_set_created((Instant)o);
                return;
            }
            case 3: {
                this._ebean_set_modified((Instant)o);
                return;
            }
        }
        throw new RuntimeException("Invalid index " + index);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private /* synthetic */ Object _ebean_getIdentity() {
        BaseModel baseModel = this;
        synchronized (baseModel) {
            if (this._ebean_identity != null) {
                return this._ebean_identity;
            }
            Object tmpId = this._ebean_getField(0);
            this._ebean_identity = tmpId != null ? tmpId : new Object();
            return this._ebean_identity;
        }
    }

    public /* synthetic */ boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (!this.getClass().equals(obj.getClass())) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        return this._ebean_getIdentity().equals(((BaseModel)obj)._ebean_getIdentity());
    }

    public /* synthetic */ int hashCode() {
        return this._ebean_getIdentity().hashCode();
    }

    @Override
    public /* synthetic */ void _ebean_setEmbeddedLoaded() {
    }

    @Override
    public /* synthetic */ boolean _ebean_isEmbeddedNewOrDirty() {
        return false;
    }

    @Override
    public /* synthetic */ Object _ebean_newInstance() {
        return new BaseModel();
    }
}

/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.storage.models;

import java.time.Instant;
import javax.persistence.Entity;
import javax.persistence.Table;
import me.egg82.antivpn.external.io.ebean.annotation.NotNull;
import me.egg82.antivpn.external.io.ebean.bean.EntityBean;
import me.egg82.antivpn.storage.models.BaseModel;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.checkerframework.checker.nullness.qual.Nullable;

@Entity
@Table(name="avpn_6_data")
public class DataModel
extends BaseModel
implements EntityBean {
    @NotNull
    private String key;
    private String value;
    private static /* synthetic */ String _EBEAN_MARKER = "me.egg82.antivpn.storage.models.DataModel";
    public static /* synthetic */ String[] _ebean_props;

    public DataModel() {
        this._ebean_set_key("");
        this._ebean_set_value(null);
    }

    public DataModel(@NonNull String dbName) {
        super(dbName);
        this._ebean_set_key("");
        this._ebean_set_value(null);
    }

    public @NonNull String getKey() {
        return this._ebean_get_key();
    }

    public void setKey(@NonNull String key) {
        this._ebean_set_key(key);
    }

    public @Nullable String getValue() {
        return this._ebean_get_value();
    }

    public void setValue(String value) {
        this._ebean_set_value(value);
    }

    @Override
    public String toString() {
        return "DataModel{id=" + this.id + ", version=" + this.version + ", created=" + this.created + ", modified=" + this.modified + ", key='" + this.key + '\'' + ", value='" + this.value + '\'' + '}';
    }

    static {
        _ebean_props = new String[]{"id", "version", "created", "modified", "key", "value"};
    }

    @Override
    public /* synthetic */ String _ebean_getMarker() {
        return _EBEAN_MARKER;
    }

    @Override
    public /* synthetic */ String[] _ebean_getPropertyNames() {
        return _ebean_props;
    }

    @Override
    public /* synthetic */ String _ebean_getPropertyName(int pos) {
        return _ebean_props[pos];
    }

    protected /* synthetic */ String _ebean_get_key() {
        this._ebean_intercept.preGetter(4);
        return this.key;
    }

    protected /* synthetic */ void _ebean_set_key(String newValue) {
        this._ebean_intercept.preSetter(true, 4, this._ebean_get_key(), newValue);
        this.key = newValue;
    }

    protected /* synthetic */ String _ebean_getni_key() {
        return this.key;
    }

    protected /* synthetic */ void _ebean_setni_key(String _newValue) {
        this.key = _newValue;
        this._ebean_intercept.setLoadedProperty(4);
    }

    protected /* synthetic */ String _ebean_get_value() {
        this._ebean_intercept.preGetter(5);
        return this.value;
    }

    protected /* synthetic */ void _ebean_set_value(String newValue) {
        this._ebean_intercept.preSetter(true, 5, this._ebean_get_value(), newValue);
        this.value = newValue;
    }

    protected /* synthetic */ String _ebean_getni_value() {
        return this.value;
    }

    protected /* synthetic */ void _ebean_setni_value(String _newValue) {
        this.value = _newValue;
        this._ebean_intercept.setLoadedProperty(5);
    }

    @Override
    public /* synthetic */ Object _ebean_getField(int index) {
        switch (index) {
            case 0: {
                return this._ebean_getni_id();
            }
            case 1: {
                return this._ebean_getni_version();
            }
            case 2: {
                return this._ebean_getni_created();
            }
            case 3: {
                return this._ebean_getni_modified();
            }
            case 4: {
                return this.key;
            }
            case 5: {
                return this.value;
            }
        }
        throw new RuntimeException("Invalid index " + index);
    }

    @Override
    public /* synthetic */ Object _ebean_getFieldIntercept(int index) {
        switch (index) {
            case 0: {
                return this._ebean_get_id();
            }
            case 1: {
                return this._ebean_get_version();
            }
            case 2: {
                return this._ebean_get_created();
            }
            case 3: {
                return this._ebean_get_modified();
            }
            case 4: {
                return this._ebean_get_key();
            }
            case 5: {
                return this._ebean_get_value();
            }
        }
        throw new RuntimeException("Invalid index " + index);
    }

    @Override
    public /* synthetic */ void _ebean_setField(int index, Object o) {
        switch (index) {
            case 0: {
                this._ebean_setni_id((Long)o);
                return;
            }
            case 1: {
                this._ebean_setni_version((Long)o);
                return;
            }
            case 2: {
                this._ebean_setni_created((Instant)o);
                return;
            }
            case 3: {
                this._ebean_setni_modified((Instant)o);
                return;
            }
            case 4: {
                this._ebean_setni_key((String)o);
                return;
            }
            case 5: {
                this._ebean_setni_value((String)o);
                return;
            }
        }
        throw new RuntimeException("Invalid index " + index);
    }

    @Override
    public /* synthetic */ void _ebean_setFieldIntercept(int index, Object o) {
        switch (index) {
            case 0: {
                this._ebean_set_id((Long)o);
                return;
            }
            case 1: {
                this._ebean_set_version((Long)o);
                return;
            }
            case 2: {
                this._ebean_set_created((Instant)o);
                return;
            }
            case 3: {
                this._ebean_set_modified((Instant)o);
                return;
            }
            case 4: {
                this._ebean_set_key((String)o);
                return;
            }
            case 5: {
                this._ebean_set_value((String)o);
                return;
            }
        }
        throw new RuntimeException("Invalid index " + index);
    }

    @Override
    public /* synthetic */ void _ebean_setEmbeddedLoaded() {
    }

    @Override
    public /* synthetic */ boolean _ebean_isEmbeddedNewOrDirty() {
        return false;
    }

    @Override
    public /* synthetic */ Object _ebean_newInstance() {
        return new DataModel();
    }
}

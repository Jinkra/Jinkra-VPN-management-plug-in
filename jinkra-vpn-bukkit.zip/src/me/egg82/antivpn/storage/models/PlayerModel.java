/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.storage.models;

import java.time.Instant;
import java.util.UUID;
import javax.persistence.Entity;
import javax.persistence.Table;
import me.egg82.antivpn.external.io.ebean.annotation.Index;
import me.egg82.antivpn.external.io.ebean.annotation.NotNull;
import me.egg82.antivpn.external.io.ebean.bean.EntityBean;
import me.egg82.antivpn.storage.models.BaseModel;
import org.checkerframework.checker.nullness.qual.NonNull;

@Entity
@Table(name="avpn_6_player")
public class PlayerModel
extends BaseModel
implements EntityBean {
    @Index(unique=true)
    @NotNull
    private UUID uuid;
    @NotNull
    private boolean mcleaks;
    private static /* synthetic */ String _EBEAN_MARKER = "me.egg82.antivpn.storage.models.PlayerModel";
    public static /* synthetic */ String[] _ebean_props;

    public PlayerModel() {
        this._ebean_set_uuid(new UUID(0L, 0L));
        this._ebean_set_mcleaks(false);
    }

    public PlayerModel(@NonNull String dbName) {
        super(dbName);
        this._ebean_set_uuid(new UUID(0L, 0L));
        this._ebean_set_mcleaks(false);
    }

    public @NonNull UUID getUuid() {
        return this._ebean_get_uuid();
    }

    public void setUuid(@NonNull UUID uuid) {
        this._ebean_set_uuid(uuid);
    }

    public boolean isMcleaks() {
        return this._ebean_get_mcleaks();
    }

    public void setMcleaks(boolean mcleaks) {
        this._ebean_set_mcleaks(mcleaks);
    }

    @Override
    public String toString() {
        return "PlayerModel{id=" + this.id + ", version=" + this.version + ", created=" + this.created + ", modified=" + this.modified + ", uuid=" + this.uuid + ", mcleaks=" + this.mcleaks + '}';
    }

    static {
        _ebean_props = new String[]{"id", "version", "created", "modified", "uuid", "mcleaks"};
    }

    @Override
    public /* synthetic */ String _ebean_getMarker() {
        return _EBEAN_MARKER;
    }

    @Override
    public /* synthetic */ String[] _ebean_getPropertyNames() {
        return _ebean_props;
    }

    @Override
    public /* synthetic */ String _ebean_getPropertyName(int pos) {
        return _ebean_props[pos];
    }

    protected /* synthetic */ UUID _ebean_get_uuid() {
        this._ebean_intercept.preGetter(4);
        return this.uuid;
    }

    protected /* synthetic */ void _ebean_set_uuid(UUID newValue) {
        this._ebean_intercept.preSetter(true, 4, this._ebean_get_uuid(), newValue);
        this.uuid = newValue;
    }

    protected /* synthetic */ UUID _ebean_getni_uuid() {
        return this.uuid;
    }

    protected /* synthetic */ void _ebean_setni_uuid(UUID _newValue) {
        this.uuid = _newValue;
        this._ebean_intercept.setLoadedProperty(4);
    }

    protected /* synthetic */ boolean _ebean_get_mcleaks() {
        this._ebean_intercept.preGetter(5);
        return this.mcleaks;
    }

    protected /* synthetic */ void _ebean_set_mcleaks(boolean newValue) {
        this._ebean_intercept.preSetter(true, 5, this._ebean_get_mcleaks(), newValue);
        this.mcleaks = newValue;
    }

    protected /* synthetic */ boolean _ebean_getni_mcleaks() {
        return this.mcleaks;
    }

    protected /* synthetic */ void _ebean_setni_mcleaks(boolean _newValue) {
        this.mcleaks = _newValue;
        this._ebean_intercept.setLoadedProperty(5);
    }

    @Override
    public /* synthetic */ Object _ebean_getField(int index) {
        switch (index) {
            case 0: {
                return this._ebean_getni_id();
            }
            case 1: {
                return this._ebean_getni_version();
            }
            case 2: {
                return this._ebean_getni_created();
            }
            case 3: {
                return this._ebean_getni_modified();
            }
            case 4: {
                return this.uuid;
            }
            case 5: {
                return this.mcleaks;
            }
        }
        throw new RuntimeException("Invalid index " + index);
    }

    @Override
    public /* synthetic */ Object _ebean_getFieldIntercept(int index) {
        switch (index) {
            case 0: {
                return this._ebean_get_id();
            }
            case 1: {
                return this._ebean_get_version();
            }
            case 2: {
                return this._ebean_get_created();
            }
            case 3: {
                return this._ebean_get_modified();
            }
            case 4: {
                return this._ebean_get_uuid();
            }
            case 5: {
                return this._ebean_get_mcleaks();
            }
        }
        throw new RuntimeException("Invalid index " + index);
    }

    @Override
    public /* synthetic */ void _ebean_setField(int index, Object o) {
        switch (index) {
            case 0: {
                this._ebean_setni_id((Long)o);
                return;
            }
            case 1: {
                this._ebean_setni_version((Long)o);
                return;
            }
            case 2: {
                this._ebean_setni_created((Instant)o);
                return;
            }
            case 3: {
                this._ebean_setni_modified((Instant)o);
                return;
            }
            case 4: {
                this._ebean_setni_uuid((UUID)o);
                return;
            }
            case 5: {
                this._ebean_setni_mcleaks((Boolean)o);
                return;
            }
        }
        throw new RuntimeException("Invalid index " + index);
    }

    @Override
    public /* synthetic */ void _ebean_setFieldIntercept(int index, Object o) {
        switch (index) {
            case 0: {
                this._ebean_set_id((Long)o);
                return;
            }
            case 1: {
                this._ebean_set_version((Long)o);
                return;
            }
            case 2: {
                this._ebean_set_created((Instant)o);
                return;
            }
            case 3: {
                this._ebean_set_modified((Instant)o);
                return;
            }
            case 4: {
                this._ebean_set_uuid((UUID)o);
                return;
            }
            case 5: {
                this._ebean_set_mcleaks((Boolean)o);
                return;
            }
        }
        throw new RuntimeException("Invalid index " + index);
    }

    @Override
    public /* synthetic */ void _ebean_setEmbeddedLoaded() {
    }

    @Override
    public /* synthetic */ boolean _ebean_isEmbeddedNewOrDirty() {
        return false;
    }

    @Override
    public /* synthetic */ Object _ebean_newInstance() {
        return new PlayerModel();
    }
}

/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.storage.models;

import java.time.Instant;
import javax.persistence.Entity;
import javax.persistence.Table;
import me.egg82.antivpn.external.io.ebean.annotation.Index;
import me.egg82.antivpn.external.io.ebean.annotation.Length;
import me.egg82.antivpn.external.io.ebean.annotation.NotNull;
import me.egg82.antivpn.external.io.ebean.bean.EntityBean;
import me.egg82.antivpn.storage.models.BaseModel;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.checkerframework.checker.nullness.qual.Nullable;

@Entity
@Table(name="avpn_6_ip")
public class IPModel
extends BaseModel
implements EntityBean {
    @Index(unique=true)
    @NotNull
    @Length(value=45)
    private String ip;
    @NotNull
    private int type;
    private Boolean cascade;
    private Double consensus;
    private static /* synthetic */ String _EBEAN_MARKER = "me.egg82.antivpn.storage.models.IPModel";
    public static /* synthetic */ String[] _ebean_props;

    public IPModel() {
        this._ebean_set_ip("");
        this._ebean_set_type(-1);
        this._ebean_set_cascade(null);
        this._ebean_set_consensus(null);
    }

    public IPModel(String dbName) {
        super(dbName);
        this._ebean_set_ip("");
        this._ebean_set_type(-1);
        this._ebean_set_cascade(null);
        this._ebean_set_consensus(null);
    }

    public @NonNull String getIp() {
        return this._ebean_get_ip();
    }

    public void setIp(@NonNull String ip) {
        this._ebean_set_ip(ip);
    }

    public int getType() {
        return this._ebean_get_type();
    }

    public void setType(int type) {
        this._ebean_set_type(type);
    }

    public @Nullable Boolean getCascade() {
        return this._ebean_get_cascade();
    }

    public void setCascade(Boolean cascade) {
        this._ebean_set_cascade(cascade);
    }

    public @Nullable Double getConsensus() {
        return this._ebean_get_consensus();
    }

    public void setConsensus(Double consensus) {
        this._ebean_set_consensus(consensus);
    }

    @Override
    public String toString() {
        return "IPModel{id=" + this.id + ", version=" + this.version + ", created=" + this.created + ", modified=" + this.modified + ", ip='" + this.ip + '\'' + ", type=" + this.type + ", cascade=" + this.cascade + ", consensus=" + this.consensus + '}';
    }

    static {
        _ebean_props = new String[]{"id", "version", "created", "modified", "ip", "type", "cascade", "consensus"};
    }

    @Override
    public /* synthetic */ String _ebean_getMarker() {
        return _EBEAN_MARKER;
    }

    @Override
    public /* synthetic */ String[] _ebean_getPropertyNames() {
        return _ebean_props;
    }

    @Override
    public /* synthetic */ String _ebean_getPropertyName(int pos) {
        return _ebean_props[pos];
    }

    protected /* synthetic */ String _ebean_get_ip() {
        this._ebean_intercept.preGetter(4);
        return this.ip;
    }

    protected /* synthetic */ void _ebean_set_ip(String newValue) {
        this._ebean_intercept.preSetter(true, 4, this._ebean_get_ip(), newValue);
        this.ip = newValue;
    }

    protected /* synthetic */ String _ebean_getni_ip() {
        return this.ip;
    }

    protected /* synthetic */ void _ebean_setni_ip(String _newValue) {
        this.ip = _newValue;
        this._ebean_intercept.setLoadedProperty(4);
    }

    protected /* synthetic */ int _ebean_get_type() {
        this._ebean_intercept.preGetter(5);
        return this.type;
    }

    protected /* synthetic */ void _ebean_set_type(int newValue) {
        this._ebean_intercept.preSetter(true, 5, this._ebean_get_type(), newValue);
        this.type = newValue;
    }

    protected /* synthetic */ int _ebean_getni_type() {
        return this.type;
    }

    protected /* synthetic */ void _ebean_setni_type(int _newValue) {
        this.type = _newValue;
        this._ebean_intercept.setLoadedProperty(5);
    }

    protected /* synthetic */ Boolean _ebean_get_cascade() {
        this._ebean_intercept.preGetter(6);
        return this.cascade;
    }

    protected /* synthetic */ void _ebean_set_cascade(Boolean newValue) {
        this._ebean_intercept.preSetter(true, 6, this._ebean_get_cascade(), newValue);
        this.cascade = newValue;
    }

    protected /* synthetic */ Boolean _ebean_getni_cascade() {
        return this.cascade;
    }

    protected /* synthetic */ void _ebean_setni_cascade(Boolean _newValue) {
        this.cascade = _newValue;
        this._ebean_intercept.setLoadedProperty(6);
    }

    protected /* synthetic */ Double _ebean_get_consensus() {
        this._ebean_intercept.preGetter(7);
        return this.consensus;
    }

    protected /* synthetic */ void _ebean_set_consensus(Double newValue) {
        this._ebean_intercept.preSetter(true, 7, this._ebean_get_consensus(), newValue);
        this.consensus = newValue;
    }

    protected /* synthetic */ Double _ebean_getni_consensus() {
        return this.consensus;
    }

    protected /* synthetic */ void _ebean_setni_consensus(Double _newValue) {
        this.consensus = _newValue;
        this._ebean_intercept.setLoadedProperty(7);
    }

    @Override
    public /* synthetic */ Object _ebean_getField(int index) {
        switch (index) {
            case 0: {
                return this._ebean_getni_id();
            }
            case 1: {
                return this._ebean_getni_version();
            }
            case 2: {
                return this._ebean_getni_created();
            }
            case 3: {
                return this._ebean_getni_modified();
            }
            case 4: {
                return this.ip;
            }
            case 5: {
                return this.type;
            }
            case 6: {
                return this.cascade;
            }
            case 7: {
                return this.consensus;
            }
        }
        throw new RuntimeException("Invalid index " + index);
    }

    @Override
    public /* synthetic */ Object _ebean_getFieldIntercept(int index) {
        switch (index) {
            case 0: {
                return this._ebean_get_id();
            }
            case 1: {
                return this._ebean_get_version();
            }
            case 2: {
                return this._ebean_get_created();
            }
            case 3: {
                return this._ebean_get_modified();
            }
            case 4: {
                return this._ebean_get_ip();
            }
            case 5: {
                return this._ebean_get_type();
            }
            case 6: {
                return this._ebean_get_cascade();
            }
            case 7: {
                return this._ebean_get_consensus();
            }
        }
        throw new RuntimeException("Invalid index " + index);
    }

    @Override
    public /* synthetic */ void _ebean_setField(int index, Object o) {
        switch (index) {
            case 0: {
                this._ebean_setni_id((Long)o);
                return;
            }
            case 1: {
                this._ebean_setni_version((Long)o);
                return;
            }
            case 2: {
                this._ebean_setni_created((Instant)o);
                return;
            }
            case 3: {
                this._ebean_setni_modified((Instant)o);
                return;
            }
            case 4: {
                this._ebean_setni_ip((String)o);
                return;
            }
            case 5: {
                this._ebean_setni_type((Integer)o);
                return;
            }
            case 6: {
                this._ebean_setni_cascade((Boolean)o);
                return;
            }
            case 7: {
                this._ebean_setni_consensus((Double)o);
                return;
            }
        }
        throw new RuntimeException("Invalid index " + index);
    }

    @Override
    public /* synthetic */ void _ebean_setFieldIntercept(int index, Object o) {
        switch (index) {
            case 0: {
                this._ebean_set_id((Long)o);
                return;
            }
            case 1: {
                this._ebean_set_version((Long)o);
                return;
            }
            case 2: {
                this._ebean_set_created((Instant)o);
                return;
            }
            case 3: {
                this._ebean_set_modified((Instant)o);
                return;
            }
            case 4: {
                this._ebean_set_ip((String)o);
                return;
            }
            case 5: {
                this._ebean_set_type((Integer)o);
                return;
            }
            case 6: {
                this._ebean_set_cascade((Boolean)o);
                return;
            }
            case 7: {
                this._ebean_set_consensus((Double)o);
                return;
            }
        }
        throw new RuntimeException("Invalid index " + index);
    }

    @Override
    public /* synthetic */ void _ebean_setEmbeddedLoaded() {
    }

    @Override
    public /* synthetic */ boolean _ebean_isEmbeddedNewOrDirty() {
        return false;
    }

    @Override
    public /* synthetic */ Object _ebean_newInstance() {
        return new IPModel();
    }
}

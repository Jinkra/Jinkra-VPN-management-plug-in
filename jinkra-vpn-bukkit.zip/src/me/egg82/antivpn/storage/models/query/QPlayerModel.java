/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.storage.models.query;

import me.egg82.antivpn.external.io.ebean.Database;
import me.egg82.antivpn.external.io.ebean.FetchGroup;
import me.egg82.antivpn.external.io.ebean.ProfileLocation;
import me.egg82.antivpn.external.io.ebean.Query;
import me.egg82.antivpn.external.io.ebean.Transaction;
import me.egg82.antivpn.external.io.ebean.typequery.AlreadyEnhancedMarker;
import me.egg82.antivpn.external.io.ebean.typequery.PBoolean;
import me.egg82.antivpn.external.io.ebean.typequery.PInstant;
import me.egg82.antivpn.external.io.ebean.typequery.PLong;
import me.egg82.antivpn.external.io.ebean.typequery.PUuid;
import me.egg82.antivpn.external.io.ebean.typequery.TQRootBean;
import me.egg82.antivpn.external.io.ebean.typequery.TypeQueryBean;
import me.egg82.antivpn.storage.models.PlayerModel;

@TypeQueryBean(value="v1")
@AlreadyEnhancedMarker
public class QPlayerModel
extends TQRootBean<PlayerModel, QPlayerModel> {
    private static final QPlayerModel _alias;
    public PLong<QPlayerModel> id;
    public PLong<QPlayerModel> version;
    public PInstant<QPlayerModel> created;
    public PInstant<QPlayerModel> modified;
    public PUuid<QPlayerModel> uuid;
    public PBoolean<QPlayerModel> mcleaks;
    private static /* synthetic */ ProfileLocation _$ebpq0;

    public static QPlayerModel alias() {
        return _alias;
    }

    public static QPlayerModel forFetchGroup() {
        return (QPlayerModel)new QPlayerModel((Query<PlayerModel>)FetchGroup.queryFor(PlayerModel.class)).setProfileLocation(_$ebpq0);
    }

    public QPlayerModel() {
        super(PlayerModel.class);
    }

    public QPlayerModel(Transaction transaction) {
        super(PlayerModel.class, transaction);
    }

    public QPlayerModel(Database database) {
        super(PlayerModel.class, database);
    }

    private QPlayerModel(boolean alias) {
        super(alias);
        this.setRoot(this);
        this.id = new PLong<QPlayerModel>("id", this);
        this.version = new PLong<QPlayerModel>("version", this);
        this.created = new PInstant<QPlayerModel>("created", this);
        this.modified = new PInstant<QPlayerModel>("modified", this);
        this.uuid = new PUuid<QPlayerModel>("uuid", this);
        this.mcleaks = new PBoolean<QPlayerModel>("mcleaks", this);
    }

    private QPlayerModel(Query<PlayerModel> fetchGroupQuery) {
        super(fetchGroupQuery);
    }

    static /* synthetic */ QPlayerModel access$000() {
        return _alias;
    }

    static {
        QPlayerModel._$ebpq0 = ProfileLocation.create();
        _alias = new QPlayerModel(true);
    }

    public PLong<QPlayerModel> _id() {
        if (this.id == null) {
            this.id = new PLong<QPlayerModel>("id", this);
        }
        return this.id;
    }

    public PLong<QPlayerModel> _version() {
        if (this.version == null) {
            this.version = new PLong<QPlayerModel>("version", this);
        }
        return this.version;
    }

    public PInstant<QPlayerModel> _created() {
        if (this.created == null) {
            this.created = new PInstant<QPlayerModel>("created", this);
        }
        return this.created;
    }

    public PInstant<QPlayerModel> _modified() {
        if (this.modified == null) {
            this.modified = new PInstant<QPlayerModel>("modified", this);
        }
        return this.modified;
    }

    public PUuid<QPlayerModel> _uuid() {
        if (this.uuid == null) {
            this.uuid = new PUuid<QPlayerModel>("uuid", this);
        }
        return this.uuid;
    }

    public PBoolean<QPlayerModel> _mcleaks() {
        if (this.mcleaks == null) {
            this.mcleaks = new PBoolean<QPlayerModel>("mcleaks", this);
        }
        return this.mcleaks;
    }

    public static class Alias {
        public static PLong<QPlayerModel> id = QPlayerModel.access$000()._id();
        public static PLong<QPlayerModel> version = QPlayerModel.access$000()._version();
        public static PInstant<QPlayerModel> created = QPlayerModel.access$000()._created();
        public static PInstant<QPlayerModel> modified = QPlayerModel.access$000()._modified();
        public static PUuid<QPlayerModel> uuid = QPlayerModel.access$000()._uuid();
        public static PBoolean<QPlayerModel> mcleaks = QPlayerModel.access$000()._mcleaks();
    }
}

/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.storage.models.query;

import me.egg82.antivpn.external.io.ebean.typequery.PBoolean;
import me.egg82.antivpn.external.io.ebean.typequery.PInstant;
import me.egg82.antivpn.external.io.ebean.typequery.PLong;
import me.egg82.antivpn.external.io.ebean.typequery.PUuid;
import me.egg82.antivpn.storage.models.query.QPlayerModel;

public static class QPlayerModel.Alias {
    public static PLong<QPlayerModel> id = QPlayerModel.access$000()._id();
    public static PLong<QPlayerModel> version = QPlayerModel.access$000()._version();
    public static PInstant<QPlayerModel> created = QPlayerModel.access$000()._created();
    public static PInstant<QPlayerModel> modified = QPlayerModel.access$000()._modified();
    public static PUuid<QPlayerModel> uuid = QPlayerModel.access$000()._uuid();
    public static PBoolean<QPlayerModel> mcleaks = QPlayerModel.access$000()._mcleaks();
}

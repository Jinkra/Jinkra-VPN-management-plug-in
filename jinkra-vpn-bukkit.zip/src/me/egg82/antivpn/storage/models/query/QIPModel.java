/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.storage.models.query;

import me.egg82.antivpn.external.io.ebean.Database;
import me.egg82.antivpn.external.io.ebean.FetchGroup;
import me.egg82.antivpn.external.io.ebean.ProfileLocation;
import me.egg82.antivpn.external.io.ebean.Query;
import me.egg82.antivpn.external.io.ebean.Transaction;
import me.egg82.antivpn.external.io.ebean.typequery.AlreadyEnhancedMarker;
import me.egg82.antivpn.external.io.ebean.typequery.PBoolean;
import me.egg82.antivpn.external.io.ebean.typequery.PDouble;
import me.egg82.antivpn.external.io.ebean.typequery.PInstant;
import me.egg82.antivpn.external.io.ebean.typequery.PInteger;
import me.egg82.antivpn.external.io.ebean.typequery.PLong;
import me.egg82.antivpn.external.io.ebean.typequery.PString;
import me.egg82.antivpn.external.io.ebean.typequery.TQRootBean;
import me.egg82.antivpn.external.io.ebean.typequery.TypeQueryBean;
import me.egg82.antivpn.storage.models.IPModel;

@TypeQueryBean(value="v1")
@AlreadyEnhancedMarker
public class QIPModel
extends TQRootBean<IPModel, QIPModel> {
    private static final QIPModel _alias;
    public PLong<QIPModel> id;
    public PLong<QIPModel> version;
    public PInstant<QIPModel> created;
    public PInstant<QIPModel> modified;
    public PString<QIPModel> ip;
    public PInteger<QIPModel> type;
    public PBoolean<QIPModel> cascade;
    public PDouble<QIPModel> consensus;
    private static /* synthetic */ ProfileLocation _$ebpq0;

    public static QIPModel alias() {
        return _alias;
    }

    public static QIPModel forFetchGroup() {
        return (QIPModel)new QIPModel((Query<IPModel>)FetchGroup.queryFor(IPModel.class)).setProfileLocation(_$ebpq0);
    }

    public QIPModel() {
        super(IPModel.class);
    }

    public QIPModel(Transaction transaction) {
        super(IPModel.class, transaction);
    }

    public QIPModel(Database database) {
        super(IPModel.class, database);
    }

    private QIPModel(boolean alias) {
        super(alias);
        this.setRoot(this);
        this.id = new PLong<QIPModel>("id", this);
        this.version = new PLong<QIPModel>("version", this);
        this.created = new PInstant<QIPModel>("created", this);
        this.modified = new PInstant<QIPModel>("modified", this);
        this.ip = new PString<QIPModel>("ip", this);
        this.type = new PInteger<QIPModel>("type", this);
        this.cascade = new PBoolean<QIPModel>("cascade", this);
        this.consensus = new PDouble<QIPModel>("consensus", this);
    }

    private QIPModel(Query<IPModel> fetchGroupQuery) {
        super(fetchGroupQuery);
    }

    static /* synthetic */ QIPModel access$000() {
        return _alias;
    }

    static {
        QIPModel._$ebpq0 = ProfileLocation.create();
        _alias = new QIPModel(true);
    }

    public PLong<QIPModel> _id() {
        if (this.id == null) {
            this.id = new PLong<QIPModel>("id", this);
        }
        return this.id;
    }

    public PLong<QIPModel> _version() {
        if (this.version == null) {
            this.version = new PLong<QIPModel>("version", this);
        }
        return this.version;
    }

    public PInstant<QIPModel> _created() {
        if (this.created == null) {
            this.created = new PInstant<QIPModel>("created", this);
        }
        return this.created;
    }

    public PInstant<QIPModel> _modified() {
        if (this.modified == null) {
            this.modified = new PInstant<QIPModel>("modified", this);
        }
        return this.modified;
    }

    public PString<QIPModel> _ip() {
        if (this.ip == null) {
            this.ip = new PString<QIPModel>("ip", this);
        }
        return this.ip;
    }

    public PInteger<QIPModel> _type() {
        if (this.type == null) {
            this.type = new PInteger<QIPModel>("type", this);
        }
        return this.type;
    }

    public PBoolean<QIPModel> _cascade() {
        if (this.cascade == null) {
            this.cascade = new PBoolean<QIPModel>("cascade", this);
        }
        return this.cascade;
    }

    public PDouble<QIPModel> _consensus() {
        if (this.consensus == null) {
            this.consensus = new PDouble<QIPModel>("consensus", this);
        }
        return this.consensus;
    }

    public static class Alias {
        public static PLong<QIPModel> id = QIPModel.access$000()._id();
        public static PLong<QIPModel> version = QIPModel.access$000()._version();
        public static PInstant<QIPModel> created = QIPModel.access$000()._created();
        public static PInstant<QIPModel> modified = QIPModel.access$000()._modified();
        public static PString<QIPModel> ip = QIPModel.access$000()._ip();
        public static PInteger<QIPModel> type = QIPModel.access$000()._type();
        public static PBoolean<QIPModel> cascade = QIPModel.access$000()._cascade();
        public static PDouble<QIPModel> consensus = QIPModel.access$000()._consensus();
    }
}

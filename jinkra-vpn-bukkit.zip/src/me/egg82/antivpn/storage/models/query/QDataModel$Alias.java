/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.storage.models.query;

import me.egg82.antivpn.external.io.ebean.typequery.PInstant;
import me.egg82.antivpn.external.io.ebean.typequery.PLong;
import me.egg82.antivpn.external.io.ebean.typequery.PString;
import me.egg82.antivpn.storage.models.query.QDataModel;

public static class QDataModel.Alias {
    public static PLong<QDataModel> id = QDataModel.access$000()._id();
    public static PLong<QDataModel> version = QDataModel.access$000()._version();
    public static PInstant<QDataModel> created = QDataModel.access$000()._created();
    public static PInstant<QDataModel> modified = QDataModel.access$000()._modified();
    public static PString<QDataModel> key = QDataModel.access$000()._key();
    public static PString<QDataModel> value = QDataModel.access$000()._value();
}

/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.storage.models.query;

import me.egg82.antivpn.external.io.ebean.Database;
import me.egg82.antivpn.external.io.ebean.FetchGroup;
import me.egg82.antivpn.external.io.ebean.ProfileLocation;
import me.egg82.antivpn.external.io.ebean.Query;
import me.egg82.antivpn.external.io.ebean.Transaction;
import me.egg82.antivpn.external.io.ebean.typequery.AlreadyEnhancedMarker;
import me.egg82.antivpn.external.io.ebean.typequery.PInstant;
import me.egg82.antivpn.external.io.ebean.typequery.PLong;
import me.egg82.antivpn.external.io.ebean.typequery.PString;
import me.egg82.antivpn.external.io.ebean.typequery.TQRootBean;
import me.egg82.antivpn.external.io.ebean.typequery.TypeQueryBean;
import me.egg82.antivpn.storage.models.DataModel;

@TypeQueryBean(value="v1")
@AlreadyEnhancedMarker
public class QDataModel
extends TQRootBean<DataModel, QDataModel> {
    private static final QDataModel _alias;
    public PLong<QDataModel> id;
    public PLong<QDataModel> version;
    public PInstant<QDataModel> created;
    public PInstant<QDataModel> modified;
    public PString<QDataModel> key;
    public PString<QDataModel> value;
    private static /* synthetic */ ProfileLocation _$ebpq0;

    public static QDataModel alias() {
        return _alias;
    }

    public static QDataModel forFetchGroup() {
        return (QDataModel)new QDataModel((Query<DataModel>)FetchGroup.queryFor(DataModel.class)).setProfileLocation(_$ebpq0);
    }

    public QDataModel() {
        super(DataModel.class);
    }

    public QDataModel(Transaction transaction) {
        super(DataModel.class, transaction);
    }

    public QDataModel(Database database) {
        super(DataModel.class, database);
    }

    private QDataModel(boolean alias) {
        super(alias);
        this.setRoot(this);
        this.id = new PLong<QDataModel>("id", this);
        this.version = new PLong<QDataModel>("version", this);
        this.created = new PInstant<QDataModel>("created", this);
        this.modified = new PInstant<QDataModel>("modified", this);
        this.key = new PString<QDataModel>("key", this);
        this.value = new PString<QDataModel>("value", this);
    }

    private QDataModel(Query<DataModel> fetchGroupQuery) {
        super(fetchGroupQuery);
    }

    static /* synthetic */ QDataModel access$000() {
        return _alias;
    }

    static {
        QDataModel._$ebpq0 = ProfileLocation.create();
        _alias = new QDataModel(true);
    }

    public PLong<QDataModel> _id() {
        if (this.id == null) {
            this.id = new PLong<QDataModel>("id", this);
        }
        return this.id;
    }

    public PLong<QDataModel> _version() {
        if (this.version == null) {
            this.version = new PLong<QDataModel>("version", this);
        }
        return this.version;
    }

    public PInstant<QDataModel> _created() {
        if (this.created == null) {
            this.created = new PInstant<QDataModel>("created", this);
        }
        return this.created;
    }

    public PInstant<QDataModel> _modified() {
        if (this.modified == null) {
            this.modified = new PInstant<QDataModel>("modified", this);
        }
        return this.modified;
    }

    public PString<QDataModel> _key() {
        if (this.key == null) {
            this.key = new PString<QDataModel>("key", this);
        }
        return this.key;
    }

    public PString<QDataModel> _value() {
        if (this.value == null) {
            this.value = new PString<QDataModel>("value", this);
        }
        return this.value;
    }

    public static class Alias {
        public static PLong<QDataModel> id = QDataModel.access$000()._id();
        public static PLong<QDataModel> version = QDataModel.access$000()._version();
        public static PInstant<QDataModel> created = QDataModel.access$000()._created();
        public static PInstant<QDataModel> modified = QDataModel.access$000()._modified();
        public static PString<QDataModel> key = QDataModel.access$000()._key();
        public static PString<QDataModel> value = QDataModel.access$000()._value();
    }
}

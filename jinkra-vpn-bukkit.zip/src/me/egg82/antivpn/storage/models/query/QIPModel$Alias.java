/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.storage.models.query;

import me.egg82.antivpn.external.io.ebean.typequery.PBoolean;
import me.egg82.antivpn.external.io.ebean.typequery.PDouble;
import me.egg82.antivpn.external.io.ebean.typequery.PInstant;
import me.egg82.antivpn.external.io.ebean.typequery.PInteger;
import me.egg82.antivpn.external.io.ebean.typequery.PLong;
import me.egg82.antivpn.external.io.ebean.typequery.PString;
import me.egg82.antivpn.storage.models.query.QIPModel;

public static class QIPModel.Alias {
    public static PLong<QIPModel> id = QIPModel.access$000()._id();
    public static PLong<QIPModel> version = QIPModel.access$000()._version();
    public static PInstant<QIPModel> created = QIPModel.access$000()._created();
    public static PInstant<QIPModel> modified = QIPModel.access$000()._modified();
    public static PString<QIPModel> ip = QIPModel.access$000()._ip();
    public static PInteger<QIPModel> type = QIPModel.access$000()._type();
    public static PBoolean<QIPModel> cascade = QIPModel.access$000()._cascade();
    public static PDouble<QIPModel> consensus = QIPModel.access$000()._consensus();
}

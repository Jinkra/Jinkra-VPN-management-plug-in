/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.storage;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.util.Properties;
import me.egg82.antivpn.external.com.zaxxer.hikari.HikariConfig;
import me.egg82.antivpn.external.io.ebean.config.dbplatform.sqlite.SQLitePlatform;
import me.egg82.antivpn.storage.SQLiteStorageService;
import org.checkerframework.checker.nullness.qual.NonNull;

public static class SQLiteStorageService.Builder {
    private final SQLiteStorageService service;
    private final HikariConfig config = new HikariConfig();

    private SQLiteStorageService.Builder(@NonNull String name) {
        this.service = new SQLiteStorageService(name, null);
        this.config.setPoolName("AntiVPN-SQLite");
        this.config.setDriverClassName("org.sqlite.JDBC");
        this.config.setConnectionTestQuery("SELECT 1;");
        this.config.addDataSourceProperty("useLegacyDatetimeCode", "false");
        this.config.addDataSourceProperty("serverTimezone", "UTC");
    }

    public SQLiteStorageService.Builder file(@NonNull File file) {
        this.config.setJdbcUrl("jdbc:sqlite:" + file.getAbsolutePath());
        return this;
    }

    public SQLiteStorageService.Builder options(@NonNull String options) throws IOException {
        options = !options.isEmpty() && options.charAt(0) == '?' ? options.substring(1) : options;
        Properties p = new Properties();
        p.load(new StringReader(options.replace("&", "\n")));
        this.config.setDataSourceProperties(p);
        return this;
    }

    public SQLiteStorageService.Builder poolSize(int min, int max) {
        this.config.setMaximumPoolSize(max);
        this.config.setMinimumIdle(min);
        return this;
    }

    public SQLiteStorageService.Builder life(long lifetime, long timeout) {
        this.config.setMaxLifetime(lifetime);
        this.config.setConnectionTimeout(timeout);
        return this;
    }

    public @NonNull SQLiteStorageService build() {
        this.service.createSource(this.config, new SQLitePlatform(), true, "sqlite");
        return this.service;
    }
}

/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  me.egg82.antivpn.external.inet.ipaddr.AddressStringException
 *  me.egg82.antivpn.external.inet.ipaddr.IPAddressString
 */
package me.egg82.antivpn.utils;

import java.util.regex.Pattern;
import me.egg82.antivpn.external.inet.ipaddr.AddressStringException;
import me.egg82.antivpn.external.inet.ipaddr.IPAddressString;

public class ValidationUtil {
    private static final Pattern uuidValidator = Pattern.compile("^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", 2);

    private ValidationUtil() {
    }

    public static boolean isValidIpRange(String range) {
        if (range == null || range.isEmpty()) {
            return false;
        }
        try {
            return new IPAddressString(range).toAddress().isMultiple();
        }
        catch (AddressStringException ignored) {
            return false;
        }
    }

    public static boolean isValidIp(String ip) {
        if (ip == null || ip.isEmpty()) {
            return false;
        }
        try {
            return !new IPAddressString(ip).toAddress().isMultiple();
        }
        catch (AddressStringException ignored) {
            return false;
        }
    }

    public static boolean isValidUuid(String uuid) {
        if (uuid == null || uuid.isEmpty()) {
            return false;
        }
        return uuidValidator.matcher(uuid).matches();
    }
}

/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.utils;

public class LogUtil {
    public static final String HEADING = "<c2>[</c2><c3>Anti-VPN</c3><c2>]</c2> ";

    private LogUtil() {
    }
}

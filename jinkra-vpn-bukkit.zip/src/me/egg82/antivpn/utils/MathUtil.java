/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  me.egg82.antivpn.external.it.unimi.dsi.fastutil.ints.IntArrays
 *  me.egg82.antivpn.external.it.unimi.dsi.fastutil.ints.IntList
 */
package me.egg82.antivpn.utils;

import me.egg82.antivpn.external.it.unimi.dsi.fastutil.ints.IntArrays;
import me.egg82.antivpn.external.it.unimi.dsi.fastutil.ints.IntList;

public class MathUtil {
    private MathUtil() {
    }

    public static int percentile(IntList list, double percentile) {
        int[] sorted = list.toIntArray();
        IntArrays.quickSort((int[])sorted);
        int index = (int)Math.ceil(percentile / (100.0 * (double)sorted.length));
        return sorted[index - 1];
    }
}

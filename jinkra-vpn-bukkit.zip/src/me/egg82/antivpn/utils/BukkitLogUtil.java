/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.bukkit.ChatColor
 */
package me.egg82.antivpn.utils;

import org.bukkit.ChatColor;

public class BukkitLogUtil {
    public static final String HEADING = ChatColor.YELLOW + "[" + ChatColor.AQUA + "Anti-VPN" + ChatColor.YELLOW + "] " + ChatColor.RESET;

    private BukkitLogUtil() {
    }
}

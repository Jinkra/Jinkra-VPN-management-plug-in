/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.utils;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.Map;
import me.egg82.antivpn.config.ConfigUtil;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class WebUtil {
    private static final Logger logger = LoggerFactory.getLogger(WebUtil.class);

    private WebUtil() {
    }

    public static @NonNull String urlEncode(@NonNull String part) {
        try {
            return URLEncoder.encode(part, StandardCharsets.UTF_8.toString());
        }
        catch (UnsupportedEncodingException ignored) {
            try {
                return URLEncoder.encode(part, StandardCharsets.US_ASCII.toString());
            }
            catch (UnsupportedEncodingException ignored2) {
                return part;
            }
        }
    }

    public static @NonNull String getString(@NonNull URL url) throws IOException {
        return WebUtil.getString(url, null, 5000, null, null, null, 20);
    }

    public static @NonNull String getString(@NonNull URL url, String method) throws IOException {
        return WebUtil.getString(url, method, 5000, null, null, null, 20);
    }

    public static @NonNull String getString(@NonNull URL url, String method, int timeout) throws IOException {
        return WebUtil.getString(url, method, timeout, null, null, null, 20);
    }

    public static @NonNull String getString(@NonNull URL url, String method, int timeout, String userAgent) throws IOException {
        return WebUtil.getString(url, method, timeout, userAgent, null, null, 20);
    }

    public static @NonNull String getString(@NonNull URL url, String method, int timeout, String userAgent, Map<String, String> headers) throws IOException {
        return WebUtil.getString(url, method, timeout, userAgent, headers, null, 20);
    }

    public static @NonNull String getString(@NonNull URL url, String method, int timeout, String userAgent, Map<String, String> headers, Map<String, String> postData) throws IOException {
        return WebUtil.getString(url, method, timeout, userAgent, headers, postData, 20);
    }

    /*
     * Exception decompiling
     */
    public static @NonNull String getString(@NonNull URL url, String method, int timeout, String userAgent, Map<String, String> headers, Map<String, String> postData, int maxRedirects) throws IOException {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Started 4 blocks at once
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.getStartingBlocks(Op04StructuredStatement.java:412)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:487)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:845)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1042)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:929)
         *     at org.benf.cfr.reader.Driver.doClass(Driver.java:84)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:75)
         *     at org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    public static @NonNull String getStringWithThrows(@NonNull URL url) throws IOException {
        return WebUtil.getStringWithThrows(url, null, 5000, null, null, null, 20);
    }

    public static @NonNull String getStringWithThrows(@NonNull URL url, String method) throws IOException {
        return WebUtil.getStringWithThrows(url, method, 5000, null, null, null, 20);
    }

    public static @NonNull String getStringWithThrows(@NonNull URL url, String method, int timeout) throws IOException {
        return WebUtil.getStringWithThrows(url, method, timeout, null, null, null, 20);
    }

    public static @NonNull String getStringWithThrows(@NonNull URL url, String method, int timeout, String userAgent) throws IOException {
        return WebUtil.getStringWithThrows(url, method, timeout, userAgent, null, null, 20);
    }

    public static @NonNull String getStringWithThrows(@NonNull URL url, String method, int timeout, String userAgent, Map<String, String> headers) throws IOException {
        return WebUtil.getStringWithThrows(url, method, timeout, userAgent, headers, null, 20);
    }

    public static @NonNull String getStringWithThrows(@NonNull URL url, String method, int timeout, String userAgent, Map<String, String> headers, Map<String, String> postData) throws IOException {
        return WebUtil.getStringWithThrows(url, method, timeout, userAgent, headers, postData, 20);
    }

    /*
     * Exception decompiling
     */
    public static @NonNull String getStringWithThrows(@NonNull URL url, String method, int timeout, String userAgent, Map<String, String> headers, Map<String, String> postData, int maxRedirects) throws IOException {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Started 4 blocks at once
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.getStartingBlocks(Op04StructuredStatement.java:412)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:487)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:845)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1042)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:929)
         *     at org.benf.cfr.reader.Driver.doClass(Driver.java:84)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:75)
         *     at org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    public static @NonNull String getString(@NonNull HttpURLConnection conn) throws IOException {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Started 4 blocks at once
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.getStartingBlocks(Op04StructuredStatement.java:412)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:487)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:845)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1042)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:929)
         *     at org.benf.cfr.reader.Driver.doClass(Driver.java:84)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:75)
         *     at org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    public static byte @NonNull [] getBytes(@NonNull URL url) throws IOException {
        return WebUtil.getBytes(url, null, 5000, null, null, null, 20);
    }

    public static byte @NonNull [] getBytes(@NonNull URL url, String method) throws IOException {
        return WebUtil.getBytes(url, method, 5000, null, null, null, 20);
    }

    public static byte @NonNull [] getBytes(@NonNull URL url, String method, int timeout) throws IOException {
        return WebUtil.getBytes(url, method, timeout, null, null, null, 20);
    }

    public static byte @NonNull [] getBytes(@NonNull URL url, String method, int timeout, String userAgent) throws IOException {
        return WebUtil.getBytes(url, method, timeout, userAgent, null, null, 20);
    }

    public static byte @NonNull [] getBytes(@NonNull URL url, String method, int timeout, String userAgent, Map<String, String> headers) throws IOException {
        return WebUtil.getBytes(url, method, timeout, userAgent, headers, null, 20);
    }

    public static byte @NonNull [] getBytes(@NonNull URL url, String method, int timeout, String userAgent, Map<String, String> headers, Map<String, String> postData) throws IOException {
        return WebUtil.getBytes(url, method, timeout, userAgent, headers, postData, 20);
    }

    /*
     * Exception decompiling
     */
    public static byte @NonNull [] getBytes(@NonNull URL url, String method, int timeout, String userAgent, Map<String, String> headers, Map<String, String> postData, int maxRedirects) throws IOException {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Started 2 blocks at once
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.getStartingBlocks(Op04StructuredStatement.java:412)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:487)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:845)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1042)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:929)
         *     at org.benf.cfr.reader.Driver.doClass(Driver.java:84)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:75)
         *     at org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    public static byte @NonNull [] getBytesWithThrows(@NonNull URL url) throws IOException {
        return WebUtil.getBytesWithThrows(url, null, 5000, null, null, null, 20);
    }

    public static byte @NonNull [] getBytesWithThrows(@NonNull URL url, String method) throws IOException {
        return WebUtil.getBytesWithThrows(url, method, 5000, null, null, null, 20);
    }

    public static byte @NonNull [] getBytesWithThrows(@NonNull URL url, String method, int timeout) throws IOException {
        return WebUtil.getBytesWithThrows(url, method, timeout, null, null, null, 20);
    }

    public static byte @NonNull [] getBytesWithThrows(@NonNull URL url, String method, int timeout, String userAgent) throws IOException {
        return WebUtil.getBytesWithThrows(url, method, timeout, userAgent, null, null, 20);
    }

    public static byte @NonNull [] getBytesWithThrows(@NonNull URL url, String method, int timeout, String userAgent, Map<String, String> headers) throws IOException {
        return WebUtil.getBytesWithThrows(url, method, timeout, userAgent, headers, null, 20);
    }

    public static byte @NonNull [] getBytesWithThrows(@NonNull URL url, String method, int timeout, String userAgent, Map<String, String> headers, Map<String, String> postData) throws IOException {
        return WebUtil.getBytesWithThrows(url, method, timeout, userAgent, headers, postData, 20);
    }

    /*
     * Exception decompiling
     */
    public static byte @NonNull [] getBytesWithThrows(@NonNull URL url, String method, int timeout, String userAgent, Map<String, String> headers, Map<String, String> postData, int maxRedirects) throws IOException {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Started 2 blocks at once
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.getStartingBlocks(Op04StructuredStatement.java:412)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:487)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:845)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1042)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:929)
         *     at org.benf.cfr.reader.Driver.doClass(Driver.java:84)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:75)
         *     at org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    public static byte @NonNull [] getBytes(HttpURLConnection conn) throws IOException {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Started 2 blocks at once
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.getStartingBlocks(Op04StructuredStatement.java:412)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:487)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:845)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1042)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:929)
         *     at org.benf.cfr.reader.Driver.doClass(Driver.java:84)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:75)
         *     at org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    public static @NonNull HttpURLConnection getConnection(@NonNull URL url) throws IOException {
        return WebUtil.getConnection(url, null, 5000, null, null, null, 20);
    }

    public static @NonNull HttpURLConnection getConnection(@NonNull URL url, String method) throws IOException {
        return WebUtil.getConnection(url, method, 5000, null, null, null, 20);
    }

    public static @NonNull HttpURLConnection getConnection(@NonNull URL url, String method, int timeout) throws IOException {
        return WebUtil.getConnection(url, method, timeout, null, null, null, 20);
    }

    public static @NonNull HttpURLConnection getConnection(@NonNull URL url, String method, int timeout, String userAgent) throws IOException {
        return WebUtil.getConnection(url, method, timeout, userAgent, null, null, 20);
    }

    public static @NonNull HttpURLConnection getConnection(@NonNull URL url, String method, int timeout, String userAgent, Map<String, String> headers) throws IOException {
        return WebUtil.getConnection(url, method, timeout, userAgent, headers, null, 20);
    }

    public static @NonNull HttpURLConnection getConnection(@NonNull URL url, String method, int timeout, String userAgent, Map<String, String> headers, Map<String, String> postData) throws IOException {
        return WebUtil.getConnection(url, method, timeout, userAgent, headers, postData, 20);
    }

    public static @NonNull HttpURLConnection getConnection(@NonNull URL url, String method, int timeout, String userAgent, Map<String, String> headers, Map<String, String> postData, int maxRedirects) throws IOException {
        boolean redirect;
        if (ConfigUtil.getDebugOrFalse()) {
            logger.info("Fetching URL: " + url);
        }
        HttpURLConnection conn = (HttpURLConnection)url.openConnection();
        WebUtil.setConnectionProperties(conn, method, timeout, userAgent, headers, postData, null);
        HashSet<String> previousUrls = new HashSet<String>();
        previousUrls.add(url.toExternalForm() + (headers != null && headers.containsKey("Set-Cookie") ? ":" + headers.get("Set-Cookie") : ""));
        do {
            int status;
            boolean bl = redirect = (status = conn.getResponseCode()) == 302 || status == 301 || status == 303;
            if (!redirect) continue;
            String cookies = conn.getHeaderField("Set-Cookie");
            String newUrl = conn.getHeaderField("Location");
            if (newUrl.charAt(0) == '/') {
                newUrl = new URL(url.getProtocol(), url.getHost(), url.getPort(), newUrl, null).toExternalForm();
            }
            if (!previousUrls.add(newUrl + (cookies != null ? ":" + cookies : ""))) {
                throw new IOException("Recursive redirect detected.");
            }
            if (maxRedirects >= 0 && previousUrls.size() > maxRedirects) {
                throw new IOException("Too many redirects.");
            }
            if (ConfigUtil.getDebugOrFalse()) {
                logger.info("Redirected to URL: " + newUrl);
            }
            conn = (HttpURLConnection)new URL(newUrl).openConnection();
            WebUtil.setConnectionProperties(conn, method, timeout, userAgent, headers, postData, cookies);
        } while (redirect);
        return conn;
    }

    private static void setConnectionProperties(@NonNull HttpURLConnection conn, String method, int timeout, String userAgent, Map<String, String> headers, Map<String, String> postData, String cookies) throws IOException {
        conn.setInstanceFollowRedirects(false);
        conn.setConnectTimeout(timeout);
        conn.setReadTimeout(timeout);
        if (method != null && !method.isEmpty()) {
            conn.setRequestMethod(method);
        }
        if (userAgent != null && !userAgent.isEmpty()) {
            conn.setRequestProperty("User-Agent", userAgent);
        }
        if (headers != null && !headers.isEmpty()) {
            for (Map.Entry<String, String> entry : headers.entrySet()) {
                conn.setRequestProperty(entry.getKey(), entry.getValue());
            }
        }
        if (cookies != null && !cookies.isEmpty()) {
            conn.setRequestProperty("Cookie", cookies);
        }
        if (postData != null) {
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
            StringBuilder data = new StringBuilder();
            for (Map.Entry<String, String> entry : postData.entrySet()) {
                data.append(URLEncoder.encode(entry.getKey(), StandardCharsets.UTF_8.name()));
                data.append('=');
                data.append(URLEncoder.encode(entry.getValue(), StandardCharsets.UTF_8.name()));
                data.append('&');
            }
            if (data.length() > 0) {
                data.deleteCharAt(data.length() - 1);
            }
            byte[] byArray = data.toString().getBytes(StandardCharsets.UTF_8);
            conn.setRequestProperty("Content-Length", String.valueOf(byArray.length));
            conn.setDoOutput(true);
            try (OutputStream outputStream = conn.getOutputStream();){
                outputStream.write(byArray);
            }
        }
    }

    public static @NonNull HttpURLConnection getConnectionWithThrows(@NonNull URL url) throws IOException {
        return WebUtil.getConnectionWithThrows(url, null, 5000, null, null, null, 20);
    }

    public static @NonNull HttpURLConnection getConnectionWithThrows(@NonNull URL url, String method) throws IOException {
        return WebUtil.getConnectionWithThrows(url, method, 5000, null, null, null, 20);
    }

    public static @NonNull HttpURLConnection getConnectionWithThrows(@NonNull URL url, String method, int timeout) throws IOException {
        return WebUtil.getConnectionWithThrows(url, method, timeout, null, null, null, 20);
    }

    public static @NonNull HttpURLConnection getConnectionWithThrows(@NonNull URL url, String method, int timeout, String userAgent) throws IOException {
        return WebUtil.getConnectionWithThrows(url, method, timeout, userAgent, null, null, 20);
    }

    public static @NonNull HttpURLConnection getConnectionWithThrows(@NonNull URL url, String method, int timeout, String userAgent, Map<String, String> headers) throws IOException {
        return WebUtil.getConnectionWithThrows(url, method, timeout, userAgent, headers, null, 20);
    }

    public static @NonNull HttpURLConnection getConnectionWithThrows(@NonNull URL url, String method, int timeout, String userAgent, Map<String, String> headers, Map<String, String> postData) throws IOException {
        return WebUtil.getConnectionWithThrows(url, method, timeout, userAgent, headers, postData, 20);
    }

    public static @NonNull HttpURLConnection getConnectionWithThrows(@NonNull URL url, String method, int timeout, String userAgent, Map<String, String> headers, Map<String, String> postData, int maxRedirects) throws IOException {
        HttpURLConnection conn = WebUtil.getConnection(url, method, timeout, userAgent, headers, postData, maxRedirects);
        int status = conn.getResponseCode();
        if (status >= 200 && status < 300) {
            if (status == 205) {
                throw new IOException("Could not get connection (HTTP status " + status + " - reset connection)");
            }
            return conn;
        }
        if (status >= 400 && status < 500) {
            if (status == 401 || status == 403) {
                throw new IOException("Could not get connection (HTTP status " + status + " - access denied)");
            }
            if (status == 429) {
                throw new IOException("Could not get connection (HTTP status " + status + " - too many queries, temporary issue)");
            }
            throw new IOException("Could not get connection (HTTP status " + status + ")");
        }
        if (status >= 500 && status < 600) {
            throw new IOException("Could not get connection (HTTP status " + status + ")");
        }
        throw new IOException("Could not get connection (HTTP status " + status + ")");
    }

    public static @NonNull InputStream getInputStream(@NonNull URL url) throws IOException {
        return WebUtil.getInputStream(url, null, 5000, null, null, null, 20);
    }

    public static @NonNull InputStream getInputStream(@NonNull URL url, String method) throws IOException {
        return WebUtil.getInputStream(url, method, 5000, null, null, null, 20);
    }

    public static @NonNull InputStream getInputStream(@NonNull URL url, String method, int timeout) throws IOException {
        return WebUtil.getInputStream(url, method, timeout, null, null, null, 20);
    }

    public static @NonNull InputStream getInputStream(@NonNull URL url, String method, int timeout, String userAgent) throws IOException {
        return WebUtil.getInputStream(url, method, timeout, userAgent, null, null, 20);
    }

    public static @NonNull InputStream getInputStream(@NonNull URL url, String method, int timeout, String userAgent, Map<String, String> headers) throws IOException {
        return WebUtil.getInputStream(url, method, timeout, userAgent, headers, null, 20);
    }

    public static @NonNull InputStream getInputStream(@NonNull URL url, String method, int timeout, String userAgent, Map<String, String> headers, Map<String, String> postData) throws IOException {
        return WebUtil.getInputStream(url, method, timeout, userAgent, headers, postData, 20);
    }

    public static @NonNull InputStream getInputStream(@NonNull URL url, String method, int timeout, String userAgent, Map<String, String> headers, Map<String, String> postData, int maxRedirects) throws IOException {
        HttpURLConnection conn = WebUtil.getConnection(url, method, timeout, userAgent, headers, postData, maxRedirects);
        int status = conn.getResponseCode();
        if (status >= 400 && status < 600) {
            throw new IOException("Server returned status code " + status);
        }
        return conn.getInputStream();
    }

    public static @NonNull InputStream getInputStreamWithThrows(@NonNull URL url) throws IOException {
        return WebUtil.getInputStreamWithThrows(url, null, 5000, null, null, null, 20);
    }

    public static @NonNull InputStream getInputStreamWithThrows(@NonNull URL url, String method) throws IOException {
        return WebUtil.getInputStreamWithThrows(url, method, 5000, null, null, null, 20);
    }

    public static @NonNull InputStream getInputStreamWithThrows(@NonNull URL url, String method, int timeout) throws IOException {
        return WebUtil.getInputStreamWithThrows(url, method, timeout, null, null, null, 20);
    }

    public static @NonNull InputStream getInputStreamWithThrows(@NonNull URL url, String method, int timeout, String userAgent) throws IOException {
        return WebUtil.getInputStreamWithThrows(url, method, timeout, userAgent, null, null, 20);
    }

    public static @NonNull InputStream getInputStreamWithThrows(@NonNull URL url, String method, int timeout, String userAgent, Map<String, String> headers) throws IOException {
        return WebUtil.getInputStreamWithThrows(url, method, timeout, userAgent, headers, null, 20);
    }

    public static @NonNull InputStream getInputStreamWithThrows(@NonNull URL url, String method, int timeout, String userAgent, Map<String, String> headers, Map<String, String> postData) throws IOException {
        return WebUtil.getInputStreamWithThrows(url, method, timeout, userAgent, headers, postData, 20);
    }

    public static @NonNull InputStream getInputStreamWithThrows(@NonNull URL url, String method, int timeout, String userAgent, Map<String, String> headers, Map<String, String> postData, int maxRedirects) throws IOException {
        HttpURLConnection conn = WebUtil.getConnectionWithThrows(url, method, timeout, userAgent, headers, postData, maxRedirects);
        int status = conn.getResponseCode();
        if (status >= 400 && status < 600) {
            throw new IOException("Server returned status code " + status);
        }
        return conn.getInputStream();
    }

    public static @NonNull InputStream getInputStream(@NonNull HttpURLConnection conn) throws IOException {
        int status = conn.getResponseCode();
        if (status >= 400 && status < 600) {
            throw new IOException("Server returned status code " + status);
        }
        return conn.getInputStream();
    }

    private static boolean hasKey(@NonNull Map<String, String> map, @NonNull String key) {
        for (String k : map.keySet()) {
            if (!k.equalsIgnoreCase(key)) continue;
            return true;
        }
        return false;
    }
}

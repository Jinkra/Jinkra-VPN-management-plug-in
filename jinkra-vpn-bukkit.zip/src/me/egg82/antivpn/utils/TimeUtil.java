/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.utils;

import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.checkerframework.checker.nullness.qual.Nullable;

public class TimeUtil {
    private static final Pattern timePattern = Pattern.compile("^(\\d+)\\s*(?:seconds?|s|minutes?|m|hours?|h|days?|d)$");
    private static final Pattern unitPattern = Pattern.compile("^(?:\\d+)\\s*(seconds?|s|minutes?|m|hours?|h|days?|d)$");

    private TimeUtil() {
    }

    public static @Nullable Time getTime(@NonNull String input) {
        Matcher timeMatcher = timePattern.matcher(input);
        if (!timeMatcher.matches()) {
            return null;
        }
        Matcher unitMatcher = unitPattern.matcher(input);
        if (!unitMatcher.matches()) {
            return null;
        }
        long time = Long.parseLong(timeMatcher.group(1));
        char unit = unitMatcher.group(1).charAt(0);
        switch (unit) {
            case 's': {
                return new Time(time, TimeUnit.SECONDS);
            }
            case 'm': {
                return new Time(time, TimeUnit.MINUTES);
            }
            case 'h': {
                return new Time(time, TimeUnit.HOURS);
            }
            case 'd': {
                return new Time(time, TimeUnit.DAYS);
            }
        }
        return null;
    }

    public static @Nullable String getTimeString(@NonNull Time time) {
        if (time.unit == TimeUnit.DAYS) {
            return time.time + (time.time == 1L ? "day" : "days");
        }
        if (time.unit == TimeUnit.HOURS) {
            return time.time + (time.time == 1L ? "hour" : "hours");
        }
        if (time.unit == TimeUnit.MINUTES) {
            return time.time + (time.time == 1L ? "minute" : "minutes");
        }
        if (time.unit == TimeUnit.SECONDS) {
            return time.time + (time.time == 1L ? "second" : "seconds");
        }
        return null;
    }

    public static class Time {
        private final long time;
        private final TimeUnit unit;
        private final int hc;

        public Time(long time, @NonNull TimeUnit unit) {
            this.time = time;
            this.unit = unit;
            this.hc = Objects.hash(new Object[]{time, unit});
        }

        public long getTime() {
            return this.time;
        }

        public TimeUnit getUnit() {
            return this.unit;
        }

        public long getMillis() {
            return this.unit.toMillis(this.time);
        }

        public boolean equals(Object o) {
            if (this == o) {
                return true;
            }
            if (!(o instanceof Time)) {
                return false;
            }
            Time time1 = (Time)o;
            return this.time == time1.time && this.unit == time1.unit;
        }

        public int hashCode() {
            return this.hc;
        }
    }
}

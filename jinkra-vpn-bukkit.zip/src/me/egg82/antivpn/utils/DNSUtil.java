/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  me.egg82.antivpn.external.com.github.benmanes.caffeine.cache.Caffeine
 *  me.egg82.antivpn.external.com.github.benmanes.caffeine.cache.LoadingCache
 *  me.egg82.antivpn.external.inet.ipaddr.IPAddress
 *  me.egg82.antivpn.external.inet.ipaddr.IPAddressString
 */
package me.egg82.antivpn.utils;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import javax.naming.directory.InitialDirContext;
import me.egg82.antivpn.config.ConfigUtil;
import me.egg82.antivpn.external.com.github.benmanes.caffeine.cache.Caffeine;
import me.egg82.antivpn.external.com.github.benmanes.caffeine.cache.LoadingCache;
import me.egg82.antivpn.external.inet.ipaddr.IPAddress;
import me.egg82.antivpn.external.inet.ipaddr.IPAddressString;
import me.egg82.antivpn.utils.ValidationUtil;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DNSUtil {
    private static final Logger logger = LoggerFactory.getLogger(DNSUtil.class);
    private static LoadingCache<String, Set<String>> validNordVpn = Caffeine.newBuilder().build(DNSUtil::findNordVpn);
    private static LoadingCache<String, Set<String>> records = Caffeine.newBuilder().build(DNSUtil::collectRecords);

    private DNSUtil() {
    }

    public static @NonNull Set<String> getNordVpnIps() {
        HashSet dns = new HashSet();
        dns.addAll((Collection)validNordVpn.get((Object)"al{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"ar{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"au{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"at{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"be{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"ba{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"br{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"bg{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"ca{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"cl{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"cr{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"hr{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"cy{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"cz{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"dk{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"ee{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"fi{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"fr{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"ge{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"de{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"gr{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"hk{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"hu{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"is{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"in{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"id{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"il{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"it{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"jp{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"lv{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"lu{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"my{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"mx{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"md{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"nl{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"nz{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"mk{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"no{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"pl{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"pt{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"ro{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"rs{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"sg{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"sk{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"si{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"za{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"kr{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"es{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"se{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"ch{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"tw{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"th{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"tr{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"ua{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"uk{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"us{}.nordvpn.com"));
        dns.addAll((Collection)validNordVpn.get((Object)"vn{}.nordvpn.com"));
        return DNSUtil.getIps(dns.toArray(new String[0]), 50);
    }

    private static @NonNull Set<String> findNordVpn(@NonNull String dns) {
        if (ConfigUtil.getDebugOrFalse()) {
            logger.info("Building NordVPN set " + dns.replace("{}", ""));
        }
        HashSet<String> retVal = new HashSet<String>();
        for (int i = 0; i < 50; ++i) {
            try {
                String name = dns.replace("{}", String.valueOf(i));
                InetAddress.getByName(name);
                retVal.add(name);
                continue;
            }
            catch (UnknownHostException unknownHostException) {
                // empty catch block
            }
        }
        if (ConfigUtil.getDebugOrFalse()) {
            logger.info("Got " + retVal.size() + " value(s) for NordVPN set " + dns.replace("{}", ""));
        }
        return retVal;
    }

    public static @NonNull Set<String> getCryptostormIps() {
        String[] dns = new String[]{"balancer.cstorm.is", "balancer.cstorm.net", "balancer.cryptostorm.ch", "balancer.cryptostorm.pw"};
        return DNSUtil.getIps(dns, 50);
    }

    private static @NonNull Set<String> collectRecords(@NonNull String dns) {
        if (ConfigUtil.getDebugOrFalse()) {
            logger.info("Collecting A records for " + dns);
        }
        HashSet<String> retVal = new HashSet<String>();
        try {
            InitialDirContext context = new InitialDirContext();
            Attributes attributes = context.getAttributes("dns:/" + dns, new String[]{"A"});
            NamingEnumeration<?> attributeEnum = attributes.get("A").getAll();
            while (attributeEnum.hasMore()) {
                retVal.add(attributeEnum.next().toString());
            }
        }
        catch (NamingException ex) {
            logger.error(ex.getMessage(), ex);
        }
        if (ConfigUtil.getDebugOrFalse()) {
            logger.info("Got " + retVal.size() + " record(s) for " + dns);
        }
        return retVal;
    }

    public static @NonNull Set<String> getHomeIps() {
        String[] dns = new String[]{"24.0.0.0/12", "24.16.0.0/13", "24.30.0.0/17", "24.34.0.0/16", "24.60.0.0/14", "24.91.0.0/16", "24.98.0.0/15", "24.118.0.0/16", "24.125.0.0/16", "24.126.0.0/15", "24.128.0.0/16", "24.129.0.0/17", "24.130.0.0/15", "24.147.0.0/16", "24.218.0.0/16", "24.245.0.0/18", "50.128.0.0/10", "65.34.128.0/17", "65.96.0.0/16", "66.30.0.0/15", "66.41.0.0/16", "66.56.0.0/18", "66.176.0.0/15", "66.229.0.0/16", "67.160.0.0/12", "67.176.0.0/15", "67.180.0.0/14", "67.184.0.0/13", "68.32.0.0/11", "68.80.0.0/14", "68.84.0.0/16", "69.136.0.0/15", "69.138.0.0/16", "69.139.0.0/17", "69.140.0.0/14", "69.180.0.0/15", "69.242.0.0/15", "69.244.0.0/14", "69.248.0.0/14", "69.253.0.0/16", "69.254.0.0/15", "71.56.0.0/13", "71.192.0.0/12", "71.224.0.0/12", "73.0.0.0/8", "75.64.0.0/13", "75.72.0.0/15", "75.74.0.0/16", "75.75.0.0/17", "75.75.128.0/18", "76.16.0.0/12", "76.97.0.0/16", "76.98.0.0/15", "76.100.0.0/14", "76.104.0.0/13", "76.112.0.0/12", "98.192.0.0/13", "98.200.0.0/14", "98.204.0.0/16", "98.206.0.0/15", "98.208.0.0/12", "98.224.0.0/12", "98.240.0.0/16", "98.242.0.0/15", "98.244.0.0/14", "98.248.0.0/13", "107.2.0.0/15", "107.4.0.0/15", "174.48.0.0/12", "2001:558:6000::/36"};
        return DNSUtil.getIps(dns, 50);
    }

    private static @NonNull Set<String> getIps(String[] dns, int count) {
        HashSet<String> retVal = new HashSet<String>();
        int fails = 0;
        while (retVal.size() < count && fails < 1000) {
            String name;
            while ((name = dns[(int)DNSUtil.fairRoundedRandom(0L, (long)dns.length - 1L)]) == null) {
            }
            if (ValidationUtil.isValidIp(name)) {
                if (retVal.add(name)) continue;
                ++fails;
                continue;
            }
            if (ValidationUtil.isValidIpRange(name)) {
                if (retVal.addAll(DNSUtil.getIps(name, 1))) continue;
                ++fails;
                continue;
            }
            ArrayList r = new ArrayList((Collection)records.get((Object)name));
            if (r.isEmpty() || retVal.add((String)r.get((int)DNSUtil.fairRoundedRandom(0L, (long)r.size() - 1L)))) continue;
            ++fails;
        }
        return retVal;
    }

    private static @NonNull Set<String> getIps(@NonNull String mask, int count) {
        HashSet<String> retVal = new HashSet<String>();
        IPAddress range = new IPAddressString(mask).getAddress();
        int fails = 0;
        block0: while (retVal.size() < count && fails < 1000) {
            long getIndex = DNSUtil.fairRoundedRandom(0L, range.getCount().longValue());
            long i = 0L;
            for (IPAddress ip : range.getIterable()) {
                if (i == getIndex) {
                    String str = ip.toCanonicalString();
                    int idx = str.indexOf(47);
                    if (idx > -1) {
                        str = str.substring(0, idx);
                    }
                    if (!retVal.add(str)) {
                        ++fails;
                    }
                    if (retVal.size() >= count || fails >= 1000 || (getIndex = DNSUtil.fairRoundedRandom(0L, range.getCount().longValue())) <= i) continue block0;
                }
                ++i;
            }
        }
        return retVal;
    }

    private static long fairRoundedRandom(long min, long max) {
        long num;
        while ((num = (long)Math.floor(Math.random() * (double)(++max - min) + (double)min)) > max - 1L) {
        }
        return num;
    }
}

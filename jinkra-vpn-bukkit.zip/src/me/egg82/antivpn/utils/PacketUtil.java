/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.google.common.util.concurrent.ThreadFactoryBuilder
 *  me.egg82.antivpn.external.it.unimi.dsi.fastutil.bytes.Byte2ObjectArrayMap
 *  me.egg82.antivpn.external.it.unimi.dsi.fastutil.bytes.Byte2ObjectMap
 */
package me.egg82.antivpn.utils;

import com.google.common.util.concurrent.ThreadFactoryBuilder;
import java.io.IOException;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicBoolean;
import me.egg82.antivpn.config.CachedConfig;
import me.egg82.antivpn.config.ConfigUtil;
import me.egg82.antivpn.core.DoubleBuffer;
import me.egg82.antivpn.external.it.unimi.dsi.fastutil.bytes.Byte2ObjectArrayMap;
import me.egg82.antivpn.external.it.unimi.dsi.fastutil.bytes.Byte2ObjectMap;
import me.egg82.antivpn.external.ninja.egg82.reflect.PackageFilter;
import me.egg82.antivpn.messaging.GenericMessagingHandler;
import me.egg82.antivpn.messaging.MessagingService;
import me.egg82.antivpn.messaging.packets.MultiPacket;
import me.egg82.antivpn.messaging.packets.Packet;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PacketUtil {
    private static final Logger logger = LoggerFactory.getLogger(PacketUtil.class);
    private static ExecutorService workPool = Executors.newFixedThreadPool(4, new ThreadFactoryBuilder().setNameFormat("AntiVPN-Messaging-%d").build());
    private static final Byte2ObjectMap<Class<Packet>> packetCache = new Byte2ObjectArrayMap();
    private static final DoubleBuffer<Packet> packetQueue;
    private static final AtomicBoolean requiresSending;

    private PacketUtil() {
    }

    public static void setPoolSize(int size) {
        workPool.shutdown();
        try {
            if (!workPool.awaitTermination(4L, TimeUnit.SECONDS)) {
                workPool.shutdownNow();
            }
        }
        catch (InterruptedException ignored) {
            Thread.currentThread().interrupt();
        }
        workPool = Executors.newFixedThreadPool(size, new ThreadFactoryBuilder().setNameFormat("AntiVPN-Messaging-%d").build());
    }

    public static @NonNull Byte2ObjectMap<Class<Packet>> getPacketCache() {
        return packetCache;
    }

    public static void queuePacket(@NonNull Packet packet) {
        packetQueue.getWriteBuffer().add(packet);
        requiresSending.set(true);
    }

    public static void repeatPacket(@NonNull UUID messageId, @NonNull Packet packet, @NonNull String fromService) {
        PacketUtil.sendPacket(messageId, packet, fromService);
    }

    public static void trySendQueue() {
        if (!requiresSending.compareAndSet(true, false)) {
            return;
        }
        packetQueue.swapBuffers();
        UUID messageId = UUID.randomUUID();
        GenericMessagingHandler.messageCache.put((Object)messageId, (Object)Boolean.TRUE);
        if (packetQueue.getReadBuffer().size() > 1) {
            Packet packet;
            MultiPacket multi = new MultiPacket();
            while ((packet = packetQueue.getReadBuffer().poll()) != null) {
                if (multi.getPackets().add(packet) || !ConfigUtil.getDebugOrFalse()) continue;
                logger.info("Skipping duplicate packet " + packet.getClass().getSimpleName());
            }
            if (!multi.getPackets().isEmpty()) {
                PacketUtil.sendPacket(messageId, multi, null);
            }
        } else {
            Packet packet = packetQueue.getReadBuffer().poll();
            if (packet != null) {
                PacketUtil.sendPacket(messageId, packet, null);
            }
        }
    }

    private static void sendPacket(@NonNull UUID messageId, @NonNull Packet packet, String fromService) {
        CachedConfig cachedConfig = ConfigUtil.getCachedConfig();
        if (cachedConfig == null) {
            logger.error("Could not get cached config.");
            return;
        }
        for (MessagingService service : cachedConfig.getMessaging()) {
            if (service.getName().equals(fromService)) continue;
            workPool.execute(() -> {
                try {
                    service.sendPacket(messageId, packet);
                }
                catch (IOException | TimeoutException ex) {
                    logger.warn("Could not broadcast packet " + packet.getClass().getSimpleName() + " through " + service.getName(), ex);
                }
            });
        }
    }

    static {
        List<Class<Packet>> packetClasses = PackageFilter.getClasses(Packet.class, "me.egg82.antivpn.messaging.packets", false, false, false, new String[0]);
        for (Class<Packet> clazz : packetClasses) {
            Packet packet;
            try {
                packet = clazz.newInstance();
            }
            catch (ExceptionInInitializerError | IllegalAccessException | InstantiationException | SecurityException ex) {
                logger.error("Could not instantiate packet " + clazz.getSimpleName() + ".", ex);
                continue;
            }
            packetCache.put(packet.getPacketId(), clazz);
        }
        packetQueue = new DoubleBuffer();
        requiresSending = new AtomicBoolean(false);
    }
}

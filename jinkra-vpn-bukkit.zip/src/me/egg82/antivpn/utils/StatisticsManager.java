package me.egg82.antivpn.utils;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.atomic.AtomicLong;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import java.util.logging.FileHandler;
import java.util.logging.SimpleFormatter;

/**
 * Jinkra VPN Statistics Manager
 * Tracks VPN detection metrics and generates reports
 */
public class StatisticsManager {
    private static final Logger LOGGER = Logger.getLogger("Jinkra-VPN");
    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    // Statistics counters
    private static final AtomicLong totalChecks = new AtomicLong(0);
    private static final AtomicLong vpnDetected = new AtomicLong(0);
    private static final AtomicLong mcleaksDetected = new AtomicLong(0);
    private static final AtomicLong playersBlocked = new AtomicLong(0);
    private static final AtomicLong cacheHits = new AtomicLong(0);
    private static final AtomicLong totalResponseTime = new AtomicLong(0);

    // Event log
    private static final List<LogEntry> eventLog = new ArrayList<>();
    private static final int MAX_LOG_SIZE = 10000;

    /**
     * Record a VPN check event
     */
    public static void recordCheck(String playerName, String ip, boolean isVPN, boolean isMCLeaks, long responseTime) {
        totalChecks.incrementAndGet();
        totalResponseTime.addAndGet(responseTime);

        if (isVPN) {
            vpnDetected.incrementAndGet();
        }
        if (isMCLeaks) {
            mcleaksDetected.incrementAndGet();
        }
        if (isVPN || isMCLeaks) {
            playersBlocked.incrementAndGet();
        }

        String eventType = "CHECK";
        if (isVPN) eventType = "VPN_DETECTED";
        if (isMCLeaks) eventType = "MCLEAKS_DETECTED";

        addLogEntry(new LogEntry(playerName, ip, eventType, "Response: " + responseTime + "ms"));
    }

    /**
     * Record a manual check via admin command
     */
    public static void recordManualCheck(String playerName, String ip, boolean isVPN, boolean isMCLeaks) {
        recordCheck(playerName, ip, isVPN, isMCLeaks, 0);
        addLogEntry(new LogEntry(playerName, ip, "ADMIN_CHECK", "Manual check by admin"));
    }

    /**
     * Record cache hit
     */
    public static void recordCacheHit() {
        cacheHits.incrementAndGet();
    }

    /**
     * Record whitelist change
     */
    public static void recordWhitelistChange(String action, String target, String admin) {
        addLogEntry(new LogEntry(admin, target, "WHITELIST_" + action, "Action by: " + admin));
    }

    /**
     * Record player blocked
     */
    public static void recordPlayerBlocked(String playerName, String ip, String reason) {
        addLogEntry(new LogEntry(playerName, ip, "PLAYER_BLOCKED", reason));
    }

    /**
     * Get current statistics snapshot
     */
    public static Stats getStats() {
        long total = totalChecks.get();
        long avgResponseTime = total > 0 ? totalResponseTime.get() / total : 0;
        double cacheHitRate = total > 0 ? (double) cacheHits.get() / total : 0;

        return new Stats(
            total,
            vpnDetected.get(),
            mcleaksDetected.get(),
            playersBlocked.get(),
            cacheHitRate,
            avgResponseTime
        );
    }

    /**
     * Get recent events
     */
    public static List<LogEntry> getRecentEvents(int limit) {
        synchronized (eventLog) {
            int start = Math.max(0, eventLog.size() - limit);
            return new ArrayList<>(eventLog.subList(start, eventLog.size()));
        }
    }

    /**
     * Add entry to event log
     */
    private static void addLogEntry(LogEntry entry) {
        synchronized (eventLog) {
            eventLog.add(entry);
            if (eventLog.size() > MAX_LOG_SIZE) {
                eventLog.remove(0);
            }
        }

        // Log to console
        LOGGER.info("[" + entry.timestamp + "] " + entry.eventType + " - " + entry.playerName +
                   " (" + entry.ip + ") - " + entry.details);
    }

    /**
     * Reset statistics (admin command)
     */
    public static void resetStatistics() {
        totalChecks.set(0);
        vpnDetected.set(0);
        mcleaksDetected.set(0);
        playersBlocked.set(0);
        cacheHits.set(0);
        totalResponseTime.set(0);
        synchronized (eventLog) {
            eventLog.clear();
        }
    }

    /**
     * Statistics data class
     */
    public static class Stats {
        private final long totalChecks;
        private final long vpnDetected;
        private final long mcleaksDetected;
        private final long playersBlocked;
        private final double cacheHitRate;
        private final long averageResponseTime;

        public Stats(long totalChecks, long vpnDetected, long mcleaksDetected,
                    long playersBlocked, double cacheHitRate, long averageResponseTime) {
            this.totalChecks = totalChecks;
            this.vpnDetected = vpnDetected;
            this.mcleaksDetected = mcleaksDetected;
            this.playersBlocked = playersBlocked;
            this.cacheHitRate = cacheHitRate;
            this.averageResponseTime = averageResponseTime;
        }

        public long getTotalChecks() { return totalChecks; }
        public long getVpnDetected() { return vpnDetected; }
        public long getMcleaksDetected() { return mcleaksDetected; }
        public long getPlayersBlocked() { return playersBlocked; }
        public double getCacheHitRate() { return cacheHitRate; }
        public long getAverageResponseTime() { return averageResponseTime; }
    }

    /**
     * Log entry class
     */
    public static class LogEntry {
        public final String timestamp;
        public final String playerName;
        public final String ip;
        public final String eventType;
        public final String details;

        public LogEntry(String playerName, String ip, String eventType, String details) {
            this.timestamp = LocalDateTime.now().format(FORMATTER);
            this.playerName = playerName;
            this.ip = ip;
            this.eventType = eventType;
            this.details = details;
        }
    }
}

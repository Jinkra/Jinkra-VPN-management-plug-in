/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.google.common.primitives.Ints
 */
package me.egg82.antivpn.utils;

import com.google.common.primitives.Ints;
import java.util.ArrayList;
import java.util.List;
import me.egg82.antivpn.external.ninja.egg82.reflect.PackageFilter;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.checkerframework.checker.nullness.qual.Nullable;

public class VersionUtil {
    private VersionUtil() {
    }

    public static boolean isAtLeast(@NonNull String atLeastVersion, char separator1, @NonNull String versionToTest, char separator2) {
        int[] v1 = VersionUtil.parseVersion(atLeastVersion, separator1);
        int[] v2 = VersionUtil.parseVersion(versionToTest, separator2);
        boolean equalOrGreater = true;
        for (int i = 0; i < v1.length; ++i) {
            if (i > v2.length) {
                equalOrGreater = false;
                break;
            }
            if (v2[i] >= v1[i]) continue;
            equalOrGreater = false;
            break;
        }
        return equalOrGreater;
    }

    public static <T> @Nullable Class<T> getBestMatch(@NonNull Class<T> clazz, @NonNull String version, @NonNull String packageName, boolean recursive) {
        List<Class<T>> enums = PackageFilter.getClasses(clazz, packageName, recursive, false, false, new String[0]);
        enums.sort((v1, v2) -> {
            int[] v1Name = VersionUtil.parseVersion(v1.getSimpleName(), '_');
            int[] v2Name = VersionUtil.parseVersion(v2.getSimpleName(), '_');
            if (v1Name.length == 0) {
                return -1;
            }
            if (v2Name.length == 0) {
                return 1;
            }
            for (int i = 0; i < Math.min(v1Name.length, v2Name.length); ++i) {
                if (v1Name[i] < v2Name[i]) {
                    return -1;
                }
                if (v1Name[i] <= v2Name[i]) continue;
                return 1;
            }
            return 0;
        });
        int[] currentVersion = VersionUtil.parseVersion(version, '.');
        Class<T> bestMatch = null;
        for (Class<T> c : enums) {
            String name = c.getSimpleName();
            int[] reflectVersion = VersionUtil.parseVersion(name, '_');
            boolean equalToOrLessThan = true;
            for (int i = 0; i < reflectVersion.length; ++i) {
                if (currentVersion.length > i) {
                    if (reflectVersion[i] > currentVersion[i]) {
                        equalToOrLessThan = false;
                        break;
                    }
                    if (currentVersion[i] <= reflectVersion[i]) continue;
                    break;
                }
                equalToOrLessThan = false;
                break;
            }
            if (!equalToOrLessThan) continue;
            bestMatch = c;
        }
        return bestMatch;
    }

    public static int @NonNull [] parseVersion(@NonNull String version, char separator) {
        int current;
        ArrayList<Integer> ints = new ArrayList<Integer>();
        int lastIndex = 0;
        int currentIndex = version.indexOf(separator);
        while (currentIndex > -1) {
            current = VersionUtil.tryParseInt(version.substring(lastIndex, currentIndex));
            if (current > -1) {
                ints.add(current);
            }
            lastIndex = currentIndex + 1;
            currentIndex = version.indexOf(separator, currentIndex + 1);
        }
        current = VersionUtil.tryParseInt(version.substring(lastIndex));
        if (current > -1) {
            ints.add(current);
        }
        return Ints.toArray(ints);
    }

    public static int tryParseInt(@NonNull String value) {
        try {
            return Integer.parseInt(value);
        }
        catch (Exception ex) {
            return -1;
        }
    }
}

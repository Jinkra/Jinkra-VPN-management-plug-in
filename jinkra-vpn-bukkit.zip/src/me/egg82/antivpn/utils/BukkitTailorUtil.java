/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.entity.Player
 */
package me.egg82.antivpn.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import me.egg82.antivpn.external.ninja.egg82.service.ServiceLocator;
import me.egg82.antivpn.hooks.PlaceholderAPIHook;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BukkitTailorUtil {
    private static final Logger logger = LoggerFactory.getLogger(BukkitTailorUtil.class);

    private BukkitTailorUtil() {
    }

    public static @NonNull List<String> tailorCommands(@NonNull List<String> commands, @NonNull String name, @NonNull UUID uuid, @NonNull String ip) {
        Optional<PlaceholderAPIHook> placeholderapi;
        ArrayList<String> retVal = new ArrayList<String>();
        try {
            placeholderapi = ServiceLocator.getOptional(PlaceholderAPIHook.class);
        }
        catch (IllegalAccessException | InstantiationException ex) {
            logger.error(ex.getMessage(), ex);
            placeholderapi = Optional.empty();
        }
        for (String command : commands) {
            if ((command = command.replace("%player%", name).replace("%uuid%", uuid.toString()).replace("%ip%", ip)).charAt(0) == '/') {
                command = command.substring(1);
            }
            if (placeholderapi.isPresent()) {
                Player p;
                retVal.add(placeholderapi.get().withPlaceholders((OfflinePlayer)((p = Bukkit.getPlayer((UUID)uuid)) != null ? p : Bukkit.getOfflinePlayer((UUID)uuid)), command));
                continue;
            }
            retVal.add(command);
        }
        return retVal;
    }

    public static @NonNull String tailorKickMessage(@NonNull String message, @NonNull String name, @NonNull UUID uuid, @NonNull String ip) {
        Optional<PlaceholderAPIHook> placeholderapi;
        try {
            placeholderapi = ServiceLocator.getOptional(PlaceholderAPIHook.class);
        }
        catch (IllegalAccessException | InstantiationException ex) {
            logger.error(ex.getMessage(), ex);
            placeholderapi = Optional.empty();
        }
        message = message.replace("%player%", name).replace("%uuid%", uuid.toString()).replace("%ip%", ip);
        if (placeholderapi.isPresent()) {
            Player p;
            message = placeholderapi.get().withPlaceholders((OfflinePlayer)((p = Bukkit.getPlayer((UUID)uuid)) != null ? p : Bukkit.getOfflinePlayer((UUID)uuid)), message);
        }
        return ChatColor.translateAlternateColorCodes((char)'&', (String)message.replace("\\r", "").replace("\r", "").replace("\\n", "\n"));
    }
}

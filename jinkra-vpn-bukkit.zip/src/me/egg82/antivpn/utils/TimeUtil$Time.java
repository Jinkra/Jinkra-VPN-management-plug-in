/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.utils;

import java.util.Objects;
import java.util.concurrent.TimeUnit;
import org.checkerframework.checker.nullness.qual.NonNull;

public static class TimeUtil.Time {
    private final long time;
    private final TimeUnit unit;
    private final int hc;

    public TimeUtil.Time(long time, @NonNull TimeUnit unit) {
        this.time = time;
        this.unit = unit;
        this.hc = Objects.hash(new Object[]{time, unit});
    }

    public long getTime() {
        return this.time;
    }

    public TimeUnit getUnit() {
        return this.unit;
    }

    public long getMillis() {
        return this.unit.toMillis(this.time);
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof TimeUtil.Time)) {
            return false;
        }
        TimeUtil.Time time1 = (TimeUtil.Time)o;
        return this.time == time1.time && this.unit == time1.unit;
    }

    public int hashCode() {
        return this.hc;
    }

    static /* synthetic */ TimeUnit access$000(TimeUtil.Time x0) {
        return x0.unit;
    }

    static /* synthetic */ long access$100(TimeUtil.Time x0) {
        return x0.time;
    }
}

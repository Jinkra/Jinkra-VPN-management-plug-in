/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.json.simple.parser.ParseException
 */
package me.egg82.antivpn.services;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.UUID;
import me.egg82.antivpn.external.ninja.egg82.analytics.GameAnalytics;
import me.egg82.antivpn.external.ninja.egg82.analytics.common.Severity;
import me.egg82.antivpn.external.ninja.egg82.analytics.events.GAError;
import me.egg82.antivpn.external.ninja.egg82.analytics.events.GASessionEnd;
import me.egg82.antivpn.external.ninja.egg82.analytics.events.GASessionStart;
import me.egg82.antivpn.external.ninja.egg82.analytics.events.base.GAEventBase;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.json.simple.parser.ParseException;

public class GameAnalyticsErrorHandler {
    private static GameAnalytics gameAnalytics = null;
    private static GAEventBase eventBase = null;
    private static long start = -1L;

    private GameAnalyticsErrorHandler() {
    }

    public static void sendException(@NonNull Throwable exception) {
        block2: {
            try {
                gameAnalytics.queueEvent(GAError.builder(eventBase, exception).build());
            }
            catch (IOException ex) {
                if (ex.getMessage().equals("Connection has been closed.")) break block2;
                ex.printStackTrace();
            }
        }
    }

    public static void sendMessage(@NonNull Severity severity, @NonNull String message) {
        block3: {
            if (gameAnalytics == null) {
                return;
            }
            try {
                gameAnalytics.queueEvent(GAError.builder(eventBase, severity, message).build());
            }
            catch (IOException ex) {
                if (ex.getMessage().equals("Connection has been closed.")) break block3;
                ex.printStackTrace();
            }
        }
    }

    public static void open(@NonNull UUID userID, @NonNull String buildVersion, @NonNull String serverVersion) {
        try {
            gameAnalytics = new GameAnalytics("10b55aa4f41d64ff258f9c66a5fbf9ec", "3794acfebab1122e852d73bbf505c37f42bf3f41", 5);
        }
        catch (IOException | InvalidKeyException | NoSuchAlgorithmException | ParseException ex) {
            ex.printStackTrace();
            return;
        }
        eventBase = GAEventBase.builder(gameAnalytics, userID, 1L).buildVersion(buildVersion).engineVersion(serverVersion).build();
        start = System.currentTimeMillis();
        try {
            gameAnalytics.queueEvent(GASessionStart.builder(eventBase).build());
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public static void close() {
        if (gameAnalytics == null) {
            return;
        }
        try {
            gameAnalytics.queueEvent(GASessionEnd.builder(eventBase, Math.floorDiv(System.currentTimeMillis() - start, 1000L)).build());
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
        gameAnalytics.close();
    }
}

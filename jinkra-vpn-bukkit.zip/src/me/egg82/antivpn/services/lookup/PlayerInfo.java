/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 */
package me.egg82.antivpn.services.lookup;

import com.google.common.collect.ImmutableList;
import java.util.UUID;
import me.egg82.antivpn.services.lookup.models.ProfileModel;
import org.checkerframework.checker.nullness.qual.NonNull;

public interface PlayerInfo {
    public @NonNull String getName();

    public @NonNull UUID getUUID();

    public @NonNull ImmutableList<ProfileModel.ProfilePropertyModel> getProperties();
}

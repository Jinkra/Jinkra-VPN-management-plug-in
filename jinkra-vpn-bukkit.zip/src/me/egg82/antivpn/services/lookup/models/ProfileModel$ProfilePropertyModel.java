/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.services.lookup.models;

import java.io.Serializable;
import java.util.Objects;

public static class ProfileModel.ProfilePropertyModel
implements Serializable {
    private String name = null;
    private String value = null;
    private String signature = null;

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getValue() {
        return this.value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public boolean hasSignature() {
        return this.signature != null;
    }

    public String getSignature() {
        return this.signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof ProfileModel.ProfilePropertyModel)) {
            return false;
        }
        ProfileModel.ProfilePropertyModel that = (ProfileModel.ProfilePropertyModel)o;
        return Objects.equals(this.name, that.name) && Objects.equals(this.value, that.value) && Objects.equals(this.signature, that.signature);
    }

    public int hashCode() {
        return Objects.hash(this.name, this.value, this.signature);
    }

    public String toString() {
        return "ProfilePropertyModel{name='" + this.name + '\'' + ", value='" + this.value + '\'' + ", signature='" + this.signature + '\'' + '}';
    }
}

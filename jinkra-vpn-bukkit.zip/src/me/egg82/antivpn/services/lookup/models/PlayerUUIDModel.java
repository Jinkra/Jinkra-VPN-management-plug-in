/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.services.lookup.models;

import java.io.Serializable;
import java.util.Objects;

public class PlayerUUIDModel
implements Serializable {
    private String name = null;
    private String id = null;

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof PlayerUUIDModel)) {
            return false;
        }
        PlayerUUIDModel that = (PlayerUUIDModel)o;
        return Objects.equals(this.name, that.name) && Objects.equals(this.id, that.id);
    }

    public int hashCode() {
        return Objects.hash(this.name, this.id);
    }

    public String toString() {
        return "PlayerModel{name='" + this.name + '\'' + ", id='" + this.id + '\'' + '}';
    }
}

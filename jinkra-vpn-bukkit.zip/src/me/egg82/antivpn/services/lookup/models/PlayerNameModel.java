/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.services.lookup.models;

import java.io.Serializable;
import java.util.Objects;

public class PlayerNameModel
implements Serializable {
    private String name = null;

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof PlayerNameModel)) {
            return false;
        }
        PlayerNameModel that = (PlayerNameModel)o;
        return Objects.equals(this.name, that.name);
    }

    public int hashCode() {
        return Objects.hash(this.name);
    }

    public String toString() {
        return "PlayerNameModel{name='" + this.name + '\'' + '}';
    }
}

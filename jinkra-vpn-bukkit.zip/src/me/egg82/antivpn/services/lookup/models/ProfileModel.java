/*
 * Decompiled with CFR 0.151.
 */
package me.egg82.antivpn.services.lookup.models;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class ProfileModel
implements Serializable {
    private String id = null;
    private String name = null;
    private List<ProfilePropertyModel> properties = new ArrayList<ProfilePropertyModel>();

    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<ProfilePropertyModel> getProperties() {
        return this.properties;
    }

    public void setProperties(List<ProfilePropertyModel> properties) {
        this.properties = properties;
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof ProfileModel)) {
            return false;
        }
        ProfileModel that = (ProfileModel)o;
        return Objects.equals(this.id, that.id) && Objects.equals(this.name, that.name) && Objects.equals(this.properties, that.properties);
    }

    public int hashCode() {
        return Objects.hash(this.id, this.name, this.properties);
    }

    public String toString() {
        return "ProfileModel{id='" + this.id + '\'' + ", name='" + this.name + '\'' + ", properties=" + this.properties + '}';
    }

    public static class ProfilePropertyModel
    implements Serializable {
        private String name = null;
        private String value = null;
        private String signature = null;

        public String getName() {
            return this.name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getValue() {
            return this.value;
        }

        public void setValue(String value) {
            this.value = value;
        }

        public boolean hasSignature() {
            return this.signature != null;
        }

        public String getSignature() {
            return this.signature;
        }

        public void setSignature(String signature) {
            this.signature = signature;
        }

        public boolean equals(Object o) {
            if (this == o) {
                return true;
            }
            if (!(o instanceof ProfilePropertyModel)) {
                return false;
            }
            ProfilePropertyModel that = (ProfilePropertyModel)o;
            return Objects.equals(this.name, that.name) && Objects.equals(this.value, that.value) && Objects.equals(this.signature, that.signature);
        }

        public int hashCode() {
            return Objects.hash(this.name, this.value, this.signature);
        }

        public String toString() {
            return "ProfilePropertyModel{name='" + this.name + '\'' + ", value='" + this.value + '\'' + ", signature='" + this.signature + '\'' + '}';
        }
    }
}

/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 *  me.egg82.antivpn.external.com.github.benmanes.caffeine.cache.Cache
 *  me.egg82.antivpn.external.com.github.benmanes.caffeine.cache.Caffeine
 *  org.bukkit.Bukkit
 *  org.bukkit.entity.Player
 */
package me.egg82.antivpn.services.lookup;

import com.google.common.collect.ImmutableList;
import flexjson.JSONDeserializer;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import me.egg82.antivpn.external.com.github.benmanes.caffeine.cache.Cache;
import me.egg82.antivpn.external.com.github.benmanes.caffeine.cache.Caffeine;
import me.egg82.antivpn.services.lookup.PlayerInfo;
import me.egg82.antivpn.services.lookup.models.PlayerNameModel;
import me.egg82.antivpn.services.lookup.models.PlayerUUIDModel;
import me.egg82.antivpn.services.lookup.models.ProfileModel;
import me.egg82.antivpn.utils.WebUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.checkerframework.checker.nullness.qual.Nullable;

public class BukkitPlayerInfo
implements PlayerInfo {
    private final UUID uuid;
    private final String name;
    private List<ProfileModel.ProfilePropertyModel> properties;
    private static final Cache<UUID, String> uuidCache = Caffeine.newBuilder().expireAfterWrite(1L, TimeUnit.HOURS).build();
    private static final Cache<String, UUID> nameCache = Caffeine.newBuilder().expireAfterWrite(1L, TimeUnit.HOURS).build();
    private static final Cache<UUID, List<ProfileModel.ProfilePropertyModel>> propertiesCache = Caffeine.newBuilder().expireAfterWrite(1L, TimeUnit.DAYS).build();
    private static final Object uuidCacheLock = new Object();
    private static final Object nameCacheLock = new Object();
    private static final Object propertiesCacheLock = new Object();
    private static final Map<String, String> headers = new HashMap<String, String>();

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    BukkitPlayerInfo(@NonNull UUID uuid) throws IOException {
        this.uuid = uuid;
        Optional<Object> name = Optional.ofNullable(uuidCache.getIfPresent((Object)uuid));
        if (!name.isPresent()) {
            Object object = uuidCacheLock;
            synchronized (object) {
                name = Optional.ofNullable(uuidCache.getIfPresent((Object)uuid));
                if (!name.isPresent()) {
                    name = Optional.ofNullable(BukkitPlayerInfo.nameExpensive(uuid));
                    name.ifPresent(v -> uuidCache.put((Object)uuid, v));
                }
            }
        }
        this.name = name.orElse(null);
        if (this.name != null) {
            Optional<Object> properties = Optional.ofNullable(propertiesCache.getIfPresent((Object)uuid));
            if (!properties.isPresent()) {
                Object object = propertiesCacheLock;
                synchronized (object) {
                    properties = Optional.ofNullable(propertiesCache.getIfPresent((Object)uuid));
                    if (!properties.isPresent()) {
                        properties = Optional.ofNullable(BukkitPlayerInfo.propertiesExpensive(uuid));
                        properties.ifPresent(v -> propertiesCache.put((Object)uuid, v));
                    }
                }
            }
            this.properties = properties.orElse(null);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    BukkitPlayerInfo(@NonNull String name) throws IOException {
        this.name = name;
        Optional<Object> uuid = Optional.ofNullable(nameCache.getIfPresent((Object)name));
        if (!uuid.isPresent()) {
            Object object = nameCacheLock;
            synchronized (object) {
                uuid = Optional.ofNullable(nameCache.getIfPresent((Object)name));
                if (!uuid.isPresent()) {
                    uuid = Optional.ofNullable(BukkitPlayerInfo.uuidExpensive(name));
                    uuid.ifPresent(v -> nameCache.put((Object)name, v));
                }
            }
        }
        this.uuid = uuid.orElse(null);
        if (this.uuid != null) {
            Optional<Object> properties = Optional.ofNullable(propertiesCache.getIfPresent((Object)this.uuid));
            if (!properties.isPresent()) {
                Object object = propertiesCacheLock;
                synchronized (object) {
                    properties = Optional.ofNullable(propertiesCache.getIfPresent((Object)this.uuid));
                    if (!properties.isPresent()) {
                        properties = Optional.ofNullable(BukkitPlayerInfo.propertiesExpensive(this.uuid));
                        properties.ifPresent(v -> propertiesCache.put((Object)this.uuid, v));
                    }
                }
            }
            this.properties = properties.orElse(null);
        }
    }

    @Override
    public @NonNull UUID getUUID() {
        return this.uuid;
    }

    @Override
    public @NonNull String getName() {
        return this.name;
    }

    @Override
    public @NonNull ImmutableList<ProfileModel.ProfilePropertyModel> getProperties() {
        return ImmutableList.copyOf(this.properties);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private static @Nullable String nameExpensive(@NonNull UUID uuid) throws IOException {
        Player player = Bukkit.getPlayer((UUID)uuid);
        if (player != null) {
            Object object = nameCacheLock;
            synchronized (object) {
                nameCache.put((Object)player.getName(), (Object)uuid);
            }
            return player.getName();
        }
        HttpURLConnection conn = WebUtil.getConnectionWithThrows(new URL("https://api.mojang.com/user/profiles/" + uuid.toString().replace("-", "") + "/names"), "GET", 2500, "egg82/PlayerInfo", headers);
        int status = conn.getResponseCode();
        if (status == 204) {
            return null;
        }
        if (status == 200) {
            JSONDeserializer modelDeserializer = new JSONDeserializer();
            modelDeserializer.use("values", PlayerNameModel.class);
            List model = (List)modelDeserializer.deserialize(WebUtil.getString(conn));
            String name = ((PlayerNameModel)model.get(model.size() - 1)).getName();
            Object object = nameCacheLock;
            synchronized (object) {
                nameCache.put((Object)name, (Object)uuid);
            }
            return name;
        }
        throw new IOException("Mojang API response code: " + status);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private static @Nullable UUID uuidExpensive(@NonNull String name) throws IOException {
        Player player = Bukkit.getPlayer((String)name);
        if (player != null) {
            Object object = uuidCacheLock;
            synchronized (object) {
                uuidCache.put((Object)player.getUniqueId(), (Object)name);
            }
            return player.getUniqueId();
        }
        HttpURLConnection conn = WebUtil.getConnectionWithThrows(new URL("https://api.mojang.com/users/profiles/minecraft/" + WebUtil.urlEncode(name)), "GET", 2500, "egg82/PlayerInfo", headers);
        int status = conn.getResponseCode();
        if (status == 204) {
            return null;
        }
        if (status == 200) {
            JSONDeserializer modelDeserializer = new JSONDeserializer();
            PlayerUUIDModel model = (PlayerUUIDModel)modelDeserializer.deserialize(WebUtil.getString(conn), PlayerUUIDModel.class);
            UUID uuid = UUID.fromString(model.getId().replaceFirst("(\\p{XDigit}{8})(\\p{XDigit}{4})(\\p{XDigit}{4})(\\p{XDigit}{4})(\\p{XDigit}+)", "$1-$2-$3-$4-$5"));
            Object object = uuidCacheLock;
            synchronized (object) {
                uuidCache.put((Object)uuid, (Object)name);
            }
            return uuid;
        }
        throw new IOException("Mojang API response code: " + status);
    }

    private static @Nullable List<ProfileModel.ProfilePropertyModel> propertiesExpensive(@NonNull UUID uuid) throws IOException {
        HttpURLConnection conn = WebUtil.getConnectionWithThrows(new URL("https://sessionserver.mojang.com/session/minecraft/profile/" + uuid.toString().replace("-", "") + "?unsigned=false"), "GET", 2500, "egg82/PlayerInfo", headers);
        int status = conn.getResponseCode();
        if (status == 204) {
            return null;
        }
        if (status == 200) {
            JSONDeserializer modelDeserializer = new JSONDeserializer();
            return ((ProfileModel)modelDeserializer.deserialize(WebUtil.getString(conn), ProfileModel.class)).getProperties();
        }
        throw new IOException("Mojang API response code: " + status);
    }

    static {
        headers.put("Accept", "application/json");
        headers.put("Accept-Language", "en-US,en;q=0.8");
    }
}

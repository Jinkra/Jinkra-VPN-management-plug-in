/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.destroystokyo.paper.profile.PlayerProfile
 *  com.destroystokyo.paper.profile.ProfileProperty
 *  com.google.common.collect.ImmutableList
 *  me.egg82.antivpn.external.com.github.benmanes.caffeine.cache.Cache
 *  me.egg82.antivpn.external.com.github.benmanes.caffeine.cache.Caffeine
 *  org.bukkit.Bukkit
 *  org.bukkit.entity.Player
 */
package me.egg82.antivpn.services.lookup;

import com.destroystokyo.paper.profile.PlayerProfile;
import com.destroystokyo.paper.profile.ProfileProperty;
import com.google.common.collect.ImmutableList;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import me.egg82.antivpn.external.com.github.benmanes.caffeine.cache.Cache;
import me.egg82.antivpn.external.com.github.benmanes.caffeine.cache.Caffeine;
import me.egg82.antivpn.services.lookup.PlayerInfo;
import me.egg82.antivpn.services.lookup.models.ProfileModel;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.checkerframework.checker.nullness.qual.NonNull;

public class PaperPlayerInfo
implements PlayerInfo {
    private final UUID uuid;
    private final String name;
    private List<ProfileModel.ProfilePropertyModel> properties;
    private static final Cache<UUID, String> uuidCache = Caffeine.newBuilder().expireAfterAccess(1L, TimeUnit.MINUTES).expireAfterWrite(1L, TimeUnit.HOURS).build();
    private static final Cache<String, UUID> nameCache = Caffeine.newBuilder().expireAfterAccess(1L, TimeUnit.MINUTES).expireAfterWrite(1L, TimeUnit.HOURS).build();
    private static final Cache<UUID, List<ProfileModel.ProfilePropertyModel>> propertiesCache = Caffeine.newBuilder().expireAfterAccess(1L, TimeUnit.MINUTES).expireAfterWrite(1L, TimeUnit.DAYS).build();
    private static final Object uuidCacheLock = new Object();
    private static final Object nameCacheLock = new Object();
    private static final Object propertiesCacheLock = new Object();

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    PaperPlayerInfo(@NonNull UUID uuid) throws IOException {
        this.uuid = uuid;
        Optional<Object> name = Optional.ofNullable(uuidCache.getIfPresent((Object)uuid));
        if (!name.isPresent()) {
            Object object = uuidCacheLock;
            synchronized (object) {
                name = Optional.ofNullable(uuidCache.getIfPresent((Object)uuid));
                if (!name.isPresent()) {
                    name = Optional.ofNullable(PaperPlayerInfo.nameExpensive(uuid));
                    name.ifPresent(v -> uuidCache.put((Object)uuid, v));
                }
            }
        }
        this.name = name.orElse(null);
        if (this.name != null) {
            Optional<Object> properties = Optional.ofNullable(propertiesCache.getIfPresent((Object)uuid));
            if (!properties.isPresent()) {
                Object object = propertiesCacheLock;
                synchronized (object) {
                    properties = Optional.ofNullable(propertiesCache.getIfPresent((Object)uuid));
                    if (!properties.isPresent()) {
                        properties = Optional.ofNullable(PaperPlayerInfo.propertiesExpensive(uuid));
                        properties.ifPresent(v -> propertiesCache.put((Object)uuid, v));
                    }
                }
            }
            this.properties = properties.orElse(null);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    PaperPlayerInfo(@NonNull String name) throws IOException {
        this.name = name;
        Optional<Object> uuid = Optional.ofNullable(nameCache.getIfPresent((Object)name));
        if (!uuid.isPresent()) {
            Object object = nameCacheLock;
            synchronized (object) {
                uuid = Optional.ofNullable(nameCache.getIfPresent((Object)name));
                if (!uuid.isPresent()) {
                    uuid = Optional.ofNullable(PaperPlayerInfo.uuidExpensive(name));
                    uuid.ifPresent(v -> nameCache.put((Object)name, v));
                }
            }
        }
        this.uuid = uuid.orElse(null);
        if (this.uuid != null) {
            Optional<Object> properties = Optional.ofNullable(propertiesCache.getIfPresent((Object)this.uuid));
            if (!properties.isPresent()) {
                Object object = propertiesCacheLock;
                synchronized (object) {
                    properties = Optional.ofNullable(propertiesCache.getIfPresent((Object)this.uuid));
                    if (!properties.isPresent()) {
                        properties = Optional.ofNullable(PaperPlayerInfo.propertiesExpensive(this.uuid));
                        properties.ifPresent(v -> propertiesCache.put((Object)this.uuid, v));
                    }
                }
            }
            this.properties = properties.orElse(null);
        }
    }

    @Override
    public @NonNull UUID getUUID() {
        return this.uuid;
    }

    @Override
    public @NonNull String getName() {
        return this.name;
    }

    @Override
    public @NonNull ImmutableList<ProfileModel.ProfilePropertyModel> getProperties() {
        return ImmutableList.copyOf(this.properties);
    }

    private static @NonNull String nameExpensive(@NonNull UUID uuid) throws IOException {
        Player player = Bukkit.getPlayer((UUID)uuid);
        if (player != null) {
            nameCache.put((Object)player.getName(), (Object)uuid);
            return player.getName();
        }
        PlayerProfile profile = Bukkit.createProfile((UUID)uuid);
        if ((profile.isComplete() || profile.completeFromCache()) && profile.getName() != null && profile.getId() != null) {
            nameCache.put((Object)profile.getName(), (Object)profile.getId());
            return profile.getName();
        }
        if (profile.complete(false) && profile.getName() != null && profile.getId() != null) {
            nameCache.put((Object)profile.getName(), (Object)profile.getId());
            return profile.getName();
        }
        throw new IOException("Could not load player data from Mojang (rate-limited?)");
    }

    private static @NonNull UUID uuidExpensive(@NonNull String name) throws IOException {
        Player player = Bukkit.getPlayer((String)name);
        if (player != null) {
            uuidCache.put((Object)player.getUniqueId(), (Object)name);
            return player.getUniqueId();
        }
        PlayerProfile profile = Bukkit.createProfile((String)name);
        if ((profile.isComplete() || profile.completeFromCache()) && profile.getName() != null && profile.getId() != null) {
            uuidCache.put((Object)profile.getId(), (Object)profile.getName());
            return profile.getId();
        }
        if (profile.complete(false) && profile.getName() != null && profile.getId() != null) {
            uuidCache.put((Object)profile.getId(), (Object)profile.getName());
            return profile.getId();
        }
        throw new IOException("Could not load player data from Mojang (rate-limited?)");
    }

    private static @NonNull List<ProfileModel.ProfilePropertyModel> propertiesExpensive(@NonNull UUID uuid) throws IOException {
        PlayerProfile profile = Bukkit.createProfile((UUID)uuid);
        if ((profile.isComplete() || profile.completeFromCache()) && profile.getName() != null && profile.getId() != null) {
            return PaperPlayerInfo.toPropertiesModel(profile.getProperties());
        }
        if (profile.complete(false) && profile.getName() != null && profile.getId() != null) {
            return PaperPlayerInfo.toPropertiesModel(profile.getProperties());
        }
        throw new IOException("Could not load skin data from Mojang (rate-limited?)");
    }

    private static @NonNull List<ProfileModel.ProfilePropertyModel> toPropertiesModel(@NonNull Set<ProfileProperty> properties) {
        ArrayList<ProfileModel.ProfilePropertyModel> retVal = new ArrayList<ProfileModel.ProfilePropertyModel>();
        for (ProfileProperty property : properties) {
            ProfileModel.ProfilePropertyModel newProperty = new ProfileModel.ProfilePropertyModel();
            newProperty.setName(property.getName());
            newProperty.setValue(property.getValue());
            newProperty.setSignature(property.getSignature());
            retVal.add(newProperty);
        }
        return retVal;
    }
}
